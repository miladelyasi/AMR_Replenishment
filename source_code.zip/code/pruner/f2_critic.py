"""
pruner/f2_critic.py
===================
Terminal-value critic V_psi for F2.

Trains a state-value network to predict the SMDP-discounted future
stockout-minutes from a logged state. The target is reconstructed
*offline* from the per-epoch buffer trajectory (state_features.B) and
holding times (epoch_time deltas) — no new reward instrumentation in the
simulator, so the logger stays non-invasive.

Target (per epoch n, within an episode):
    G_n = sum_{m>=n} gamma^((t_m - t_n)/K) * stockout_increment_m
    stockout_increment_m = (t_{m+1}-t_m)/60 * #{ lines l : B_{l,m} <= 0 }

V_psi(s_n) ~= E[G_n | s_n]. Lower = healthier (less future stockout).

CLI:
    python -m pruner.f2_critic train \
        --jsonl rollouts/base_h80/milponly_seed*.jsonl \
        --out-dir runs/f2_base_h80 \
        --gamma 0.995 --K 5 --epochs 30
"""

from __future__ import annotations

import argparse
import glob
import json
import os
from dataclasses import dataclass, asdict
from typing import Dict, List, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


# --------------------------------------------------------------------------- #
# State-vector assembly from state_features
# --------------------------------------------------------------------------- #

@dataclass
class CriticIndex:
    nL: int
    nR: int
    state_mean: List[float]
    state_std: List[float]
    target_mean: float
    target_std: float
    gamma: float
    K: float

    def save(self, p):
        os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
        json.dump(asdict(self), open(p, "w"), indent=2)

    @classmethod
    def load(cls, p):
        return cls(**json.load(open(p)))


_PER_LINE = ("B", "S", "hat_lambda", "hat_T_so")
_PER_ROBOT = ("battery", "tau_free")
_SCALARS = ("congestion_norm", "n_lines_critical", "min_T_so", "mean_buffer")


def _state_vector(sf: dict, nL: int, nR: int) -> np.ndarray:
    """Fixed-length state vector from one record's state_features dict."""
    parts: List[float] = []

    for k in _PER_LINE:
        a = list(sf.get(k, []) or [])
        a = (a + [0.0] * nL)[:nL]
        parts += [float(x) for x in a]

    for k in _PER_ROBOT:
        a = list(sf.get(k, []) or [])
        a = (a + [0.0] * nR)[:nR]
        parts += [float(x) for x in a]

    for k in _SCALARS:
        parts.append(float(sf.get(k, 0.0) or 0.0))

    # Episode-progress feature.
    parts.append(float(sf.get("epoch_time", 0.0) or 0.0) / 28800.0)

    return np.asarray(parts, dtype=np.float32)


def _infer_dims(jsonl_paths: Sequence[str]) -> Tuple[int, int]:
    for p in jsonl_paths:
        for line in open(p):
            sf = json.loads(line).get("state_features", {})
            nL = len(sf.get("B", []) or [])
            nR = len(sf.get("battery", []) or [])
            if nL and nR:
                return nL, nR

    raise RuntimeError(
        "Could not infer |L|, |R| from state_features. "
        "Was the data collected with the v3 logger?"
    )


# --------------------------------------------------------------------------- #
# Target reconstruction: discounted future stockout per epoch
# --------------------------------------------------------------------------- #

def _episode_targets(records: List[dict], gamma: float, K: float) -> List[float]:
    """records: list of one episode's records in epoch order. Returns G_n list."""
    n = len(records)

    t = [
        float(
            r.get(
                "decision_time_s",
                r.get("state_features", {}).get("epoch_time", 0.0),
            )
        )
        for r in records
    ]

    incr = [0.0] * n

    for m in range(n):
        B = records[m].get("state_features", {}).get("B", []) or []
        n_out = sum(1 for b in B if float(b) <= 0.0)

        dt = (t[m + 1] - t[m]) if m + 1 < n else K
        incr[m] = max(0.0, dt) / 60.0 * n_out

    G = [0.0] * n

    for m in range(n - 1, -1, -1):
        if m == n - 1:
            G[m] = incr[m]
        else:
            dt = t[m + 1] - t[m]
            disc = gamma ** (max(0.0, dt) / K)
            G[m] = incr[m] + disc * G[m + 1]

    return G


def _load_dataset(
    jsonl_paths: Sequence[str],
    gamma: float,
    K: float,
    nL: int,
    nR: int,
):
    """Returns list of (episode_id, X[ne,D], y[ne])."""
    by_ep: Dict[int, List[dict]] = {}

    for p in sorted(jsonl_paths):
        for line in open(p):
            r = json.loads(line)
            by_ep.setdefault(r["episode_id"], []).append(r)

    episodes = []

    for eid, recs in by_ep.items():
        recs.sort(key=lambda r: r.get("epoch_index", r.get("epoch_id", 0)))

        G = _episode_targets(recs, gamma, K)

        X = np.stack(
            [
                _state_vector(r.get("state_features", {}), nL, nR)
                for r in recs
            ]
        )

        y = np.asarray(G, dtype=np.float32)

        episodes.append((eid, X, y))

    return episodes


# --------------------------------------------------------------------------- #
# Critic network
# --------------------------------------------------------------------------- #

class Critic(nn.Module):
    def __init__(self, in_dim: int, hidden: int = 128, depth: int = 3):
        super().__init__()

        layers = []
        d = in_dim

        for _ in range(depth):
            layers += [nn.Linear(d, hidden), nn.GELU()]
            d = hidden

        layers += [nn.Linear(d, 1)]

        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).squeeze(-1)


class _DS(Dataset):
    def __init__(self, X, y):
        self.X = torch.from_numpy(X)
        self.y = torch.from_numpy(y)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return self.X[i], self.y[i]


# --------------------------------------------------------------------------- #
# Training
# --------------------------------------------------------------------------- #

def train_critic(
    jsonl_paths,
    out_dir,
    *,
    gamma=0.995,
    K=5.0,
    hidden=128,
    depth=3,
    epochs=30,
    lr=1e-3,
    batch=256,
    val_frac=0.2,
    device="cpu",
    seed=0,
):
    os.makedirs(out_dir, exist_ok=True)

    nL, nR = _infer_dims(jsonl_paths)

    eps = _load_dataset(jsonl_paths, gamma, K, nL, nR)

    if len(eps) < 2:
        raise RuntimeError(f"Need >=2 episodes, found {len(eps)}.")

    rng = np.random.default_rng(seed)

    order = list(range(len(eps)))
    rng.shuffle(order)

    n_val = max(1, int(len(eps) * val_frac))
    val_ids = set(order[:n_val])

    Xtr = np.concatenate(
        [eps[i][1] for i in range(len(eps)) if i not in val_ids]
    )
    ytr = np.concatenate(
        [eps[i][2] for i in range(len(eps)) if i not in val_ids]
    )

    Xva = np.concatenate(
        [eps[i][1] for i in range(len(eps)) if i in val_ids]
    )
    yva = np.concatenate(
        [eps[i][2] for i in range(len(eps)) if i in val_ids]
    )

    s_mean = Xtr.mean(0)
    s_std = Xtr.std(0)
    s_std[s_std < 1e-6] = 1.0

    t_mean = float(ytr.mean())
    t_std = float(ytr.std()) or 1.0

    idx = CriticIndex(
        nL=nL,
        nR=nR,
        state_mean=s_mean.tolist(),
        state_std=s_std.tolist(),
        target_mean=t_mean,
        target_std=t_std,
        gamma=gamma,
        K=K,
    )

    idx.save(os.path.join(out_dir, "critic_index.json"))

    def norm(X, y):
        return ((X - s_mean) / s_std).astype(np.float32), (
            (y - t_mean) / t_std
        ).astype(np.float32)

    Xtr_n, ytr_n = norm(Xtr, ytr)
    Xva_n, yva_n = norm(Xva, yva)

    tr = DataLoader(_DS(Xtr_n, ytr_n), batch_size=batch, shuffle=True)

    net = Critic(Xtr.shape[1], hidden, depth).to(device)

    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-5)
    lossf = nn.SmoothL1Loss()

    Xva_t = torch.from_numpy(Xva_n).to(device)
    yva_t = torch.from_numpy(yva_n).to(device)

    best = float("inf")
    hist = []

    for ep in range(epochs):
        net.train()

        tot = 0.0

        for xb, yb in tr:
            xb, yb = xb.to(device), yb.to(device)

            pred = net(xb)
            loss = lossf(pred, yb)

            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(net.parameters(), 1.0)
            opt.step()

            tot += loss.item() * len(yb)

        net.eval()

        with torch.no_grad():
            pv = net(Xva_t)

            vmse = float(((pv - yva_t) ** 2).mean())

            pv_o = pv.cpu().numpy() * t_std + t_mean

            ss_res = float(((pv_o - yva) ** 2).sum())
            ss_tot = float(((yva - yva.mean()) ** 2).sum()) or 1.0

            r2 = 1.0 - ss_res / ss_tot

        hist.append(
            {
                "epoch": ep,
                "train": tot / len(ytr),
                "val_mse_norm": vmse,
                "val_R2": r2,
            }
        )

        print(
            f"[f2] ep {ep:02d}  train={tot / len(ytr):.4f}  "
            f"val_mse(norm)={vmse:.4f}  val_R2={r2:.4f}"
        )

        if vmse < best:
            best = vmse

            torch.save(
                {
                    "model_state": net.state_dict(),
                    "config": {
                        "in_dim": Xtr.shape[1],
                        "hidden": hidden,
                        "depth": depth,
                    },
                },
                os.path.join(out_dir, "critic_best.pt"),
            )

    torch.save(
        {
            "model_state": net.state_dict(),
            "config": {
                "in_dim": Xtr.shape[1],
                "hidden": hidden,
                "depth": depth,
            },
        },
        os.path.join(out_dir, "critic_final.pt"),
    )

    json.dump(hist, open(os.path.join(out_dir, "history.json"), "w"), indent=2)

    print(
        f"[f2] done. best val_mse(norm)={best:.4f}  "
        f"final val_R2={hist[-1]['val_R2']:.4f}"
    )

    return hist


# --------------------------------------------------------------------------- #
# Runtime inference wrapper
# --------------------------------------------------------------------------- #

class TerminalValueRuntime:
    """
    Runtime inference wrapper for the F2 terminal-value critic.

    It loads:
      - critic_best.pt
      - critic_index.json

    and returns F2 terminal-value coefficients for feasible MILP candidates.
    """

    def __init__(
        self,
        ckpt_path: str,
        index_path: str,
        eta: float = 1.0,
        device: str = "cpu",
    ):
        self.eta = float(eta)
        self.device = torch.device(device)

        self.index = CriticIndex.load(index_path)

        ckpt = torch.load(ckpt_path, map_location=self.device)

        cfg = ckpt.get("config", {})

        in_dim = cfg.get("in_dim")
        hidden = cfg.get("hidden", 128)
        depth = cfg.get("depth", 3)

        if in_dim is None:
            raise ValueError("critic checkpoint does not contain config['in_dim'].")

        self.nL = int(self.index.nL)
        self.nR = int(self.index.nR)

        self.net = Critic(in_dim=in_dim, hidden=hidden, depth=depth).to(self.device)
        self.net.load_state_dict(ckpt["model_state"])
        self.net.eval()

        # IMPORTANT:
        # These normalization statistics are saved in critic_index.json,
        # not in critic_best.pt.
        self.x_mean = torch.tensor(
            self.index.state_mean,
            dtype=torch.float32,
            device=self.device,
        )

        self.x_std = torch.tensor(
            self.index.state_std,
            dtype=torch.float32,
            device=self.device,
        )

        self.y_mean = float(self.index.target_mean)
        self.y_std = float(self.index.target_std)

    @torch.no_grad()
    def value(self, state_features: dict) -> float:
        x = _state_vector(state_features, self.nL, self.nR).astype("float32")

        xt = torch.tensor(x, dtype=torch.float32, device=self.device)

        xt = (xt - self.x_mean) / (self.x_std + 1e-8)

        pred_norm = self.net(xt.unsqueeze(0)).squeeze().item()

        pred = self.y_mean + self.y_std * pred_norm

        return self.eta * float(pred)

    def __call__(self, state_features: dict) -> float:
        return self.value(state_features)

    def _extract_state_features(self, state, sim=None):
        """
        Extract or reconstruct the state_features dictionary required by the F2 critic.

        The critic was trained on JSONL records containing fields such as:
            B, S, hat_lambda, hat_T_so, battery, tau_free,
            congestion_norm, n_lines_critical, min_T_so, mean_buffer, epoch_time

        This method first tries to retrieve an existing feature dictionary.
        If none exists, it reconstructs a compatible dictionary from common
        state/simulator fields.
        """

        def _as_list(x):
            if x is None:
                return None

            if isinstance(x, list):
                return x

            if isinstance(x, tuple):
                return list(x)

            if hasattr(x, "tolist"):
                try:
                    return x.tolist()
                except Exception:
                    pass

            if isinstance(x, dict):
                try:
                    keys = sorted(x.keys())
                    return [x[k] for k in keys]
                except Exception:
                    return list(x.values())

            try:
                return list(x)
            except Exception:
                return None

        def _get_attr(obj, names):
            if obj is None:
                return None

            for name in names:
                if not hasattr(obj, name):
                    continue

                val = getattr(obj, name)

                if callable(val):
                    try:
                        val = val()
                    except TypeError:
                        continue
                    except Exception:
                        continue

                return val

            return None

        def _numeric_list_from_objects(container, names):
            if container is None:
                return None

            items = container.values() if isinstance(container, dict) else container

            out = []

            try:
                for item in items:
                    val = None

                    if isinstance(item, dict):
                        for k in names:
                            if k in item:
                                val = item[k]
                                break
                    else:
                        val = _get_attr(item, names)

                    if val is not None:
                        try:
                            out.append(float(val))
                        except Exception:
                            pass
            except Exception:
                return None

            return out if out else None

        def _vector_from_sources(sources, names):
            for obj in sources:
                raw = _get_attr(obj, names)
                arr = _as_list(raw)
                if arr is not None:
                    return arr
            return None

        def _fix_len(arr, length, fill):
            if arr is None:
                arr = []

            arr = list(arr)[:length]

            while len(arr) < length:
                arr.append(fill)

            out = []

            for x in arr:
                try:
                    out.append(float(x))
                except Exception:
                    out.append(float(fill))

            return out

        # ------------------------------------------------------------------ #
        # 1. Already a dictionary of features
        # ------------------------------------------------------------------ #
        if isinstance(state, dict):
            if "state_features" in state and isinstance(state["state_features"], dict):
                return state["state_features"]

            if "B" in state and "battery" in state:
                return state

        # ------------------------------------------------------------------ #
        # 2. State object directly stores state_features
        # ------------------------------------------------------------------ #
        if hasattr(state, "state_features"):
            sf = getattr(state, "state_features")

            if callable(sf):
                try:
                    sf = sf()
                except Exception:
                    sf = None

            if isinstance(sf, dict):
                return sf

        # ------------------------------------------------------------------ #
        # 3. Simulator directly stores or builds state_features
        # ------------------------------------------------------------------ #
        if sim is not None:
            for name in [
                "state_features",
                "get_state_features",
                "_get_state_features",
                "build_state_features",
                "_build_state_features",
                "extract_state_features",
                "_extract_state_features",
            ]:
                obj = getattr(sim, name, None)

                if isinstance(obj, dict):
                    return obj

                if callable(obj):
                    try:
                        sf = obj()
                        if isinstance(sf, dict):
                            return sf
                    except Exception:
                        pass

        # ------------------------------------------------------------------ #
        # 4. Try helper functions from baselines._milp_logger, if available
        # ------------------------------------------------------------------ #
        try:
            import baselines._milp_logger as ml

            for name in [
                "build_state_features",
                "_build_state_features",
                "extract_state_features",
                "_extract_state_features",
                "state_features",
                "get_state_features",
            ]:
                fn = getattr(ml, name, None)

                if not callable(fn):
                    continue

                for args in [
                    (state, sim),
                    (sim, state),
                    (state,),
                    (sim,),
                ]:
                    try:
                        sf = fn(*args)
                        if isinstance(sf, dict):
                            return sf
                    except TypeError:
                        pass
                    except Exception:
                        pass

        except Exception:
            pass

        # ------------------------------------------------------------------ #
        # 5. Reconstruct from common live state/sim fields
        # ------------------------------------------------------------------ #
        sources = [state, sim]

        B = _vector_from_sources(
            sources,
            [
                "B",
                "buffers",
                "buffer",
                "line_buffers",
                "line_buffer",
                "buffer_levels",
                "line_buffer_levels",
                "line_inventory",
                "line_inventories",
                "line_stock",
                "line_stocks",
            ],
        )

        S = _vector_from_sources(
            sources,
            [
                "S",
                "storage",
                "storages",
                "storage_levels",
                "storage_inventory",
                "storage_inventories",
                "column_stock",
                "column_stocks",
                "inventory",
                "inventories",
            ],
        )

        hat_lambda = _vector_from_sources(
            sources,
            [
                "hat_lambda",
                "lambda_hat",
                "demand_rate",
                "demand_rates",
                "line_demand_rate",
                "line_demand_rates",
                "forecast_demand",
                "forecast_demands",
            ],
        )

        hat_T_so = _vector_from_sources(
            sources,
            [
                "hat_T_so",
                "T_so",
                "time_to_stockout",
                "times_to_stockout",
                "line_time_to_stockout",
                "line_times_to_stockout",
            ],
        )

        battery = _vector_from_sources(
            sources,
            [
                "battery",
                "batteries",
                "robot_battery",
                "robot_batteries",
                "battery_levels",
                "robot_battery_levels",
            ],
        )

        if battery is None:
            for obj in sources:
                robots = _get_attr(
                    obj,
                    [
                        "robots",
                        "robot_states",
                        "amrs",
                        "resources",
                    ],
                )

                battery = _numeric_list_from_objects(
                    robots,
                    [
                        "battery",
                        "battery_level",
                        "soc",
                        "charge",
                        "energy",
                    ],
                )

                if battery is not None:
                    break

        tau_free = _vector_from_sources(
            sources,
            [
                "tau_free",
                "robot_tau_free",
                "robot_free_time",
                "robot_free_times",
                "free_at",
                "available_at",
                "availability_time",
                "availability_times",
            ],
        )

        if tau_free is None:
            for obj in sources:
                robots = _get_attr(
                    obj,
                    [
                        "robots",
                        "robot_states",
                        "amrs",
                        "resources",
                    ],
                )

                tau_free = _numeric_list_from_objects(
                    robots,
                    [
                        "tau_free",
                        "free_at",
                        "available_at",
                        "availability_time",
                        "busy_until",
                    ],
                )

                if tau_free is not None:
                    break

        B = _fix_len(B, self.nL, 0.0)
        S = _fix_len(S, self.nL, 0.0)
        hat_lambda = _fix_len(hat_lambda, self.nL, 0.0)
        hat_T_so = _fix_len(hat_T_so, self.nL, 0.0)
        battery = _fix_len(battery, self.nR, 1.0)
        tau_free = _fix_len(tau_free, self.nR, 0.0)

        epoch_time = None
        epoch_index = None
        congestion_norm = None
        n_lines_critical = None
        min_T_so = None
        mean_buffer = None

        for obj in sources:
            if obj is None:
                continue

            if epoch_time is None:
                epoch_time = _get_attr(
                    obj,
                    [
                        "epoch_time",
                        "now_seconds",
                        "t_now",
                        "time",
                        "time_s",
                        "current_time",
                        "current_time_s",
                        "clock",
                    ],
                )

            if epoch_index is None:
                epoch_index = _get_attr(
                    obj,
                    [
                        "epoch_index",
                        "review_index",
                        "decision_index",
                        "step",
                        "step_index",
                        "k",
                    ],
                )

            if congestion_norm is None:
                congestion_norm = _get_attr(
                    obj,
                    [
                        "congestion_norm",
                        "congestion",
                        "normalized_congestion",
                    ],
                )

            if n_lines_critical is None:
                n_lines_critical = _get_attr(
                    obj,
                    [
                        "n_lines_critical",
                        "num_lines_critical",
                        "critical_lines",
                    ],
                )

            if min_T_so is None:
                min_T_so = _get_attr(
                    obj,
                    [
                        "min_T_so",
                        "min_time_to_stockout",
                        "minimum_time_to_stockout",
                    ],
                )

            if mean_buffer is None:
                mean_buffer = _get_attr(
                    obj,
                    [
                        "mean_buffer",
                        "avg_buffer",
                        "average_buffer",
                    ],
                )

        try:
            epoch_time = float(epoch_time) if epoch_time is not None else 0.0
        except Exception:
            epoch_time = 0.0

        try:
            epoch_index = int(epoch_index) if epoch_index is not None else 0
        except Exception:
            epoch_index = 0

        try:
            congestion_norm = (
                float(congestion_norm) if congestion_norm is not None else 0.0
            )
        except Exception:
            congestion_norm = 0.0

        if n_lines_critical is None:
            n_lines_critical = sum(1 for b in B if float(b) <= 0.0)

        try:
            n_lines_critical = float(n_lines_critical)
        except Exception:
            n_lines_critical = 0.0

        if min_T_so is None:
            positive_tso = [float(x) for x in hat_T_so if float(x) > 0.0]
            min_T_so = min(positive_tso) if positive_tso else 0.0

        try:
            min_T_so = float(min_T_so)
        except Exception:
            min_T_so = 0.0

        if mean_buffer is None:
            mean_buffer = float(np.mean(B)) if B else 0.0

        try:
            mean_buffer = float(mean_buffer)
        except Exception:
            mean_buffer = 0.0

        sf = {
            "B": B,
            "S": S,
            "hat_lambda": hat_lambda,
            "hat_T_so": hat_T_so,
            "battery": battery,
            "tau_free": tau_free,
            "congestion_norm": congestion_norm,
            "n_lines_critical": n_lines_critical,
            "min_T_so": min_T_so,
            "mean_buffer": mean_buffer,
            "epoch_index": epoch_index,
            "epoch_time": epoch_time,
        }

        return sf

    def _get_candidate_location(self, cand):
        """
        Infer destination line/location index from a feasible candidate.
        """

        def _get(obj, names):
            if obj is None:
                return None
            if isinstance(obj, dict):
                for n in names:
                    if n in obj:
                        return obj[n]
                return None
            for n in names:
                if hasattr(obj, n):
                    return getattr(obj, n)
            return None

        def _to_int_or_none(x):
            try:
                return int(x)
            except Exception:
                return None

        if isinstance(cand, (tuple, list)):
            if len(cand) >= 2:
                return _to_int_or_none(cand[1])
            return None

        # Direct fields.
        loc = _get(
            cand,
            [
                "lid",
                "line_id",
                "line",
                "loc",
                "location",
                "location_id",
                "j",
            ],
        )

        if loc is not None:
            return _to_int_or_none(loc)

        # Nested job object.
        job = _get(cand, ["job", "jobj", "task"])

        loc = _get(
            job,
            [
                "lid",
                "line_id",
                "line",
                "loc",
                "location",
                "location_id",
            ],
        )

        return _to_int_or_none(loc)

    def _candidate_key(self, cand):
        """
        Return the exact key expected by TacticalMILP.score_field.

        Existing RL controller uses keys of the form:
            (rid, lid, uid)

        This function tries to recover that format from FeasibleTriple,
        tuple/list candidates, dictionaries, or nested job objects.
        """

        def _get(obj, names):
            if obj is None:
                return None
            if isinstance(obj, dict):
                for n in names:
                    if n in obj:
                        return obj[n]
                return None
            for n in names:
                if hasattr(obj, n):
                    return getattr(obj, n)
            return None

        def _to_int(x):
            try:
                return int(x)
            except Exception:
                return x

        # Already a tuple/list.
        if isinstance(cand, (tuple, list)):
            # If already (rid, lid, uid), preserve it.
            if len(cand) >= 3:
                return (_to_int(cand[0]), _to_int(cand[1]), _to_int(cand[2]))
            return tuple(cand)

        # Dictionary form.
        if isinstance(cand, dict):
            if "key" in cand:
                return cand["key"]

            rid = _get(cand, ["rid", "robot_id", "robot", "r"])
            lid = _get(cand, ["lid", "line_id", "line", "loc", "location", "j"])
            uid = _get(cand, ["uid", "tote_id", "job_id", "job", "u"])

            if rid is not None and lid is not None and uid is not None:
                return (_to_int(rid), _to_int(lid), _to_int(uid))

            return cand

        # Object form, likely FeasibleTriple.
        rid = _get(cand, ["rid", "robot_id", "robot", "r"])

        # Candidate may directly contain line/tote fields.
        lid = _get(cand, ["lid", "line_id", "line", "loc", "location", "j"])
        uid = _get(cand, ["uid", "tote_id", "job_id", "u"])

        # Or candidate may contain a nested job object.
        job = _get(cand, ["job", "jobj", "task"])

        if lid is None and job is not None:
            lid = _get(job, ["lid", "line_id", "line", "loc", "location"])

        if uid is None and job is not None:
            uid = _get(job, ["uid", "tote_id", "job_id", "id"])

        if rid is not None and lid is not None and uid is not None:
            return (_to_int(rid), _to_int(lid), _to_int(uid))

        # Fallback: preserve original object, but this may not match MILP key.
        return cand
    @torch.no_grad()
    def coefficients(self, state, feasible, sim=None):
        """
        Return one F2 score per feasible candidate.

        The score is a finite-difference estimate of the terminal-value gain from
        improving the candidate's destination line buffer.

        Since V predicts future stockout, lower V is better.

            gain = V(current state) - V(state after +1 buffer at destination)

        A positive gain means the candidate reduces predicted future stockout.
        """

        sf = self._extract_state_features(state, sim)

        base_value = self.value(sf)

        coeffs = {}

        for cand in feasible:
            key = self._candidate_key(cand)
            loc = self._get_candidate_location(cand)

            if loc is None:
                coeffs[key] = 0.0
                continue

            sf2 = {}

            for k, v in sf.items():
                if isinstance(v, list):
                    sf2[k] = list(v)
                else:
                    sf2[k] = v

            B = list(sf.get("B", []))

            if 0 <= loc < len(B):
                B[loc] = B[loc] + 1.0
                sf2["B"] = B

                try:
                    sf2["mean_buffer"] = float(np.mean(B)) if B else 0.0
                    sf2["n_lines_critical"] = float(
                        sum(1 for b in B if float(b) <= 0.0)
                    )
                except Exception:
                    pass

                new_value = self.value(sf2)

                coeffs[key] = float(base_value - new_value)

            else:
                coeffs[key] = 0.0

        return coeffs


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def _cli():
    ap = argparse.ArgumentParser()

    sub = ap.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train")

    t.add_argument("--jsonl", nargs="+", required=True)
    t.add_argument("--out-dir", required=True)
    t.add_argument("--gamma", type=float, default=0.995)
    t.add_argument("--K", type=float, default=5.0)
    t.add_argument("--epochs", type=int, default=30)
    t.add_argument("--hidden", type=int, default=128)
    t.add_argument("--depth", type=int, default=3)
    t.add_argument("--lr", type=float, default=1e-3)
    t.add_argument("--device", default="cpu")

    a = ap.parse_args()

    if a.cmd == "train":
        paths = []

        for pat in a.jsonl:
            if any(c in pat for c in "*?"):
                paths += sorted(glob.glob(pat))
            else:
                paths.append(pat)

        train_critic(
            paths,
            a.out_dir,
            gamma=a.gamma,
            K=a.K,
            epochs=a.epochs,
            hidden=a.hidden,
            depth=a.depth,
            lr=a.lr,
            device=a.device,
        )


if __name__ == "__main__":
    _cli()