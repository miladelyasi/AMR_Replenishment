"""
smoke_test.py
=============
End-to-end smoke test using SYNTHETIC data. Validates that logger schema,
feature index, model, training loop, and integration glue are wired up
correctly before any real simulator data is collected.

Run:
    python -m pruner.smoke_test

What it does:
    1) Generates 500 synthetic epochs mimicking the manuscript's regime:
       ~10 robots, ~60 jobs, ~600 pairs per epoch, ground-truth label is a
       hand-crafted ranking that matches what an actual MILP would pick.
    2) Builds the feature index.
    3) Trains the pruner for 5 epochs on CPU.
    4) Projects latency savings.
    5) Verifies coverage@2|R| beats the trivial random baseline.
    6) Tests the integration wrapper (LearnedPruner + urgency floor).

Coverage should reach >0.85 on the synthetic data within a few training
epochs. If it doesn't, something is wrong with feature normalization,
the model, or the loss.
"""

from __future__ import annotations
import json
import os
import shutil
import tempfile
import numpy as np
import torch
import random

from pruner.logger import EpochLogger
from pruner.pruner import (
    build_index, train_pruner, project_latency_savings, FeatureIndex,
)
from pruner.integration import LearnedPruner, UrgencyGreedyPruner


class _FakeVar:
    """Minimal stand-in for gurobipy.Var.X, used only by the logger in tests."""
    def __init__(self, value: float):
        self.X = float(value)


class _FakeModel:
    """Stand-in for a solved gurobipy.Model with a few attributes."""
    def __init__(self, n_binaries: int = 36000, solve_ms: float = 35.0,
                 obj: float = 1000.0, gap: float = 0.0, status: int = 2):
        self.Runtime = solve_ms / 1000.0
        self.ObjVal = obj
        self.MIPGap = gap
        self.NumBinVars = n_binaries
        self.SolCount = 1
        self.Status = status


def _gen_synthetic_epoch(rng: random.Random, np_rng: np.random.Generator,
                          ep_id: int, n: int):
    """Generate one synthetic decision epoch with hand-tuned 'optimal' labels."""
    n_robots = rng.randint(8, 12)
    n_lines = rng.randint(4, 6)
    n_totes = rng.randint(40, 80)
    # robots
    robots = {}
    for r in range(n_robots):
        robots[f"R{r}"] = {
            "pos_x": float(np_rng.uniform(0, 20)),
            "pos_y": float(np_rng.uniform(0, 20)),
            "battery": float(np_rng.uniform(0.3, 1.0)),
            "tau_free": float(np_rng.exponential(2.0)),
            "has_commitment": int(np_rng.uniform() < 0.2),
        }
    # jobs - a tote-line pair with one service mode
    jobs = {}
    line_t_so = {f"L{l}": float(np_rng.uniform(20, 400)) for l in range(n_lines)}
    line_lambda = {f"L{l}": float(np_rng.uniform(0.01, 0.05)) for l in range(n_lines)}
    line_B = {f"L{l}": float(np_rng.uniform(4, 12)) for l in range(n_lines)}
    for u in range(n_totes):
        ell = f"L{rng.randint(0, n_lines-1)}"
        m = "D" if np_rng.uniform() < 0.7 else "E"
        depth = int(np_rng.integers(0, 5)) if m == "D" else int(np_rng.integers(2, 9))
        access_class = 1 if m == "D" else 2
        jid = f"J{u}"
        jobs[jid] = {
            "line_id_hash": float(hash(ell) % 1000) / 1000.0,
            "T_so": line_t_so[ell],
            "B_line": line_B[ell],
            "lambda_line": line_lambda[ell],
            "depth": depth,
            "access_class": access_class,
            "phi": float(np_rng.uniform(0.5, 2.0)),
            "is_excavation": int(m == "E"),
        }

    # candidate pairs: all robots x all jobs
    candidate_pairs = [(r, j) for r in robots for j in jobs]
    pair_features = {}
    for (r, j) in candidate_pairs:
        rx, ry = robots[r]["pos_x"], robots[r]["pos_y"]
        # synthetic tote position consistent across jobs of same id
        np_rng_local = np.random.default_rng(hash(j) & 0xFFFF)
        ux, uy = float(np_rng_local.uniform(0, 20)), float(np_rng_local.uniform(0, 20))
        tau_ru = ((rx - ux) ** 2 + (ry - uy) ** 2) ** 0.5 / 1.2
        tau_ul = float(np_rng_local.uniform(2, 10))
        pair_features[(r, j)] = {
            "tau_xy_ru": tau_ru,
            "tau_xy_ul": tau_ul,
            "expected_lateness": max(0.0, tau_ru + tau_ul + 6.0 + 4.0 * jobs[j]["depth"]
                                     - jobs[j]["T_so"]),
            "congestion_exposure": float(np_rng.uniform(0, 1)),
            "energy_cost": tau_ru + tau_ul + 0.5 * jobs[j]["depth"],
        }

    # Build a synthetic 'optimal' label rule:
    #   For each robot, pick the job with the smallest
    #     T_so - (tau_ru + tau_ul + 6 + 4*depth)  (i.e. tightest deadline meeting)
    # That is roughly what the actual MILP would prefer.
    assignments = {}
    for r in robots:
        best_j, best_score = None, float("inf")
        for j in jobs:
            pf = pair_features[(r, j)]
            score = jobs[j]["T_so"] - (pf["tau_xy_ru"] + pf["tau_xy_ul"]
                                        + 6.0 + 4.0 * jobs[j]["depth"])
            if score < best_score:
                best_score = score
                best_j = j
        # don't assign every robot every epoch (mimic single-dispatch with idle robots)
        if np_rng.uniform() < 0.75:
            assignments[r] = best_j

    # Create fake x_vars and v_vars
    x_vars = {}
    for r in robots:
        for j in jobs:
            for q in range(3):  # only a few slots in synthetic data
                x_vars[(r, j, q)] = _FakeVar(0.0)
    for r, j in assignments.items():
        x_vars[(r, j, 0)] = _FakeVar(1.0)
    v_vars = {j: _FakeVar(1.0 if j in assignments.values() else 0.0) for j in jobs}

    global_features = {
        "n_lines_at_risk": float(sum(1 for v in line_t_so.values() if v < 60)),
        "n_idle_robots": float(sum(1 for r in robots if robots[r]["has_commitment"] == 0)),
        "avg_congestion": float(np_rng.uniform(0.1, 0.6)),
        "time_in_episode_s": float(n) * 5.0,
    }

    return {
        "ep_id": ep_id, "epoch_id": n, "decision_time": float(n) * 5.0,
        "robots": robots, "jobs": jobs,
        "candidate_pairs": candidate_pairs, "pair_features": pair_features,
        "global_features": global_features,
        "x_vars": x_vars, "v_vars": v_vars,
        "model": _FakeModel(n_binaries=len(candidate_pairs) * 3, solve_ms=35.0),
    }


def run_smoke():
    tmpdir = tempfile.mkdtemp(prefix="pruner_smoke_")
    try:
        jsonl_path = os.path.join(tmpdir, "synthetic.jsonl")
        rng = random.Random(0)
        np_rng = np.random.default_rng(0)
        print(f"[smoke] writing synthetic rollouts to {jsonl_path}")
        with EpochLogger(jsonl_path) as logger:
            for ep in range(20):
                for n in range(25):
                    rec = _gen_synthetic_epoch(rng, np_rng, ep, n)
                    logger.log_epoch(
                        episode_id=rec["ep_id"], epoch_id=rec["epoch_id"],
                        decision_time_s=rec["decision_time"],
                        state={}, candidate_pairs=rec["candidate_pairs"],
                        pair_features=rec["pair_features"],
                        milp_model=rec["model"],
                        x_vars=rec["x_vars"], v_vars=rec["v_vars"],
                        global_features=rec["global_features"],
                        robot_features=rec["robots"], job_features=rec["jobs"],
                    )

        # 1) build index
        print("[smoke] building feature index")
        idx_path = os.path.join(tmpdir, "feature_index.json")
        idx = build_index([jsonl_path], idx_path)
        print(f"[smoke] index: |g|={len(idx.global_keys)} |r|={len(idx.robot_keys)} "
              f"|j|={len(idx.job_keys)} |p|={len(idx.pair_keys)}")

        # 2) train (small)
        print("[smoke] training pruner (5 epochs, CPU)")
        out_dir = os.path.join(tmpdir, "runs")
        train_pruner([jsonl_path], out_dir, epochs=5, batch_size=8,
                     lr=1e-3, hidden=64, depth=3, device="cpu")

        # 3) project latency
        print("[smoke] projecting latency savings")
        proj = project_latency_savings(
            [jsonl_path],
            os.path.join(out_dir, "pruner_best.pt"),
            idx_path,
        )
        print(json.dumps(proj, indent=2))

        # 4) test integration wrapper
        print("[smoke] testing integration wrapper")
        pruner = LearnedPruner.from_checkpoint(
            os.path.join(out_dir, "pruner_best.pt"),
            idx_path, k=20, T_crit_seconds=30.0,
        )
        # build one fresh epoch and call prune()
        rec = _gen_synthetic_epoch(rng, np_rng, 99, 0)
        pruned = pruner.prune(rec["candidate_pairs"], rec["pair_features"],
                              rec["robots"], rec["jobs"], rec["global_features"])
        print(f"[smoke] learned pruner: |full|={len(rec['candidate_pairs'])} "
              f"-> |pruned|={len(pruned)}")

        baseline = UrgencyGreedyPruner(k=20, T_crit_seconds=30.0)
        b_pruned = baseline.prune(rec["candidate_pairs"], rec["pair_features"],
                                   rec["robots"], rec["jobs"], rec["global_features"])
        print(f"[smoke] urgency baseline: |full|={len(rec['candidate_pairs'])} "
              f"-> |pruned|={len(b_pruned)}")

        # 5) Pass/fail summary
        cov_2R = None
        with open(os.path.join(out_dir, "training_history.json")) as f:
            hist = json.load(f)
        if hist["test_coverage"]:
            cov_2R = hist["test_coverage"][-1].get("cov_at_2R")
        random_coverage_proxy = 2 * 10 / 600  # k=2R=20 random out of ~600
        ok = (cov_2R is not None) and (cov_2R > 3 * random_coverage_proxy)
        print(f"\n[smoke] final cov@2R = {cov_2R:.3f}  "
              f"(random baseline ~ {random_coverage_proxy:.3f})")
        print(f"[smoke] {'PASS' if ok else 'FAIL'} on synthetic data")
        return ok
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    ok = run_smoke()
    raise SystemExit(0 if ok else 1)
