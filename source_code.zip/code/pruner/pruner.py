"""
pruner.py
=========
Feature extraction, dataset, model, training loop, and evaluation for the
F1 top-k candidate pruner.

The pipeline assumes JSONL data produced by `pruner.logger.EpochLogger`.
It is intentionally self-contained: numpy + torch only, no Hydra/Lightning,
single file, ~600 lines.

Workflow:
    1) Collect: run MILPOnly with the logger attached -> rollouts/*.jsonl
    2) Build features: features.build_index(jsonl_paths) -> meta.json
    3) Train: train_pruner(...)
    4) Evaluate: eval_pruner(...) -> coverage@k, latency projection
    5) Integrate: load the trained pruner inside the simulator and run
       a pruned-MILP evaluation (see pruner_integration.py for the glue).
"""

from __future__ import annotations
import json
import math
import os
import time
import argparse
from collections import defaultdict
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader


# =========================================================================== #
# 1. Schema discovery + feature index
# =========================================================================== #

# The pruner does not hardcode feature names. It walks the JSONL once,
# collects the set of (numeric, scalar) keys that appear in pair-features /
# robot-features / job-features / global-features, and freezes that schema
# as the input dimensionality of the model. This way the user can add or drop
# features without touching code.


@dataclass
class FeatureIndex:
    """The frozen feature schema for one trained model."""
    global_keys: List[str]
    robot_keys: List[str]
    job_keys: List[str]
    pair_keys: List[str]
    # Standardization stats, computed on the training split only.
    global_mean: List[float]
    global_std: List[float]
    robot_mean: List[float]
    robot_std: List[float]
    job_mean: List[float]
    job_std: List[float]
    pair_mean: List[float]
    pair_std: List[float]

    def save(self, path: str):
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def load(cls, path: str) -> "FeatureIndex":
        with open(path) as f:
            return cls(**json.load(f))


def _iter_jsonl(paths: Sequence[str]):
    for p in paths:
        with open(p) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                yield json.loads(line)


def _is_number(v) -> bool:
    return isinstance(v, (int, float)) and not (isinstance(v, float) and math.isnan(v))


def discover_schema(paths: Sequence[str], max_records: int = 20000) -> Dict[str, List[str]]:
    """Walk the data once to discover the (sorted) set of numeric feature keys."""
    sets = {"global": set(), "robot": set(), "job": set(), "pair": set()}
    n = 0
    for rec in _iter_jsonl(paths):
        for k, v in rec.get("global_features", {}).items():
            if _is_number(v):
                sets["global"].add(k)
        for rfeats in rec.get("robots", {}).values():
            for k, v in rfeats.items():
                if _is_number(v):
                    sets["robot"].add(k)
        for jfeats in rec.get("jobs", {}).values():
            for k, v in jfeats.items():
                if _is_number(v):
                    sets["job"].add(k)
        for p in rec.get("pairs", []):
            for k, v in p.get("features", {}).items():
                if _is_number(v):
                    sets["pair"].add(k)
        n += 1
        if n >= max_records:
            break
    return {k: sorted(s) for k, s in sets.items()}


def _vec(d: Dict[str, float], keys: Sequence[str]) -> np.ndarray:
    return np.asarray([float(d.get(k, 0.0)) if _is_number(d.get(k)) else 0.0
                       for k in keys], dtype=np.float32)


def _stats(values: np.ndarray, eps: float = 1e-6) -> Tuple[np.ndarray, np.ndarray]:
    mean = values.mean(axis=0)
    std = values.std(axis=0)
    std = np.where(std < eps, 1.0, std)
    return mean.astype(np.float32), std.astype(np.float32)


def build_index(paths: Sequence[str], out_path: str, sample_for_stats: int = 50000) -> FeatureIndex:
    """Discover schema and compute standardization stats on a random subsample."""
    schema = discover_schema(paths)
    # collect a flat sample of vectors for each kind
    g, rfs, jfs, pfs = [], [], [], []
    rng = np.random.default_rng(0)
    for rec in _iter_jsonl(paths):
        if rng.random() < 0.1 or len(pfs) < sample_for_stats:
            g.append(_vec(rec.get("global_features", {}), schema["global"]))
            for rfeats in rec.get("robots", {}).values():
                rfs.append(_vec(rfeats, schema["robot"]))
            for jfeats in rec.get("jobs", {}).values():
                jfs.append(_vec(jfeats, schema["job"]))
            for p in rec.get("pairs", []):
                pfs.append(_vec(p.get("features", {}), schema["pair"]))
        if len(pfs) >= sample_for_stats:
            break
    g = np.stack(g) if g else np.zeros((1, max(1, len(schema["global"]))), dtype=np.float32)
    rfs = np.stack(rfs) if rfs else np.zeros((1, max(1, len(schema["robot"]))), dtype=np.float32)
    jfs = np.stack(jfs) if jfs else np.zeros((1, max(1, len(schema["job"]))), dtype=np.float32)
    pfs = np.stack(pfs) if pfs else np.zeros((1, max(1, len(schema["pair"]))), dtype=np.float32)
    gm, gs = _stats(g)
    rm, rs = _stats(rfs)
    jm, js = _stats(jfs)
    pm, ps = _stats(pfs)
    idx = FeatureIndex(
        global_keys=schema["global"], robot_keys=schema["robot"],
        job_keys=schema["job"], pair_keys=schema["pair"],
        global_mean=gm.tolist(), global_std=gs.tolist(),
        robot_mean=rm.tolist(), robot_std=rs.tolist(),
        job_mean=jm.tolist(), job_std=js.tolist(),
        pair_mean=pm.tolist(), pair_std=ps.tolist(),
    )
    idx.save(out_path)
    return idx


# =========================================================================== #
# 2. Dataset: one (epoch -> packed-pair-tensor) per __getitem__
# =========================================================================== #

class EpochDataset(Dataset):
    """
    Each item is a single epoch. The dataloader pads/concatenates epochs into a
    batch of (B, P_max, F) and emits an epoch_id_per_pair tensor so the loss
    can do per-epoch normalization.

    We pre-index the JSONL by recording byte offsets, so __getitem__ is O(1)
    seeks rather than O(line) reads.
    """

    def __init__(self, jsonl_paths: Sequence[str], index: FeatureIndex,
                 epoch_ids: Optional[Sequence[Tuple[int, int]]] = None):
        self.paths = list(jsonl_paths)
        self.index = index
        self.offsets: List[Tuple[int, int]] = []  # (file_idx, byte_offset)
        for fi, p in enumerate(self.paths):
            with open(p, "rb") as fh:
                while True:
                    off = fh.tell()
                    line = fh.readline()
                    if not line:
                        break
                    if line.strip():
                        self.offsets.append((fi, off))
        # epoch_ids is optional; used for deterministic train/test splits
        if epoch_ids is not None:
            keep = set(epoch_ids)
            kept = []
            for (fi, off) in self.offsets:
                with open(self.paths[fi]) as fh:
                    fh.seek(off)
                    rec = json.loads(fh.readline())
                if (rec["episode_id"], rec["epoch_id"]) in keep:
                    kept.append((fi, off))
            self.offsets = kept

    def __len__(self):
        return len(self.offsets)

    def __getitem__(self, i):
        fi, off = self.offsets[i]
        with open(self.paths[fi]) as fh:
            fh.seek(off)
            rec = json.loads(fh.readline())

        idx = self.index
        # standardize a vector
        def _std(v, mean, std):
            return (v - np.asarray(mean, dtype=np.float32)) / np.asarray(std, dtype=np.float32)

        gvec = _std(_vec(rec.get("global_features", {}), idx.global_keys),
                    idx.global_mean, idx.global_std)
        robots = rec.get("robots", {}) or {}
        jobs = rec.get("jobs", {}) or {}
        rvec = {r: _std(_vec(f, idx.robot_keys), idx.robot_mean, idx.robot_std)
                for r, f in robots.items()}
        jvec = {j: _std(_vec(f, idx.job_keys), idx.job_mean, idx.job_std)
                for j, f in jobs.items()}

        pairs = rec.get("pairs", [])
        P = len(pairs)
        Fg, Fr, Fj, Fp = (len(idx.global_keys), len(idx.robot_keys),
                          len(idx.job_keys), len(idx.pair_keys))
        feats = np.zeros((P, Fr + Fj + Fp + Fg), dtype=np.float32)
        labels = np.zeros((P,), dtype=np.float32)
        for k, p in enumerate(pairs):
            r_id, j_id = p["robot_id"], p["job_id"]
            rv = rvec.get(r_id, np.zeros(Fr, dtype=np.float32))
            jv = jvec.get(j_id, np.zeros(Fj, dtype=np.float32))
            pv = _std(_vec(p.get("features", {}), idx.pair_keys),
                      idx.pair_mean, idx.pair_std)
            feats[k] = np.concatenate([rv, jv, pv, gvec])
            labels[k] = float(p.get("selected", 0))

        return {
            "feats": torch.from_numpy(feats),
            "labels": torch.from_numpy(labels),
            "n_pairs": P,
            "episode_id": rec["episode_id"],
            "epoch_id": rec["epoch_id"],
            "milp_meta": rec.get("milp_meta", {}),
            "pair_ids": [(p["robot_id"], p["job_id"]) for p in pairs],
        }


def collate_epochs(batch):
    """Pack a variable-length batch of epochs into a single (B, P_max, F) tensor."""
    B = len(batch)
    P_max = max(item["n_pairs"] for item in batch) if batch else 1
    P_max = max(P_max, 1)
    F = batch[0]["feats"].shape[1] if batch else 1
    feats = torch.zeros((B, P_max, F), dtype=torch.float32)
    labels = torch.zeros((B, P_max), dtype=torch.float32)
    mask = torch.zeros((B, P_max), dtype=torch.bool)
    epoch_pos_label = torch.zeros((B,), dtype=torch.float32)
    for i, item in enumerate(batch):
        P = item["n_pairs"]
        if P > 0:
            feats[i, :P] = item["feats"]
            labels[i, :P] = item["labels"]
            mask[i, :P] = True
            epoch_pos_label[i] = item["labels"].sum()
    return {
        "feats": feats, "labels": labels, "mask": mask,
        "epoch_pos_label": epoch_pos_label,
        "n_pairs": torch.tensor([item["n_pairs"] for item in batch]),
        "items": batch,
    }


# =========================================================================== #
# 3. Model
# =========================================================================== #

class MLP(nn.Module):
    def __init__(self, dims: Sequence[int], dropout: float = 0.0):
        super().__init__()
        layers = []
        for k in range(len(dims) - 1):
            layers.append(nn.Linear(dims[k], dims[k + 1]))
            if k < len(dims) - 2:
                layers.append(nn.GELU())
                if dropout > 0:
                    layers.append(nn.Dropout(dropout))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class PrunerNetwork(nn.Module):
    """
    Shared-weight pairwise scorer.

    The input to forward() is the concatenated per-pair feature tensor
    [robot_feats | job_feats | pair_feats | global_feats], so the encoders
    work on a single flat representation. This matches the manuscript's
    f_phi^prune(s_n, r, j) interface with the smallest possible code surface.

    For papers we may later switch to separate robot/job encoders + a pair
    head (closer to the manuscript's f^R, f^J, f^pair decomposition); this
    version is the minimal viable architecture, kept deliberately simple so
    that the inductive bias used in evaluation can be cleanly compared with
    a non-learned baseline (e.g. urgency-greedy top-k).
    """

    def __init__(self, in_dim: int, hidden: int = 64, depth: int = 3, dropout: float = 0.1):
        super().__init__()
        dims = [in_dim] + [hidden] * depth + [1]
        self.net = MLP(dims, dropout=dropout)

    def forward(self, feats: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """
        feats: (B, P, F)
        mask:  (B, P) bool
        returns logits (B, P), with -inf in masked positions.
        """
        logits = self.net(feats).squeeze(-1)  # (B, P)
        logits = logits.masked_fill(~mask, float("-inf"))
        return logits


# =========================================================================== #
# 4. Loss + training
# =========================================================================== #

def per_epoch_bce_loss(logits: torch.Tensor, labels: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """
    BCE over valid pairs, then averaged within each epoch and over epochs.

    Per-epoch averaging ensures each decision epoch contributes equally to the
    loss regardless of |C_n|. Without this, large-|C_n| epochs would dominate
    training and bias the pruner toward low-pruning-rate behavior on small
    epochs.
    """
    # Replace -inf logits with 0 to make BCE numerically safe; mask will gate.
    safe_logits = torch.where(mask, logits, torch.zeros_like(logits))
    bce = F.binary_cross_entropy_with_logits(safe_logits, labels, reduction="none")
    bce = bce * mask.float()
    # per-epoch mean
    per_epoch = bce.sum(dim=1) / mask.float().sum(dim=1).clamp_min(1.0)
    return per_epoch.mean()


def listwise_softmax_ce(logits: torch.Tensor, labels: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """
    Optional alternative: per-epoch softmax cross-entropy treating the set of
    positive labels as a target distribution. Tends to give sharper rankings
    than pure BCE when positives are sparse. Not used by default.
    """
    logits = logits.masked_fill(~mask, float("-inf"))
    log_p = F.log_softmax(logits, dim=1)
    # target distribution: uniform over positives
    pos = labels * mask.float()
    pos_sum = pos.sum(dim=1, keepdim=True).clamp_min(1.0)
    target = pos / pos_sum
    # KL = -sum(target * log_p) up to const
    loss = -(target * log_p).sum(dim=1)
    return loss.mean()


def _train_test_split_by_episode(jsonl_paths: Sequence[str], test_frac: float = 0.2,
                                  seed: int = 0) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
    """Split at episode granularity so that no leakage occurs across epochs of the same episode."""
    episodes: Dict[int, List[int]] = defaultdict(list)
    for rec in _iter_jsonl(jsonl_paths):
        episodes[rec["episode_id"]].append(rec["epoch_id"])
    ep_ids = sorted(episodes.keys())
    rng = np.random.default_rng(seed)
    rng.shuffle(ep_ids)
    cut = int(len(ep_ids) * (1.0 - test_frac))
    train_eps, test_eps = set(ep_ids[:cut]), set(ep_ids[cut:])
    train_pairs = [(e, n) for e in train_eps for n in episodes[e]]
    test_pairs = [(e, n) for e in test_eps for n in episodes[e]]
    return train_pairs, test_pairs


def train_pruner(
    jsonl_paths: Sequence[str],
    out_dir: str,
    *,
    hidden: int = 64,
    depth: int = 3,
    dropout: float = 0.1,
    batch_size: int = 32,
    epochs: int = 20,
    lr: float = 1e-3,
    weight_decay: float = 1e-4,
    test_frac: float = 0.2,
    loss: str = "bce",  # "bce" or "listwise"
    device: str = "cpu",
    seed: int = 0,
    log_every: int = 50,
) -> Dict[str, float]:
    os.makedirs(out_dir, exist_ok=True)
    index_path = os.path.join(out_dir, "feature_index.json")
    if not os.path.exists(index_path):
        build_index(jsonl_paths, index_path)
    idx = FeatureIndex.load(index_path)

    train_ids, test_ids = _train_test_split_by_episode(jsonl_paths, test_frac, seed=seed)
    train_ds = EpochDataset(jsonl_paths, idx, epoch_ids=train_ids)
    test_ds = EpochDataset(jsonl_paths, idx, epoch_ids=test_ids)
    print(f"[train] train epochs: {len(train_ds)}, test epochs: {len(test_ds)}")

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              collate_fn=collate_epochs, num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False,
                             collate_fn=collate_epochs, num_workers=0)

    in_dim = len(idx.robot_keys) + len(idx.job_keys) + len(idx.pair_keys) + len(idx.global_keys)
    model = PrunerNetwork(in_dim=in_dim, hidden=hidden, depth=depth, dropout=dropout).to(device)
    optim = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    loss_fn = per_epoch_bce_loss if loss == "bce" else listwise_softmax_ce

    history = {"train_loss": [], "test_loss": [], "test_coverage": []}
    best_test = float("inf")
    for ep in range(epochs):
        model.train()
        t0 = time.time()
        running, count = 0.0, 0
        for step, batch in enumerate(train_loader):
            feats = batch["feats"].to(device)
            labels = batch["labels"].to(device)
            mask = batch["mask"].to(device)
            logits = model(feats, mask)
            loss_val = loss_fn(logits, labels, mask)
            optim.zero_grad()
            loss_val.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optim.step()
            running += float(loss_val.item())
            count += 1
            if step % log_every == 0:
                print(f"[train] ep {ep:02d} step {step:04d}  loss={loss_val.item():.4f}")
        train_loss = running / max(count, 1)

        test_loss, cov = _evaluate_loop(model, test_loader, loss_fn, device)
        history["train_loss"].append(train_loss)
        history["test_loss"].append(test_loss)
        history["test_coverage"].append(cov)
        print(f"[train] ep {ep:02d}  train={train_loss:.4f}  test={test_loss:.4f}  "
              f"cov@k=2|R| ={cov['cov_at_2R']:.3f}  cov@10={cov['cov_at_10']:.3f}  "
              f"cov@20={cov['cov_at_20']:.3f}  ({time.time()-t0:.1f}s)")

        if test_loss < best_test:
            best_test = test_loss
            torch.save({"model_state": model.state_dict(),
                        "config": {"hidden": hidden, "depth": depth, "in_dim": in_dim}},
                       os.path.join(out_dir, "pruner_best.pt"))

    # Always save final
    torch.save({"model_state": model.state_dict(),
                "config": {"hidden": hidden, "depth": depth, "in_dim": in_dim}},
               os.path.join(out_dir, "pruner_final.pt"))
    with open(os.path.join(out_dir, "training_history.json"), "w") as f:
        json.dump(history, f, indent=2)

    return history["test_coverage"][-1]


# =========================================================================== #
# 5. Evaluation: coverage@k + counterfactual latency projection
# =========================================================================== #

def _coverage_at_k(scores: np.ndarray, labels: np.ndarray, k: int) -> Tuple[int, int]:
    """For one epoch, return (n_positives_recovered, n_positives_total)."""
    n = len(scores)
    if n == 0:
        return 0, 0
    k_eff = min(k, n)
    top = np.argpartition(-scores, k_eff - 1)[:k_eff]
    recovered = int(labels[top].sum())
    total = int(labels.sum())
    return recovered, total


def _evaluate_loop(model: PrunerNetwork, loader: DataLoader, loss_fn, device: str) -> Tuple[float, Dict[str, float]]:
    """Compute test loss + coverage metrics at several k."""
    model.eval()
    running, count = 0.0, 0
    rec_at, tot_at = defaultdict(int), defaultdict(int)
    n_robots_per_epoch_sum = 0
    n_epochs = 0
    rec_at_2R, tot_at_2R = 0, 0
    with torch.no_grad():
        for batch in loader:
            feats = batch["feats"].to(device)
            labels = batch["labels"].to(device)
            mask = batch["mask"].to(device)
            logits = model(feats, mask)
            running += float(loss_fn(logits, labels, mask).item())
            count += 1
            scores = logits.detach().cpu().numpy()
            labs = labels.detach().cpu().numpy()
            msk = mask.detach().cpu().numpy()
            for i in range(scores.shape[0]):
                lab_i = labs[i][msk[i]]
                sc_i = scores[i][msk[i]]
                # number of robots in this epoch (positives is a lower bound)
                n_R = int(lab_i.sum())  # approximate: # selected pairs == # active robots committed
                # better proxy: count distinct robots that received commitments;
                # but in single-dispatch rolling approximation, len(positives) ~= n_R
                n_robots_per_epoch_sum += n_R
                n_epochs += 1
                # cov @ 2R (the policy's intended operating point)
                k_2R = max(4, 2 * max(n_R, 1))
                r, t = _coverage_at_k(sc_i, lab_i, k_2R)
                rec_at_2R += r
                tot_at_2R += t
                for k in (5, 10, 20, 40, 80):
                    r, t = _coverage_at_k(sc_i, lab_i, k)
                    rec_at[k] += r
                    tot_at[k] += t
    cov = {f"cov_at_{k}": (rec_at[k] / max(tot_at[k], 1)) for k in (5, 10, 20, 40, 80)}
    cov["cov_at_2R"] = rec_at_2R / max(tot_at_2R, 1)
    cov["avg_n_active_robots"] = n_robots_per_epoch_sum / max(n_epochs, 1)
    return running / max(count, 1), cov


def project_latency_savings(jsonl_paths: Sequence[str],
                            model_path: str,
                            feature_index_path: str,
                            k_values: Sequence[int] = (10, 20, 40, 80),
                            device: str = "cpu") -> Dict[str, Dict[str, float]]:
    """
    Estimate the *bound* on solve-time savings achievable by pruning.

    This is a projection, not a measurement: it uses the empirical relationship
    in the logged data between |C_n|, n_binaries, and milp_solve_time to predict
    the solve time for the pruned MILP at each k.

    The projection is deliberately conservative: we report (i) the linear
    extrapolation, (ii) the loglinear (cubic in n_binaries) extrapolation, and
    (iii) the median ratio observed in the data. The user runs the actual
    pruned-MILP evaluation in their simulator to get the ground truth.

    Returns a dict keyed by k with:
        coverage:          fraction of MILPOnly-optimal pairs in top-k
        binaries_ratio:    expected n_binaries(pruned) / n_binaries(full)
        latency_linear:    mean predicted solve time (ms) under linear scaling
        latency_cubic:     mean predicted solve time (ms) under cubic scaling
        latency_99p:       95th percentile under cubic scaling
    """
    idx = FeatureIndex.load(feature_index_path)
    ckpt = torch.load(model_path, map_location=device)
    in_dim = ckpt["config"]["in_dim"]
    model = PrunerNetwork(in_dim=in_dim, hidden=ckpt["config"]["hidden"],
                          depth=ckpt["config"]["depth"]).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    ds = EpochDataset(jsonl_paths, idx)
    loader = DataLoader(ds, batch_size=1, shuffle=False, collate_fn=collate_epochs)

    out: Dict[int, Dict[str, List[float]]] = {k: {"cov": [], "bin_ratio": [],
                                                    "lat_lin": [], "lat_cub": []}
                                                for k in k_values}
    with torch.no_grad():
        for batch in loader:
            feats = batch["feats"].to(device)
            labels = batch["labels"].to(device)
            mask = batch["mask"].to(device)
            logits = model(feats, mask).cpu().numpy()
            labs = labels.cpu().numpy()
            msk = mask.cpu().numpy()
            items = batch["items"]
            for i in range(logits.shape[0]):
                sc = logits[i][msk[i]]
                lab = labs[i][msk[i]]
                P = int(msk[i].sum())
                meta = items[i]["milp_meta"]
                n_bins_full = float(meta.get("n_binaries", P))
                solve_ms_full = float(meta.get("solve_time_ms", float("nan")))
                if not math.isfinite(solve_ms_full) or solve_ms_full <= 0:
                    continue
                for k in k_values:
                    if P == 0:
                        continue
                    k_eff = min(k, P)
                    top = np.argpartition(-sc, k_eff - 1)[:k_eff]
                    coverage = float(lab[top].sum()) / max(float(lab.sum()), 1.0)
                    # binaries scale with P linearly (each pair gets N slots)
                    bin_ratio = k_eff / P
                    # naive projections
                    lat_lin = solve_ms_full * bin_ratio
                    lat_cub = solve_ms_full * (bin_ratio ** 3)
                    out[k]["cov"].append(coverage)
                    out[k]["bin_ratio"].append(bin_ratio)
                    out[k]["lat_lin"].append(lat_lin)
                    out[k]["lat_cub"].append(lat_cub)

    summary = {}
    for k, d in out.items():
        if not d["cov"]:
            continue
        summary[k] = {
            "coverage": float(np.mean(d["cov"])),
            "binaries_ratio": float(np.mean(d["bin_ratio"])),
            "latency_linear_mean_ms": float(np.mean(d["lat_lin"])),
            "latency_cubic_mean_ms": float(np.mean(d["lat_cub"])),
            "latency_cubic_p95_ms": float(np.percentile(d["lat_cub"], 95)),
            "n_epochs": len(d["cov"]),
        }
    return summary


# =========================================================================== #
# 6. CLI entry points
# =========================================================================== #

def _cli():
    parser = argparse.ArgumentParser(description="F1 pruner pipeline")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_idx = sub.add_parser("build-index")
    p_idx.add_argument("--jsonl", nargs="+", required=True)
    p_idx.add_argument("--out", required=True)

    p_train = sub.add_parser("train")
    p_train.add_argument("--jsonl", nargs="+", required=True)
    p_train.add_argument("--out-dir", required=True)
    p_train.add_argument("--epochs", type=int, default=20)
    p_train.add_argument("--batch-size", type=int, default=32)
    p_train.add_argument("--lr", type=float, default=1e-3)
    p_train.add_argument("--loss", choices=["bce", "listwise"], default="bce")
    p_train.add_argument("--device", default="cpu")

    p_eval = sub.add_parser("project")
    p_eval.add_argument("--jsonl", nargs="+", required=True)
    p_eval.add_argument("--model", required=True)
    p_eval.add_argument("--index", required=True)
    p_eval.add_argument("--device", default="cpu")

    args = parser.parse_args()
    if args.cmd == "build-index":
        idx = build_index(args.jsonl, args.out)
        print(f"[build-index] wrote {args.out}: "
              f"|global|={len(idx.global_keys)} |robot|={len(idx.robot_keys)} "
              f"|job|={len(idx.job_keys)} |pair|={len(idx.pair_keys)}")
    elif args.cmd == "train":
        train_pruner(args.jsonl, args.out_dir, epochs=args.epochs,
                     batch_size=args.batch_size, lr=args.lr,
                     loss=args.loss, device=args.device)
    elif args.cmd == "project":
        result = project_latency_savings(args.jsonl, args.model, args.index, device=args.device)
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    _cli()
