"""
integration.py
==============
Glue code for using a trained pruner inside the simulator.

This is the only piece that touches the simulator's MILP construction.
The trained pruner is wrapped in a `LearnedPruner` object that, given the
same state/feature dicts the logger consumed, returns the top-k subset
plus the urgency-floor inclusions.

Usage in the simulator (pseudocode):

    from pruner.integration import LearnedPruner

    pruner = LearnedPruner.from_checkpoint(
        model_path="runs/pruner_best.pt",
        index_path="runs/feature_index.json",
        k=20,
        T_crit_seconds=30.0,  # urgency floor: any job with T_so <= T_crit is forced in
    )

    # ... at each decision epoch n, before constructing the MILP ...
    candidate_pairs_full = ...  # the full C_n list of (r, j) tuples
    pair_features = ...         # dict {(r,j): {...}}
    robot_features = ...        # dict {r: {...}}
    job_features = ...          # dict {j: {...}}  -- MUST include "T_so" if you want the urgency floor
    global_features = ...

    candidate_pairs_pruned = pruner.prune(
        candidate_pairs_full, pair_features, robot_features,
        job_features, global_features
    )

    # Build MILP over candidate_pairs_pruned instead of the full C_n.
"""

from __future__ import annotations
import json
import os
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch

# Imports from the same package
from .pruner import (
    FeatureIndex, PrunerNetwork, _vec, _is_number,
)


class LearnedPruner:
    """
    Wraps a trained pruner checkpoint and exposes a single .prune() call.
    Includes the hard urgency-floor rule from the manuscript:
        any pair (r, j) where j corresponds to a line with
        T_so <= T_crit is included regardless of the score.
    """

    def __init__(self, model: PrunerNetwork, index: FeatureIndex,
                 k: int, T_crit_seconds: float = 30.0,
                 t_so_key: str = "T_so", device: str = "cpu"):
        self.model = model.to(device).eval()
        self.index = index
        self.k = int(k)
        self.T_crit = float(T_crit_seconds)
        self.t_so_key = t_so_key
        self.device = device

    # ----------------------------------------------------------------- #
    @classmethod
    def from_checkpoint(cls, model_path: str, index_path: str,
                        k: int, T_crit_seconds: float = 30.0,
                        t_so_key: str = "T_so", device: str = "cpu"
                        ) -> "LearnedPruner":
        idx = FeatureIndex.load(index_path)
        ckpt = torch.load(model_path, map_location=device)
        cfg = ckpt["config"]
        model = PrunerNetwork(in_dim=cfg["in_dim"], hidden=cfg["hidden"],
                              depth=cfg["depth"])
        model.load_state_dict(ckpt["model_state"])
        return cls(model=model, index=idx, k=k,
                   T_crit_seconds=T_crit_seconds,
                   t_so_key=t_so_key, device=device)

    # ----------------------------------------------------------------- #
    def _std(self, v: np.ndarray, mean: Sequence[float], std: Sequence[float]) -> np.ndarray:
        return (v - np.asarray(mean, dtype=np.float32)) / np.asarray(std, dtype=np.float32)

    def _build_feats(self,
                     candidate_pairs: Sequence[Tuple[str, str]],
                     pair_features: Dict[Tuple[str, str], Dict[str, float]],
                     robot_features: Dict[str, Dict[str, float]],
                     job_features: Dict[str, Dict[str, float]],
                     global_features: Dict[str, float]) -> np.ndarray:
        idx = self.index
        gvec = self._std(_vec(global_features or {}, idx.global_keys),
                         idx.global_mean, idx.global_std)
        rvec = {r: self._std(_vec(f or {}, idx.robot_keys),
                             idx.robot_mean, idx.robot_std)
                for r, f in (robot_features or {}).items()}
        jvec = {j: self._std(_vec(f or {}, idx.job_keys),
                             idx.job_mean, idx.job_std)
                for j, f in (job_features or {}).items()}
        Fr, Fj, Fp, Fg = (len(idx.robot_keys), len(idx.job_keys),
                          len(idx.pair_keys), len(idx.global_keys))
        feats = np.zeros((len(candidate_pairs), Fr + Fj + Fp + Fg), dtype=np.float32)
        for i, (r, j) in enumerate(candidate_pairs):
            rv = rvec.get(r, np.zeros(Fr, dtype=np.float32))
            jv = jvec.get(j, np.zeros(Fj, dtype=np.float32))
            pv = self._std(_vec(pair_features.get((r, j), {}), idx.pair_keys),
                           idx.pair_mean, idx.pair_std)
            feats[i] = np.concatenate([rv, jv, pv, gvec])
        return feats

    # ----------------------------------------------------------------- #
    def prune(self,
              candidate_pairs: Sequence[Tuple[str, str]],
              pair_features: Dict[Tuple[str, str], Dict[str, float]],
              robot_features: Dict[str, Dict[str, float]],
              job_features: Dict[str, Dict[str, float]],
              global_features: Optional[Dict[str, float]] = None,
              k: Optional[int] = None) -> List[Tuple[str, str]]:
        """
        Returns the subset C~_n = TopK(scores, k) ∪ urgency_floor.

        The order of the returned list is:
            urgency-floor pairs first (in input order),
            then learned-top-k pairs that aren't in the floor (in score order).
        """
        if not candidate_pairs:
            return []
        k_use = int(k if k is not None else self.k)

        # Urgency floor
        urgency_set = set()
        for (r, j) in candidate_pairs:
            jfeats = job_features.get(j, {})
            t_so = jfeats.get(self.t_so_key)
            if _is_number(t_so) and float(t_so) <= self.T_crit:
                urgency_set.add((r, j))

        # Learned score
        feats = self._build_feats(candidate_pairs, pair_features,
                                  robot_features, job_features, global_features or {})
        with torch.no_grad():
            x = torch.from_numpy(feats).unsqueeze(0).to(self.device)
            mask = torch.ones((1, x.shape[1]), dtype=torch.bool, device=self.device)
            logits = self.model(x, mask).squeeze(0).cpu().numpy()

        # Sort by score descending; pick top-k that aren't already in the floor
        order = np.argsort(-logits)
        topk_extra: List[Tuple[str, str]] = []
        slots_remaining = max(0, k_use - len(urgency_set))
        for i in order:
            pair = candidate_pairs[i]
            if pair in urgency_set:
                continue
            topk_extra.append(pair)
            if len(topk_extra) >= slots_remaining:
                break

        floor_list = [p for p in candidate_pairs if p in urgency_set]
        return floor_list + topk_extra


# =========================================================================== #
# Non-learned baselines for ablation
# =========================================================================== #

class UrgencyGreedyPruner:
    """
    Non-learned baseline. Ranks pairs by predicted lateness
        score(r, j) = -T_so(j)   (more urgent line -> higher score)
    Includes the same urgency floor. Use this to ablate the learned part of F1.
    """

    def __init__(self, k: int, T_crit_seconds: float = 30.0, t_so_key: str = "T_so"):
        self.k = int(k)
        self.T_crit = float(T_crit_seconds)
        self.t_so_key = t_so_key

    def prune(self, candidate_pairs, pair_features, robot_features,
              job_features, global_features=None, k=None) -> List[Tuple[str, str]]:
        if not candidate_pairs:
            return []
        k_use = int(k if k is not None else self.k)
        urgency_set = set()
        scores: List[float] = []
        for (r, j) in candidate_pairs:
            jfeats = job_features.get(j, {})
            t_so = jfeats.get(self.t_so_key, 1e9)
            try:
                t_so = float(t_so)
            except Exception:
                t_so = 1e9
            scores.append(-t_so)
            if t_so <= self.T_crit:
                urgency_set.add((r, j))
        order = np.argsort(-np.asarray(scores))
        topk_extra = []
        slots_remaining = max(0, k_use - len(urgency_set))
        for i in order:
            pair = candidate_pairs[i]
            if pair in urgency_set:
                continue
            topk_extra.append(pair)
            if len(topk_extra) >= slots_remaining:
                break
        floor_list = [p for p in candidate_pairs if p in urgency_set]
        return floor_list + topk_extra


class TravelGreedyPruner:
    """
    Non-learned baseline. Ranks pairs by travel-time surrogate (smaller -> higher
    score). Used as a second ablation point: shows whether learning is doing
    something different from "just pick close ones".
    """

    def __init__(self, k: int, T_crit_seconds: float = 30.0,
                 t_so_key: str = "T_so",
                 tau_ru_key: str = "tau_xy_ru", tau_ul_key: str = "tau_xy_ul"):
        self.k = int(k)
        self.T_crit = float(T_crit_seconds)
        self.t_so_key = t_so_key
        self.tau_ru_key = tau_ru_key
        self.tau_ul_key = tau_ul_key

    def prune(self, candidate_pairs, pair_features, robot_features,
              job_features, global_features=None, k=None) -> List[Tuple[str, str]]:
        if not candidate_pairs:
            return []
        k_use = int(k if k is not None else self.k)
        urgency_set = set()
        scores: List[float] = []
        for (r, j) in candidate_pairs:
            pfeats = pair_features.get((r, j), {})
            tt = float(pfeats.get(self.tau_ru_key, 1e9)) + float(pfeats.get(self.tau_ul_key, 1e9))
            scores.append(-tt)
            jfeats = job_features.get(j, {})
            t_so = jfeats.get(self.t_so_key, 1e9)
            try:
                if float(t_so) <= self.T_crit:
                    urgency_set.add((r, j))
            except Exception:
                pass
        order = np.argsort(-np.asarray(scores))
        topk_extra = []
        slots_remaining = max(0, k_use - len(urgency_set))
        for i in order:
            pair = candidate_pairs[i]
            if pair in urgency_set:
                continue
            topk_extra.append(pair)
            if len(topk_extra) >= slots_remaining:
                break
        floor_list = [p for p in candidate_pairs if p in urgency_set]
        return floor_list + topk_extra
