"""
logger.py
=========
Data-collection hook for F1 pruner training.

Drop-in usage inside the existing MILPOnly run loop:

    from pruner.logger import EpochLogger

    logger = EpochLogger(output_path="rollouts/milponly_base.jsonl")

    # ... inside the rolling-horizon loop, after Gurobi solves at epoch n ...
    logger.log_epoch(
        episode_id=ep,
        epoch_id=n,
        decision_time_s=kappa_n,
        state=state_dict,            # whatever container holds R_n, J_n, etc.
        candidate_pairs=cn,           # list of (robot_id, job_id) tuples in C_n
        pair_features=pair_feat_dict, # dict {(r,j): {...features...}}
        milp_model=gurobi_model,      # the solved gurobipy.Model
        x_vars=x_rjq,                 # dict (r,j,q) -> gurobipy.Var
        v_vars=v_j,                   # dict j       -> gurobipy.Var
    )

    logger.close()

The output is one JSON object per line. Format is documented in PIPELINE_README.md.
The logger never mutates the state, the model, or the simulator. Safe to leave on
in production runs.
"""

from __future__ import annotations
import json
import os
import time
from typing import Any, Dict, Iterable, Optional, Tuple


# --------------------------------------------------------------------------- #
# Helpers for extracting Gurobi values defensively
# --------------------------------------------------------------------------- #

def _safe_x_val(var) -> float:
    """Read a Gurobi variable value, returning 0.0 if unsolved or infeasible."""
    try:
        return float(var.X)
    except Exception:
        return 0.0


def _solve_meta(model) -> Dict[str, float]:
    """Pull MILP metadata from a solved gurobipy.Model without crashing on a bad solve."""
    meta = {"solve_time_ms": 0.0, "objective": float("nan"), "gap": float("nan"),
            "n_binaries": 0, "status": -1, "incumbent_found": 0}
    try:
        meta["solve_time_ms"] = float(model.Runtime) * 1000.0
    except Exception:
        pass
    try:
        meta["status"] = int(model.Status)
    except Exception:
        pass
    try:
        if model.SolCount > 0:
            meta["objective"] = float(model.ObjVal)
            meta["incumbent_found"] = 1
    except Exception:
        pass
    try:
        meta["gap"] = float(model.MIPGap)
    except Exception:
        pass
    try:
        meta["n_binaries"] = int(model.NumBinVars)
    except Exception:
        pass
    return meta


# --------------------------------------------------------------------------- #
# Main logger
# --------------------------------------------------------------------------- #

class EpochLogger:
    """
    Append-only JSONL logger. One line per decision epoch.

    Parameters
    ----------
    output_path : str
        Path to the .jsonl file. Will be created/truncated on first open.
    append : bool
        If True, append to an existing file rather than truncate.
    flush_every : int
        How often to fsync the file. Cheap insurance for crash-aborted runs.
    """

    def __init__(self, output_path: str, append: bool = False, flush_every: int = 50):
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        mode = "a" if append else "w"
        self._fh = open(output_path, mode, buffering=1)
        self._count = 0
        self._flush_every = flush_every
        self._t_start = time.time()

    # --------------------------------------------------------------------- #
    def log_epoch(
        self,
        *,
        episode_id: int,
        epoch_id: int,
        decision_time_s: float,
        state: Dict[str, Any],
        candidate_pairs: Iterable[Tuple[str, str]],
        pair_features: Dict[Tuple[str, str], Dict[str, float]],
        milp_model,
        x_vars: Dict[Tuple[str, str, int], Any],
        v_vars: Optional[Dict[str, Any]] = None,
        global_features: Optional[Dict[str, float]] = None,
        robot_features: Optional[Dict[str, Dict[str, float]]] = None,
        job_features: Optional[Dict[str, Dict[str, float]]] = None,
    ) -> None:
        """
        Serialize one epoch of MILPOnly data.

        The arguments are deliberately wide so that the function does not need to
        know how the caller stores state. The caller is responsible for filling
        the per-robot / per-job / per-pair feature dicts.

        Labels for the pruner are derived by inspecting the MILP solution:
        y[(r,j)] = 1  iff  any q has  x_vars[(r,j,q)].X > 0.5
        """
        # ---- Label derivation: per-pair selection by MILPOnly --------------- #
        selected_slot: Dict[Tuple[str, str], int] = {}
        for (r, j, q), var in x_vars.items():
            if _safe_x_val(var) > 0.5:
                # Keep the smallest selected slot if multiple (shouldn't happen
                # under the single-dispatch rolling approximation, but defensive).
                if (r, j) not in selected_slot or q < selected_slot[(r, j)]:
                    selected_slot[(r, j)] = q

        # ---- Build the pairs list ------------------------------------------- #
        pairs_out = []
        for (r, j) in candidate_pairs:
            feats = pair_features.get((r, j), {})
            sel = selected_slot.get((r, j), -1)
            pairs_out.append({
                "robot_id": str(r),
                "job_id": str(j),
                "features": {k: _scalar(v) for k, v in feats.items()},
                "selected": int(sel >= 0),
                "selected_slot": int(sel),
            })

        # ---- Optional v_j ---------------------------------------------------- #
        v_selected = {}
        if v_vars is not None:
            for j, var in v_vars.items():
                v_selected[str(j)] = int(_safe_x_val(var) > 0.5)

        record = {
            "episode_id": int(episode_id),
            "epoch_id": int(epoch_id),
            "decision_time_s": float(decision_time_s),
            "global_features": {k: _scalar(v) for k, v in (global_features or {}).items()},
            "robots": {str(r): {k: _scalar(v) for k, v in f.items()}
                       for r, f in (robot_features or {}).items()},
            "jobs": {str(j): {k: _scalar(v) for k, v in f.items()}
                     for j, f in (job_features or {}).items()},
            "pairs": pairs_out,
            "v_selected": v_selected,
            "milp_meta": _solve_meta(milp_model),
        }

        self._fh.write(json.dumps(record, separators=(",", ":")) + "\n")
        self._count += 1
        if self._count % self._flush_every == 0:
            self._fh.flush()
            os.fsync(self._fh.fileno())

    # --------------------------------------------------------------------- #
    def close(self):
        if not self._fh.closed:
            self._fh.flush()
            try:
                os.fsync(self._fh.fileno())
            except Exception:
                pass
            self._fh.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


# --------------------------------------------------------------------------- #
# Defensive scalar cast (numpy floats, torch tensors, etc.) -> python float/int
# --------------------------------------------------------------------------- #

def _scalar(x):
    if x is None:
        return None
    if isinstance(x, (int, float, bool, str)):
        return x
    try:
        return float(x)
    except Exception:
        try:
            return float(x.item())
        except Exception:
            return None
