#!/usr/bin/env python3
"""
run_sweep.py
============
Drive run_overall.py across the generated config matrix, writing per-seed
CSVs in the exact naming convention aggregate_results.py expects:

    results/sweep/{factor}__{level}__k{budget}__{method}.csv

Reads configs/sweep/_manifest.csv (from gen_configs.py). For each cell it
invokes your existing runner; nothing about the simulator or controllers is
touched. Resumable: a cell whose output CSV already exists and has the
expected seed count is skipped, so you can stop/restart freely.

Examples
--------
# Robustness sweep, MILPOnly only, 15 seeds, all regimes/budgets:
python run_sweep.py --manifest configs/sweep/_manifest.csv \
    --methods MILPOnly --seeds 15 --out-dir ../results/sweep

# Baseline table at the base regime only (see PHASE notes):
python run_sweep.py --manifest configs/sweep/_manifest.csv \
    --only-factor base --methods Random Reactive UrgencyRank MILPOnly \
    --seeds 30 --out-dir ../results/sweep
"""
from __future__ import annotations
import argparse, csv, os, subprocess, sys, time

RUNNER = "experiments/run_overall.py"   # adjust if your path differs


def _expected_seeds(csv_path: str, n: int) -> bool:
    if not os.path.exists(csv_path):
        return False
    try:
        import pandas as pd
        d = pd.read_csv(csv_path)
        return d["seed"].nunique() >= n
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--methods", nargs="+", required=True,
                    help="e.g. MILPOnly  or  Random Reactive UrgencyRank")
    ap.add_argument("--seeds", type=int, required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--only-factor", default=None,
                    help="restrict to one factor (e.g. base, fleet)")
    ap.add_argument("--only-budgets", nargs="+", default=None,
                    help="restrict to a subset of budget tags")
    ap.add_argument("--pruner-ckpt", default=None)
    ap.add_argument("--pruner-index", default=None)
    ap.add_argument("--runner", default=RUNNER)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    cells = list(csv.DictReader(open(a.manifest)))
    if a.only_factor:
        cells = [c for c in cells if c["factor"] == a.only_factor]
    if a.only_budgets:
        cells = [c for c in cells if c["budget"] in set(a.only_budgets)]
    if not cells:
        sys.exit("No cells selected.")

    os.makedirs(a.out_dir, exist_ok=True)
    total = len(cells) * len(a.methods)
    done = skipped = 0
    t0 = time.time()

    for c in cells:
        for method in a.methods:
            tag = f"{c['factor']}__{c['level']}__k{c['budget']}__{method}"
            out_csv = os.path.join(a.out_dir, tag + ".csv")
            if _expected_seeds(out_csv, a.seeds):
                skipped += 1
                print(f"[skip] {tag} (already has >= {a.seeds} seeds)")
                continue

            cmd = [sys.executable, a.runner,
                   "--config", c["config"],
                   "--seeds", str(a.seeds),
                   "--methods", method,
                   "--out", out_csv]
            # learned pruner needs its checkpoint; the budget tag is still
            # recorded for bookkeeping (k = the candidate cap it runs under)
            if method.endswith("+F1"):
                if not (a.pruner_ckpt and a.pruner_index):
                    sys.exit("F1 method requires --pruner-ckpt/--pruner-index")
                cmd += ["--pruner-ckpt", a.pruner_ckpt,
                        "--pruner-index", a.pruner_index,
                        "--pruner-k", c["budget"] if c["budget"].isdigit()
                        else "80"]

            print(f"\n[{done+skipped+1}/{total}] {tag}")
            print("   " + " ".join(cmd))
            if a.dry_run:
                done += 1
                continue
            env = dict(os.environ)
            env["PYTHONPATH"] = "src:." + (
                ":" + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
            r = subprocess.run(cmd, env=env)
            if r.returncode != 0:
                print(f"   !! runner failed for {tag} (continuing)")
            done += 1
            el = time.time() - t0
            rate = el / max(done, 1)
            eta = rate * (total - done - skipped)
            print(f"   elapsed {el/60:.1f} min | ~ETA {eta/60:.1f} min")

    print(f"\nDone. ran={done} skipped={skipped} total={total} "
          f"wall={ (time.time()-t0)/60:.1f} min")
    print(f"Aggregate with:\n  python sweep/aggregate_results.py "
          f'--glob "{a.out_dir}/*.csv" --out ../results/sweep_tidy.csv')


if __name__ == "__main__":
    main()
