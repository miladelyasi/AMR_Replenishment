#!/usr/bin/env python3
"""
aggregate_results.py
====================
Collapse every per-seed CSV produced by the sweep into ONE tidy long-format
CSV that is the single artifact you send back for analysis & writing.

It parses the experiment coordinates out of the filename, which the
orchestrator writes in a fixed convention:

    {factor}__{level}__k{budget}__{method}.csv

Examples:
    base__base__k80__MILPOnly.csv
    fleet__15__k160__MILPOnly.csv
    demand__high__k240__UrgencyRank.csv
    base__base__kUNPRUNED__MILPOnly+F1.csv

Any CSV not matching that pattern is still ingested with factor/level/budget
parsed as 'unknown' (so ad-hoc runs are not lost) and flagged in a warning.

The per-seed CSV schema is the one run_overall.py already writes:
    method, seed, stockout_minutes, delivered_total, delivered_on_time,
    on_time_ratio, total_travel_m, total_energy, shield_repairs,
    shield_rejections, wall_seconds

Usage:
    python aggregate_results.py --glob "../results/sweep/*.csv" \
                                --out ../results/sweep_tidy.csv
"""
from __future__ import annotations
import argparse, glob, os, re, sys
import pandas as pd

FNAME = re.compile(
    r"^(?P<factor>[^_]+(?:_[^_]+)*?)__(?P<level>.+?)__k(?P<budget>[^_]+)__"
    r"(?P<method>.+)\.csv$"
)

CANON = {  # tolerate minor schema name drift
    "stockout_minutes": ["stockout_minutes", "stockout_min", "stockout"],
    "delivered_total": ["delivered_total", "delivered"],
    "delivered_on_time": ["delivered_on_time", "on_time_delivered"],
    "on_time_ratio": ["on_time_ratio", "on_time"],
    "total_travel_m": ["total_travel_m", "travel_m", "total_travel"],
    "total_energy": ["total_energy", "energy"],
    "shield_repairs": ["shield_repairs", "repairs"],
    "shield_rejections": ["shield_rejections", "rejections", "rejected",
                          "deferrals"],
    "wall_seconds": ["wall_seconds", "wall", "runtime_s"],
    "seed": ["seed"],
    "method": ["method"],
}


def _canon(df: pd.DataFrame) -> pd.DataFrame:
    ren = {}
    low = {c.lower(): c for c in df.columns}
    for canon, alts in CANON.items():
        for a in alts:
            if a in low:
                ren[low[a]] = canon
                break
    return df.rename(columns=ren)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--glob", required=True,
                    help='quoted glob, e.g. "../results/sweep/*.csv"')
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    files = sorted(glob.glob(a.glob))
    if not files:
        sys.exit(f"No files matched {a.glob!r}")

    rows = []
    unmatched = []
    for fp in files:
        base = os.path.basename(fp)
        m = FNAME.match(base)
        if m:
            factor, level, budget, method_fn = (
                m["factor"], m["level"], m["budget"], m["method"])
        else:
            factor = level = budget = "unknown"
            method_fn = base[:-4]
            unmatched.append(base)
        try:
            df = _canon(pd.read_csv(fp))
        except Exception as e:
            print(f"  ! skipping {base}: {e}")
            continue
        df["factor"] = factor
        df["level"] = level
        df["budget"] = budget
        df["source_file"] = base
        if "method" not in df.columns:
            df["method"] = method_fn
        rows.append(df)

    if not rows:
        sys.exit("No readable CSVs.")
    out = pd.concat(rows, ignore_index=True)

    keep = ["factor", "level", "budget", "method", "seed",
            "stockout_minutes", "delivered_total", "delivered_on_time",
            "on_time_ratio", "total_travel_m", "total_energy",
            "shield_repairs", "shield_rejections", "wall_seconds",
            "source_file"]
    for k in keep:
        if k not in out.columns:
            out[k] = pd.NA
    out = out[keep].sort_values(
        ["factor", "level", "budget", "method", "seed"]
    ).reset_index(drop=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    out.to_csv(a.out, index=False)

    # ---- console summary so you can sanity-check before sending ----
    print(f"\nWrote {a.out}")
    print(f"  files ingested : {len(rows)}")
    print(f"  total rows     : {len(out)}")
    print(f"  factors        : {sorted(out['factor'].unique())}")
    print(f"  budgets        : {sorted(out['budget'].unique())}")
    print(f"  methods        : {sorted(out['method'].unique())}")
    seedcount = (out.groupby(['factor', 'level', 'budget', 'method'])['seed']
                    .nunique())
    thin = seedcount[seedcount < 15]
    if len(thin):
        print(f"\n  CELLS WITH <15 SEEDS (rigor check):")
        for idx, n in thin.items():
            print(f"    {idx} -> {n} seeds")
    else:
        print("\n  all cells have >=15 seeds.")
    if unmatched:
        print(f"\n  {len(unmatched)} file(s) did not match the naming "
              f"convention (ingested as 'unknown'):")
        for u in unmatched[:10]:
            print(f"    {u}")


if __name__ == "__main__":
    main()
