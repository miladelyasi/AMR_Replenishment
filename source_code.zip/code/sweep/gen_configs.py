#!/usr/bin/env python3
"""
gen_configs.py
==============
Generate the one-factor-at-a-time (OFAT) robustness matrix of config files
for the sweep. OFAT (not full cartesian) is the correct design for the
sensitivity question "does the screening effect persist across regimes?": vary ONE
factor at a time around the base, sweep the candidate budget within each,
hold everything else at base. Full cartesian would be thousands of 8-h
episodes; OFAT answers the question with ~15 regime points.

It works by DEEP-MERGING small override dicts onto your real base.yaml, so
it cannot silently corrupt unrelated keys. The only thing you must verify
is the ~7 dotted YAML paths in KEY_PATHS below (2 minutes against your
base.yaml). If a path differs in your schema, fix that one string.

Outputs: configs/sweep/{factor}__{level}__k{budget}.yaml
plus a manifest configs/sweep/_manifest.csv listing every cell.

Usage:
    python gen_configs.py --base configs/base.yaml --out-dir configs/sweep
    # then inspect configs/sweep/_manifest.csv and a couple of YAMLs
"""
from __future__ import annotations
import argparse, copy, csv, os, sys
import yaml

# =====================================================================
# >>> VERIFY THESE PATHS AGAINST YOUR base.yaml (dotted = nested keys) <<<
# Pre-filled from our prior runs; candidate_pruning is CONFIRMED correct
# (you already hand-made base_h160/base_h240/base_f1 with this block).
# The others are best-guesses — open base.yaml and confirm/fix the string.
# =====================================================================
KEY_PATHS = {
    "fleet":            "world.robots.fleet_size",
    "num_lines":        "world.num_lines",
    "grid_w":           "world.grid.width",
    "grid_h":           "world.grid.height",
    "stack_depth_max":  "world.storage.max_stack_depth",
    "demand_rate":      "demand.baseline_rate",
    "consume_rate":     "world.buffers.consumption_rate_baseline",
    "buffer_cap":       "world.buffers.capacity",
    "safety_stock":     "world.buffers.safety_stock",
    "shield_repair":    "controller.shield_repair_budget_slots",
    # candidate budget block — verified against base.yaml AND the loader
    # (src/baselines/milp_only.py:274 & src/policy/controller.py:254 both
    #  read self.cfg.controller.candidate_pruning):
    "cp_per_robot":     "controller.candidate_pruning.max_candidates_per_robot",
    "cp_per_line":      "controller.candidate_pruning.max_candidates_per_line",
    "cp_total":         "controller.candidate_pruning.max_total_candidates",
    "cp_jobs":          "controller.candidate_pruning.max_jobs",
}

# Candidate-budget tuples ANCHORED to your confirmed variants
# (base.yaml / base_h160 / base_h240 / base_f1). UNPRUNED ~= effectively
# unbounded. 120 and 320 interpolated for cliff-knee resolution.
BUDGETS = {
    "80":       dict(cp_per_robot=8,   cp_per_line=12,  cp_total=80,   cp_jobs=60),
    "120":      dict(cp_per_robot=15,  cp_per_line=20,  cp_total=120,  cp_jobs=90),
    "160":      dict(cp_per_robot=20,  cp_per_line=30,  cp_total=160,  cp_jobs=120),
    "240":      dict(cp_per_robot=30,  cp_per_line=40,  cp_total=240,  cp_jobs=180),
    "320":      dict(cp_per_robot=40,  cp_per_line=50,  cp_total=320,  cp_jobs=240),
    "UNPRUNED": dict(cp_per_robot=100, cp_per_line=100, cp_total=1000, cp_jobs=400),
}

# OFAT factors. Each level is a dict of {KEY_PATHS-name: value}.
# "base" level == your base.yaml (emitted once, shared).
#
# NOTE on demand: intensity is stored in TWO keys in your base.yaml
# (demand.baseline_rate AND world.buffers.consumption_rate_baseline),
# both = 0.025. They must stay consistent, so each demand level writes
# BOTH via demand_rate + consume_rate.
#
# NOTE on congestion: your base.yaml has NO blocked-cell / obstacle-
# density parameter (the layout is an open 20x20 grid). A congestion
# factor would require a simulator change, so it is intentionally
# OMITTED here rather than faked. We instead obtain a congestion-stress
# axis "for free" through the fleet-size factor (more AMRs on the same
# grid = higher contention) and can add a true obstacle factor later if
# you add the sim knob. This scoping is stated explicitly in the paper.
FACTORS = {
    "demand": {                       # demand intensity (writes BOTH keys)
        "low":  {"demand_rate": 0.0167, "consume_rate": 0.0167},
        "base": {"demand_rate": 0.025,  "consume_rate": 0.025},
        "high": {"demand_rate": 0.0375, "consume_rate": 0.0375},
        # 'surge' is a time-varying scenario, not a stationary rate; your
        # repo already has surge.yaml. Treat surge as a separate named
        # scenario in the paper, not an OFAT level (stated explicitly).
    },
    "fleet": {
        "8":  {"fleet": 8},
        "10": {"fleet": 10},          # base
        "12": {"fleet": 12},
        "15": {"fleet": 15},
    },
    "stackdepth": {
        "shallow": {"stack_depth_max": 5},
        "base":    {"stack_depth_max": 10},
        "deep":    {"stack_depth_max": 15},
    },
    "shield": {                       # repair budget Delta_sh (slots)
        "1": {"shield_repair": 1},
        "3": {"shield_repair": 3},    # base
        "5": {"shield_repair": 5},
    },
    "buffer": {                       # line buffer cap + safety stock
        "low":  {"buffer_cap": 8,  "safety_stock": 2},
        "base": {"buffer_cap": 12, "safety_stock": 4},
        "high": {"buffer_cap": 16, "safety_stock": 6},
    },
}


def _set(d: dict, dotted: str, value):
    keys = dotted.split(".")
    cur = d
    for k in keys[:-1]:
        if k not in cur or not isinstance(cur[k], dict):
            cur[k] = {}
        cur = cur[k]
    cur[keys[-1]] = value


def _apply(cfg: dict, overrides: dict):
    for name, val in overrides.items():
        if name not in KEY_PATHS:
            sys.exit(f"Unknown override key {name!r}; add it to KEY_PATHS.")
        _set(cfg, KEY_PATHS[name], val)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--budgets", nargs="+",
                    default=["80", "120", "160", "240", "UNPRUNED"],
                    help="subset of BUDGETS keys to emit")
    ap.add_argument("--factors", nargs="+", default=list(FACTORS),
                    help="subset of factors to emit (default: all)")
    a = ap.parse_args()

    with open(a.base) as fh:
        base_cfg = yaml.safe_load(fh)

    # ---- HARD GUARD: every target path MUST already resolve in base.yaml,
    # AND its PARENT mapping must already exist. This makes BOTH silent
    # failures impossible: (1) a wholly-missing path, and (2) a path whose
    # parent is absent so a stray top-level/duplicate block gets created
    # while the real block elsewhere is left untouched (the Phase-1 bug).
    def _resolve(d, dotted):
        cur = d
        for k in dotted.split("."):
            if not isinstance(cur, dict) or k not in cur:
                return False
            cur = cur[k]
        return True

    def _parent_ok(d, dotted):
        parts = dotted.split(".")
        if len(parts) == 1:
            return True
        cur = d
        for k in parts[:-1]:
            if not isinstance(cur, dict) or k not in cur:
                return False
            cur = cur[k]
        return isinstance(cur, dict)

    bad = {}
    for name, path in KEY_PATHS.items():
        if not _resolve(base_cfg, path):
            bad[name] = (path, "leaf not found")
        elif not _parent_ok(base_cfg, path):
            bad[name] = (path, "parent mapping absent (stray-key risk)")
    if bad:
        print(f"REFUSING TO GENERATE — KEY_PATHS not safely present in "
              f"{a.base}:")
        for name, (path, why) in bad.items():
            print(f"   {name:18s} -> {path}   [{why}]")
        print("\nFix KEY_PATHS at the top of this script to the TRUE dotted "
              "paths in base.yaml, then re-run. Aborted by design.")
        sys.exit(2)

    os.makedirs(a.out_dir, exist_ok=True)

    manifest = []
    emitted = set()

    def emit(factor, level, level_over):
        for bkey in a.budgets:
            if bkey not in BUDGETS:
                sys.exit(f"Unknown budget {bkey!r}")
            tag = f"{factor}__{level}__k{bkey}"
            if tag in emitted:
                continue
            emitted.add(tag)
            cfg = copy.deepcopy(base_cfg)
            _apply(cfg, level_over)            # the regime factor
            _apply(cfg, BUDGETS[bkey])         # the candidate budget
            path = os.path.join(a.out_dir, tag + ".yaml")
            with open(path, "w") as fh:
                yaml.safe_dump(cfg, fh, sort_keys=False)
            manifest.append(dict(factor=factor, level=level, budget=bkey,
                                 config=os.path.relpath(path)))

    # the shared base cell (factor='base')
    emit("base", "base", {})
    # OFAT: every non-base level of every requested factor
    for fac in a.factors:
        if fac not in FACTORS:
            sys.exit(f"Unknown factor {fac!r}")
        for level, over in FACTORS[fac].items():
            if level == "base" or set(over.items()) <= set(
                    FACTORS[fac].get("base", {}).items()):
                continue  # base level already covered by the shared cell
            emit(fac, level, over)

    mpath = os.path.join(a.out_dir, "_manifest.csv")
    with open(mpath, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["factor", "level", "budget",
                                           "config"])
        w.writeheader()
        w.writerows(manifest)

    n_cells = len(manifest)
    print(f"Wrote {n_cells} config files to {a.out_dir}")
    print(f"Manifest: {mpath}")
    regimes = sorted(set((m["factor"], m["level"]) for m in manifest))
    print(f"Regime points ({len(regimes)}): {regimes}")
    print(f"Budgets per regime: {a.budgets}")
    print("\n>>> SANITY CHECK before running the full sweep:")
    print("    1. open 2-3 generated YAMLs and confirm the factor value")
    print("       and the candidate_pruning block are both correct.")
    print("    2. if any KEY_PATHS path was wrong, the wrong key will be")
    print("       ADDED (not overwrite the real one) — you'll see a stray")
    print("       top-level key. Fix the path string and regenerate.")


if __name__ == "__main__":
    main()