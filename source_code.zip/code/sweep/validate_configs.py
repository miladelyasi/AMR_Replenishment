#!/usr/bin/env python3
"""
validate_configs.py
====================
Run this AFTER gen_configs.py and BEFORE any sweep. It proves that the
candidate-budget override actually lands somewhere that differs between
the generated config files. If it does not, the Phase-1 failure (all
budgets silently running at base) repeats — so this refuses to pass.

It does NOT need to know your schema: it loads each base__base__k*.yaml,
locates ANY mapping whose keys look like the candidate-pruning block
(contains 'max_total_candidates' or similar), and asserts the value
actually changes across budgets.

Usage:
    python sweep/validate_configs.py --dir configs/sweep
"""
from __future__ import annotations
import argparse, glob, os, sys
import yaml

PRUNE_HINTS = ("max_total_candidates", "max_candidates_per_robot",
               "max_candidates_per_line", "max_jobs")


def find_prune_values(node, path=""):
    """Yield (dotted_path, dict) for every mapping that looks like the
    candidate-pruning block, anywhere in the tree."""
    if isinstance(node, dict):
        if any(h in node for h in PRUNE_HINTS):
            yield path or "<root>", {k: node[k] for h in PRUNE_HINTS
                                     if (k := h) in node}
        for k, v in node.items():
            yield from find_prune_values(v, f"{path}.{k}" if path else k)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    a = ap.parse_args()

    files = sorted(glob.glob(os.path.join(a.dir, "base__base__k*.yaml")))
    if not files:
        sys.exit(f"No base__base__k*.yaml in {a.dir} (run gen_configs first)")

    print(f"Inspecting {len(files)} base-regime budget configs:\n")
    table = {}
    for fp in files:
        cfg = yaml.safe_load(open(fp))
        hits = list(find_prune_values(cfg))
        tag = os.path.basename(fp).replace(".yaml", "")
        if not hits:
            sys.exit(f"FAIL: no candidate-pruning block found in {tag}. "
                     f"Generator wrote it nowhere recognizable.")
        if len(hits) > 1:
            print(f"  !! {tag}: pruning-like block found at MULTIPLE "
                  f"locations {[h[0] for h in hits]} — this is the stray-"
                  f"key smell. The runner reads only ONE; the override may "
                  f"be on the wrong one.")
        for loc, vals in hits:
            print(f"  {tag:28s} @ {loc:28s} {vals}")
            table.setdefault(loc, {})[tag] = vals.get(
                "max_total_candidates", None)

    print("\nDoes max_total_candidates actually vary across budgets?")
    ok_any = False
    for loc, byk in table.items():
        vals = [v for v in byk.values() if v is not None]
        varies = len(set(vals)) > 1
        flag = "VARIES (good)" if varies else "CONSTANT (BAD)"
        print(f"  at {loc:28s}: {sorted(set(vals))}  -> {flag}")
        ok_any = ok_any or varies

    if not ok_any:
        print("\nVALIDATION FAILED. The budget does not change across the "
              "generated configs at ANY location the runner could read. "
              "Do NOT run the sweep. Fix KEY_PATHS in gen_configs.py to "
              "your real base.yaml schema (paste base.yaml for help), "
              "regenerate, and re-validate.")
        sys.exit(1)
    if len(table) > 1:
        print("\nWARNING: pruning-like keys exist at >1 location. Confirm "
              "the runner reads the one that VARIES. If unsure, paste "
              "base.yaml + the config-loading code.")
        sys.exit(3)
    print("\nVALIDATION PASSED: a single pruning block, and it varies "
          "across budgets. Safe to run the sweep.")


if __name__ == "__main__":
    main()