"""Stage-2 end-to-end integration tests.

Verifies that the MILP-only baseline runs an episode and produces
metrics consistent with optimization-driven dispatching:
* zero or near-zero stockout
* on-time delivery ratio ~1.0
* MILP solves within the configured time budget
* MILPOnly dominates Random on stockout (the whole point of optimization)
"""

from __future__ import annotations

import pytest

# Skip cleanly if Gurobi isn't installed
gurobipy = pytest.importorskip("gurobipy")

from common.config import Config
from common.controller import Controller, ControllerOutput
from world.simulator import Simulator
from baselines.milp_only import MILPOnlyController
from baselines.random_controller import RandomController


class _Stub(Controller):
    name = "stub"
    def decide(self, state):
        return ControllerOutput([], {})


def _run(make_ctrl, seed, horizon_seconds):
    cfg = Config.from_yaml("configs/base.yaml")
    cfg.experiment.episode_horizon_seconds = horizon_seconds
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    ctrl = make_ctrl(cfg, sim)
    sim.controller = ctrl
    ctrl.reset()
    return sim.run()


def test_milp_only_runs_to_completion():
    """End-to-end: 5-min episode with MILPOnly terminates cleanly."""
    result = _run(
        lambda cfg, sim: MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1),
        seed=0, horizon_seconds=300.0,
    )
    assert result.delivered_total >= 0
    assert len(result.epoch_records) > 0


def test_milp_only_beats_random_on_stockout_short_episode():
    """At 30 min on the base config, MILPOnly should produce <= Random's stockout."""
    short = 1800.0
    rand_results = [_run(lambda cfg, sim: RandomController(seed=s), seed=s, horizon_seconds=short)
                    for s in range(3)]
    milp_results = [_run(lambda cfg, sim: MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1),
                          seed=s, horizon_seconds=short)
                    for s in range(3)]

    avg_random = sum(r.stockout_minutes for r in rand_results) / 3
    avg_milp = sum(r.stockout_minutes for r in milp_results) / 3

    # MILPOnly's stockout should be <= Random's. Tolerance: 0.5 min absolute slack.
    assert avg_milp <= avg_random + 0.5, (
        f"MILPOnly avg stockout {avg_milp:.2f} > Random avg {avg_random:.2f} "
        f"(MILP is supposed to be smarter than random!)"
    )


def test_milp_only_delivers_at_least_as_many_as_random():
    """Across 3 seeds, MILPOnly should deliver at least 80% of what Random delivers
    (typically MILPOnly delivers more due to efficient routing)."""
    short = 1800.0
    rand_total = sum(_run(lambda cfg, sim: RandomController(seed=s),
                           seed=s, horizon_seconds=short).delivered_total
                      for s in range(3))
    milp_total = sum(_run(lambda cfg, sim: MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1),
                           seed=s, horizon_seconds=short).delivered_total
                      for s in range(3))
    assert milp_total >= 0.8 * rand_total, (
        f"MILPOnly delivered {milp_total} / Random {rand_total} — "
        f"unexpectedly low throughput from optimization"
    )


def test_milp_solve_times_are_under_limit_on_average():
    """Average MILP solve time should stay under the configured budget on small problems."""
    cfg = Config.from_yaml("configs/base.yaml")
    cfg.experiment.episode_horizon_seconds = 600.0
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=0)
    sim.reset()
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    sim.controller = ctrl
    ctrl.reset()
    sim.run()
    last_sol = ctrl._last_solution
    assert last_sol is not None
    # On the small post-filter F_n (typically < 600 binaries), solves are fast
    assert last_sol.runtime_ms < 1000.0, (
        f"Last solve took {last_sol.runtime_ms:.1f} ms — too slow"
    )
