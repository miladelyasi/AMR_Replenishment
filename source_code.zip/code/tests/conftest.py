"""Shared pytest fixtures for the amr_replenishment test suite."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

# Make `src` importable
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


@pytest.fixture
def rng() -> np.random.Generator:
    return np.random.default_rng(0)


@pytest.fixture
def base_config_path() -> Path:
    return ROOT / "configs" / "base.yaml"


@pytest.fixture
def base_config(base_config_path):
    """Loaded Config object with a short episode horizon for fast tests."""
    from common.config import Config
    cfg = Config.from_yaml(base_config_path)
    cfg.experiment.episode_horizon_seconds = 600.0  # 10 min
    return cfg
