"""Tests for ``tactical/windows.py`` — service durations and Γ indicators."""

from __future__ import annotations

import pytest

from common.enums import ServiceMode
from tactical.windows import (
    Window,
    compute_drop_window,
    compute_lock_window,
    compute_pickup_window,
    lock_duration,
    pickup_duration,
    slot_indices_overlapping,
    slot_overlap_indicators,
)


# ---------------------------------------------------------------------------
# Service durations (eq. picktime, eq. locktime)
# ---------------------------------------------------------------------------

def test_pickup_duration_direct_is_independent_of_support():
    """For DIRECT mode, pickup time only depends on depth."""
    t1 = pickup_duration(depth=3, support=1, mode=ServiceMode.DIRECT,
                         base=6.0, per_depth=4.0, excavation_overhead=8.0,
                         epsilon_0=1e-3)
    t2 = pickup_duration(depth=3, support=10, mode=ServiceMode.DIRECT,
                         base=6.0, per_depth=4.0, excavation_overhead=8.0,
                         epsilon_0=1e-3)
    assert t1 == t2 == 6.0 + 4.0 * 3


def test_pickup_duration_excavation_grows_with_depth():
    """Excavation: t increases with d (holding phi fixed)."""
    kw = dict(support=2, mode=ServiceMode.EXCAVATION,
              base=6.0, per_depth=4.0, excavation_overhead=8.0, epsilon_0=1e-3)
    times = [pickup_duration(depth=d, **kw) for d in range(1, 6)]
    for a, b in zip(times, times[1:]):
        assert b > a


def test_pickup_duration_excavation_decreases_with_support():
    """Excavation: t decreases as phi grows (holding d fixed)."""
    kw = dict(depth=4, mode=ServiceMode.EXCAVATION,
              base=6.0, per_depth=4.0, excavation_overhead=8.0, epsilon_0=1e-3)
    times = [pickup_duration(support=s, **kw) for s in range(1, 8)]
    for a, b in zip(times, times[1:]):
        assert b < a


def test_pickup_duration_no_division_by_zero_when_phi_zero():
    """epsilon_0 clamping prevents division-by-zero crashes."""
    # Should not raise; should return a finite positive number.
    t = pickup_duration(depth=5, support=0, mode=ServiceMode.EXCAVATION,
                        base=6.0, per_depth=4.0, excavation_overhead=8.0,
                        epsilon_0=1e-3)
    assert t > 0
    assert t < float("inf")


def test_lock_duration_direct_proportional_to_depth():
    """DIRECT mode lock = per_depth * d."""
    t = lock_duration(depth=4, support=2, mode=ServiceMode.DIRECT,
                      per_depth=2.0, excavation_overhead=4.0, epsilon_0=1e-3)
    assert t == 2.0 * 4


# ---------------------------------------------------------------------------
# Slot overlap (Γ indicators)
# ---------------------------------------------------------------------------

def test_slot_overlap_indicator_handles_half_open_intervals():
    """Window [2.0, 5.0) should overlap slots {2, 3, 4} but not slot 5 (slot=1.0)."""
    w = Window(start=2.0, end=5.0)
    idx = slot_indices_overlapping(w, num_slots=10, slot_size=1.0)
    assert idx == [2, 3, 4]


def test_slot_overlap_indicator_window_inside_one_slot():
    """A window strictly inside a single slot still flags it."""
    w = Window(start=2.3, end=2.7)
    idx = slot_indices_overlapping(w, num_slots=10, slot_size=1.0)
    assert idx == [2]


def test_slot_overlap_indicator_dense_matches_sparse():
    """Dense and sparse versions produce identical sets."""
    import numpy as np
    w = Window(start=1.5, end=4.2)
    dense = slot_overlap_indicators(w, num_slots=8, slot_size=1.0)
    sparse = slot_indices_overlapping(w, num_slots=8, slot_size=1.0)
    dense_set = set(int(i) for i, v in enumerate(dense) if v == 1)
    assert dense_set == set(sparse)


def test_slot_overlap_empty_for_zero_duration():
    """A degenerate (start == end) window overlaps nothing."""
    w = Window(start=3.0, end=3.0)
    assert slot_indices_overlapping(w, num_slots=10, slot_size=1.0) == []


# ---------------------------------------------------------------------------
# Service windows (eq. pickwindow, dropwindow, lockwindow)
# ---------------------------------------------------------------------------

def test_pickup_window_starts_after_travel():
    """Source-interface usage starts on arrival at the column."""
    w = compute_pickup_window(start_slot=2, slot_size=5.0,
                              travel_to_tote_seconds=12.0,
                              pickup_seconds=18.0)
    # arrival = 2*5 + 12 = 22.  end = 22 + 18 = 40
    assert w.start == 22.0
    assert w.end == 40.0


def test_drop_window_starts_after_full_pickup_chain():
    """Destination-interface usage starts when robot reaches the line."""
    w = compute_drop_window(start_slot=0, slot_size=5.0,
                            travel_to_tote_seconds=10.0,
                            pickup_seconds=20.0,
                            travel_to_line_seconds=15.0,
                            completion_time=53.0)
    # arrival_at_line = 0 + 10 + 20 + 15 = 45.  end = completion = 53.
    assert w.start == 45.0
    assert w.end == 53.0


def test_lock_window_aligned_with_pickup_arrival():
    """Local lock starts when robot reaches the column."""
    w = compute_lock_window(start_slot=1, slot_size=5.0,
                            travel_to_tote_seconds=10.0,
                            lock_seconds=12.0)
    # arrival = 5 + 10 = 15.  end = 15 + 12 = 27.
    assert w.start == 15.0
    assert w.end == 27.0
