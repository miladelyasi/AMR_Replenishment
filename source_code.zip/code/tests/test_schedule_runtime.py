"""Regression checks for mission execution and resource accounting."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from common.config import Config
from common.controller import Controller,ControllerOutput
from common.types import Commitment,Job
from common.enums import ServiceMode
from world.schedule_simulator import ScheduleSimulator
from baselines.milp_only import MILPOnlyController
from shield.prioritized import PrioritizedShield
from world.schedule_simulator import carried_peak_occupancy

def test_sequential_service_intervals_do_not_create_false_carried_overload():
    # Both intervals touch slot 0 but are never simultaneous. An overlap-sum
    # of two would make even the zero-new-assignment MILP infeasible at C=1.
    a=carried_peak_occupancy([(0,0.,2.),(0,3.,4.)],1,2,5.,0.)
    assert a.tolist()==[[1,0]]
    # Genuine overlap still consumes two units; it must not be clamped away.
    b=carried_peak_occupancy([(0,0.,3.),(0,2.,4.)],1,2,5.,0.)
    assert b.tolist()==[[2,0]]
    c=carried_peak_occupancy([(0,-2.,5.),(0,5.,8.)],1,2,5.,0.)
    assert c.tolist()==[[1,1]]

class Stub(Controller):
    def decide(self,state):return ControllerOutput([],{})

def make(seed=0,horizon=600):
    cfg=Config.from_yaml('configs/sweep/base__base__k80.yaml')
    cfg.experiment.episode_horizon_seconds=horizon
    sim=ScheduleSimulator(cfg,Stub(),seed=seed);sim.reset()
    sim.shield=PrioritizedShield(cfg.shield,sim.grid,cfg.controller.slot_size_delta_seconds)
    sim.shield.cfg.shield_repair_budget_slots=3
    sim.controller=MILPOnlyController(cfg,sim,max_slots_per_pair=1)
    return sim

def test_occupied_initial_vertex_is_rejected_even_for_zero_length_path():
    sim=make();sh=sim.shield
    sh.table.reserve_node((1,1),0,99)
    assert sh._astar_time_expanded((1,1),(1,1),0,20,0) is None
    assert sh._astar_time_expanded((1,1),(2,1),0,20,0) is None

def test_executed_times_energy_distance_and_material_counts():
    sim=make();distances=[];energies=[]
    raw=sim._apply_commitments_with_shield
    def apply(cms):
        before={id(m.commitment) for m in sim.active_missions.values()}
        out=raw(cms)
        for m in sim.active_missions.values():
            if id(m.commitment) not in before:
                distances.append(m.travel_distance_m)
        return out
    sim._apply_commitments_with_shield=apply
    result=sim.run()
    assert result.delivered_total>10
    assert abs(result.total_travel_m-sum(distances))<1e-8
    assert sim.executed_schedule_mismatches==0
    assert sim.missed_completion_deadlines==0
    assert sim.min_battery_observed>=sim.cfg.world.robots.battery_min-1e-9
    assert sim.buffer_accepted_units+sim.buffer_overflow_units==result.delivered_total
    assert len(sim.reserved_totes)==len(sim.active_missions)

def test_consumption_stream_is_independent_of_controller_and_inventory_draws():
    a=make(seed=4,horizon=100);b=make(seed=4,horizon=100)
    b.cfg.controller.candidate_pruning.max_candidates_per_line=40
    events=[[],[]]
    for i,sim in enumerate([a,b]):
        raw=sim._handle_consumption
        def consume(lid,sim=sim,raw=raw,i=i):
            events[i].append((sim.t_now,lid));return raw(lid)
        sim._handle_consumption=consume
    b.rng.random(10000)
    a.run();b.run()
    assert events[0]==events[1]

def test_realized_energy_admission_prevents_battery_floor_violation():
    sim=make(seed=2,horizon=900)
    sim.cfg.world.robots.charge_per_second_idle=0.
    for r in sim.robots:r.battery=.19
    sim.run()
    assert sim.min_battery_observed>=.10-1e-9
    assert all(r.battery>=.10-1e-9 for r in sim.robots)

def test_distinct_jobs_cannot_reuse_same_physical_tote():
    import gurobipy as gp
    from types import SimpleNamespace
    from tactical.milp import TacticalMILP
    sim=make();solver=sim.controller.milp
    model=solver._build_model()
    jobs=[Job(0,123,ServiceMode.DIRECT),Job(1,123,ServiceMode.DIRECT)]
    feasible=[SimpleNamespace(robot_id=i,job=j) for i,j in enumerate(jobs)]
    x,v=solver._add_decision_variables(model,feasible,jobs)
    solver._add_assignment_constraints(model,x,v,feasible,jobs)
    model.setObjective(-gp.quicksum(v.values()));model.optimize()
    assert model.SolCount and abs(sum(a.X for a in v.values())-1)<1e-8
    assert model.getConstrByName('tote_unique_123') is not None

def test_reserved_tote_is_excluded_from_new_job_catalogue():
    from tactical.feasibility import build_job_set
    sim=make();state=sim._build_state();jobs=build_job_set(state,sim.cfg.controller.candidate_pruning)
    uid=jobs[0].tote_id;sim.reserved_totes.add(uid)
    newjobs=build_job_set(sim._build_state(),sim.cfg.controller.candidate_pruning)
    assert all(j.tote_id!=uid for j in newjobs)

def test_buffer_material_balance():
    sim=make(seed=3,horizon=1200);initial=sum(b.level for b in sim.buffers);successful=[0]
    raw=sim._handle_consumption
    def consume(lid):
        if sim.buffers[lid].level>0:successful[0]+=1
        return raw(lid)
    sim._handle_consumption=consume;sim.run()
    assert initial+sim.buffer_accepted_units==successful[0]+sum(b.level for b in sim.buffers)
