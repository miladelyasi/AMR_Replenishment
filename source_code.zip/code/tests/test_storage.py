"""Storage-system unit tests (Stage 1)."""

from __future__ import annotations

from common.enums import AccessClass
from common.types import Tote
from world.storage import StorageColumn, StorageSystem


def _build_2x2_system(stack_depths: list[list[int]]) -> StorageSystem:
    """Helper: build a 2x2 storage with given depth-counts per column.

    ``stack_depths[x][y]`` = number of totes in column (x, y), top-first.
    """
    cols = {(x, y): StorageColumn(cell=(x, y), capacity=10)
            for x in range(2) for y in range(2)}
    sys = StorageSystem(columns=cols, max_stack_depth=10, support_threshold=1)
    totes = []
    uid = 0
    for x in range(2):
        for y in range(2):
            n = stack_depths[x][y]
            for d in range(n):
                totes.append(Tote(uid=uid, sku=0, column=(x, y), depth=d))
                uid += 1
    sys.register_totes(totes)
    return sys


def test_top_tote_is_directly_retrievable():
    """A tote at depth=0 with no lock returns AccessClass.DIRECT."""
    sys = _build_2x2_system([[3, 1], [1, 1]])
    # The top tote in column (0, 0) is uid 0 (first registered there).
    cell = (0, 0)
    top_uid = sys.columns[cell].top()
    assert sys.compute_access_class(top_uid, locked_cells=set()) == AccessClass.DIRECT


def test_buried_tote_is_excavation_feasible_when_support_available():
    """A tote at depth>=1 with sufficient neighbor support → EXCAVATION."""
    sys = _build_2x2_system([[3, 1], [1, 1]])
    cell = (0, 0)
    # The 2nd tote in (0,0)'s stack is at depth 1
    buried_uid = sys.columns[cell].stack[1]
    ac = sys.compute_access_class(buried_uid, locked_cells=set())
    assert ac == AccessClass.EXCAVATION


def test_buried_tote_is_infeasible_when_no_support():
    """A buried tote with all neighbors locked → INFEASIBLE."""
    sys = _build_2x2_system([[3, 1], [1, 1]])
    cell = (0, 0)
    buried_uid = sys.columns[cell].stack[1]

    # Lock both neighbors of (0, 0): (1, 0) and (0, 1)
    locked = {(1, 0), (0, 1)}
    ac = sys.compute_access_class(buried_uid, locked_cells=locked)
    assert ac == AccessClass.INFEASIBLE


def test_tote_in_locked_cell_is_infeasible_regardless_of_depth():
    """An active retrieval in the same column blocks all access."""
    sys = _build_2x2_system([[3, 1], [1, 1]])
    cell = (0, 0)
    top_uid = sys.columns[cell].top()
    ac = sys.compute_access_class(top_uid, locked_cells={cell})
    assert ac == AccessClass.INFEASIBLE


def test_retrieval_removes_tote_from_stack():
    """``execute_retrieval`` reduces the stack length by 1."""
    sys = _build_2x2_system([[3, 1], [1, 1]])
    cell = (0, 0)
    before = len(sys.columns[cell].stack)
    top_uid = sys.columns[cell].top()
    sys.execute_retrieval(top_uid)
    after = len(sys.columns[cell].stack)
    assert after == before - 1
    assert top_uid not in sys.columns[cell].stack


def test_compute_access_map_covers_all_totes():
    """``compute_access_map`` returns one entry per tote in the system."""
    sys = _build_2x2_system([[3, 2], [1, 1]])
    m = sys.compute_access_map(locked_cells=set())
    assert set(m.keys()) == set(sys.all_tote_ids())
    # Top totes should always be DIRECT (no locks)
    for cell, col in sys.columns.items():
        if col.stack:
            assert m[col.top()] == AccessClass.DIRECT


def test_full_column_does_not_provide_excavation_support():
    """A neighbor at full capacity counts as zero support."""
    cols = {(x, y): StorageColumn(cell=(x, y), capacity=2)
            for x in range(2) for y in range(2)}
    sys = StorageSystem(columns=cols, max_stack_depth=2, support_threshold=1)

    totes = []
    uid = 0
    # Fill column (0, 0) to capacity 2; column (1, 0) full; columns (0, 1), (1, 1) full
    for cell in [(0, 0), (1, 0), (0, 1), (1, 1)]:
        for d in range(2):
            totes.append(Tote(uid=uid, sku=0, column=cell, depth=d))
            uid += 1
    sys.register_totes(totes)

    # Tote at depth 1 in (0, 0) should be INFEASIBLE: all neighbors are full.
    buried = sys.columns[(0, 0)].stack[1]
    ac = sys.compute_access_class(buried, locked_cells=set())
    assert ac == AccessClass.INFEASIBLE
