"""Stage-5 unit tests for the SMDP discount math, masked Gaussian log-prob,
and PPO importance ratio. These are pure-tensor tests — no simulator.
"""

from __future__ import annotations

import math

import numpy as np
import pytest
import torch

from common.config import EncoderConfig, PolicyConfig, ActorConfig, PPOConfig
from policy.actor_critic import ActorCritic, _standard_normal_log_prob
from policy.rollout import RolloutBuffer, Transition


def _make_actor_critic(global_dim=4, robot_dim=4, job_dim=4, pair_dim=4):
    cfg = PolicyConfig(
        encoders=EncoderConfig(
            global_dim=8, robot_dim=4, job_dim=4,
            pair_hidden_dim=8, pair_output_dim=1,
        ),
        actor=ActorConfig(init_log_sigma=0.0, learn_sigma=True),
        ppo=PPOConfig(),
    )
    torch.manual_seed(0)
    return ActorCritic(global_dim, robot_dim, job_dim, pair_dim, cfg)


def test_smdp_discount_recursion_matches_math():
    """A_n = δ_n + γ^(Θ/K) ζ A_{n+1}, with terminal A_T = 0.

    Hand-compute on a 3-step trajectory and check the recursion.
    """
    gamma, zeta, K = 0.9, 0.95, 5.0
    rewards = [1.0, -2.0, 3.0]
    holdings = [4.0, 6.0, 5.0]
    values = [0.5, 0.2, -0.1]
    next_values = [0.2, -0.1, 0.0]   # last is bootstrap-zero (done=True)
    dones = [False, False, True]

    discs = [gamma ** (h / K) for h in holdings]
    deltas = [
        rewards[i] + (0.0 if dones[i] else discs[i] * next_values[i]) - values[i]
        for i in range(3)
    ]
    # Reverse recursion: A_2 = δ_2; A_1 = δ_1 + disc_1 * ζ * A_2; A_0 = ...
    expected = [0.0, 0.0, 0.0]
    expected[2] = deltas[2]
    expected[1] = deltas[1] + discs[1] * zeta * expected[2]
    expected[0] = deltas[0] + discs[0] * zeta * expected[1]

    # Now run buffer
    buffer = RolloutBuffer()
    for i in range(3):
        buffer.add(Transition(
            state={"global": np.array([i], dtype=np.float32)},
            action=np.zeros(1, dtype=np.float32),
            log_prob_old=0.0,
            reward=rewards[i],
            holding_time=holdings[i],
            next_state={"global": np.array([i + 1], dtype=np.float32)},
            done=dones[i],
        ))

    def value_fn(features):
        i = int(features["global"][0])
        if i < 3:
            return values[i]
        return next_values[2]   # post-terminal (won't be queried due to done)

    # Patch value_fn so next_state lookups return next_values[i]
    def value_fn_full(features):
        i = int(features["global"][0])
        if i == 0: return values[0]
        if i == 1: return values[1] if features is buffer.transitions[1].state else next_values[0]
        if i == 2: return values[2] if features is buffer.transitions[2].state else next_values[1]
        if i == 3: return next_values[2]
        return 0.0

    buffer.compute_advantages(critic_value_fn=value_fn_full,
                              gamma=gamma, zeta=zeta, K=K)

    assert buffer.advantages[0] == pytest.approx(expected[0], rel=1e-5)
    assert buffer.advantages[1] == pytest.approx(expected[1], rel=1e-5)
    assert buffer.advantages[2] == pytest.approx(expected[2], rel=1e-5)


def test_smdp_discount_with_zero_holding_recovers_standard_gae():
    """When Θ_n = K for all n, gamma^(Θ/K) = gamma — back to standard GAE."""
    gamma, zeta, K = 0.95, 0.9, 5.0
    rewards = [1.0, 1.0, 1.0]
    values = [0.0, 0.0, 0.0]
    buffer = RolloutBuffer()
    for r in rewards:
        buffer.add(Transition(
            state={"global": np.zeros(1, dtype=np.float32)},
            action=np.zeros(1, dtype=np.float32),
            log_prob_old=0.0,
            reward=r,
            holding_time=K,    # exactly the nominal period
            next_state={"global": np.zeros(1, dtype=np.float32)},
            done=False,
        ))
    buffer.transitions[-1].done = True

    buffer.compute_advantages(
        critic_value_fn=lambda f: 0.0, gamma=gamma, zeta=zeta, K=K,
    )
    # Standard GAE with V=0 reduces to: A_n = sum_{k=n}^{T-1} (γζ)^{k-n} r_k
    # (with terminal bootstrap zero for the last step's discount):
    #   A_2 = 1
    #   A_1 = 1 + γζ * 1 = 1 + 0.855 = 1.855
    #   A_0 = 1 + γζ * (1 + γζ * 1) = 1 + 0.855 + 0.855² = 2.586...
    expected = [
        1.0 + (gamma * zeta) * (1.0 + (gamma * zeta) * 1.0),
        1.0 + (gamma * zeta) * 1.0,
        1.0,
    ]
    for got, exp in zip(buffer.advantages, expected):
        assert got == pytest.approx(exp, rel=1e-5)


def test_masked_gaussian_log_prob_matches_standard_normal():
    """A standard-normal sample at the mean has log-prob = -log(σ) - 0.5*log(2π)."""
    ac = _make_actor_critic()
    means = torch.zeros(1, 5)
    samples = means.clone()             # ε = 0
    mask = torch.ones(1, 5, dtype=torch.bool)
    lp = ac.log_prob_of(means, samples, mask).item()
    expected = -ac.log_sigma.item() - 0.5 * math.log(2 * math.pi)
    assert lp == pytest.approx(expected, rel=1e-5)


def test_masked_gaussian_log_prob_is_zero_for_empty_mask():
    """No feasible pairs → log-prob is the sum-over-zero / max(1, 0) = 0."""
    ac = _make_actor_critic()
    means = torch.zeros(1, 5)
    samples = means.clone()
    mask = torch.zeros(1, 5, dtype=torch.bool)
    lp = ac.log_prob_of(means, samples, mask).item()
    assert lp == 0.0


def test_actor_sample_returns_consistent_log_prob():
    """sample() and log_prob_of() should agree on the same action."""
    torch.manual_seed(42)
    ac = _make_actor_critic()
    means = torch.randn(1, 7)
    mask = torch.ones(1, 7, dtype=torch.bool)
    mask[0, 3] = False    # one infeasible
    mask[0, 5] = False    # another

    samples, lp_sample = ac.sample(means, mask)
    lp_recompute = ac.log_prob_of(means, samples, mask)
    assert torch.allclose(lp_sample, lp_recompute, rtol=1e-5)


def test_ppo_ratio_clipping_behavior_is_sane():
    """Empirically: when log_prob_new == log_prob_old, ratio = 1; the unclipped
    and clipped surrogates equal advantage * 1."""
    log_prob_old = -0.7
    log_prob_new = torch.tensor(-0.7, requires_grad=True)
    ratio = (log_prob_new - log_prob_old).exp()
    adv = -2.5
    eps = 0.2
    unclipped = ratio * adv
    clipped = ratio.clamp(1 - eps, 1 + eps) * adv
    surrogate = -torch.min(unclipped, clipped)
    # ratio == 1 → both equal -2.5; min(-2.5, -2.5) == -2.5 → surrogate = 2.5
    assert surrogate.item() == pytest.approx(2.5, rel=1e-5)
