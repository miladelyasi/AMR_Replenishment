"""Tactical MILP tests (Stage-2 acceptance).

Each test builds a *small* problem instance (well within the gurobipy
trial license limit) and verifies one constraint or behavior. The full
paper-scale instances need the user's licensed Gurobi.
"""

from __future__ import annotations

import numpy as np
import pytest

# Heavy imports — guarded so the rest of the suite can run even without gurobi.
gurobipy = pytest.importorskip("gurobipy")

from common.config import Config
from common.controller import Controller, ControllerOutput
from world.simulator import Simulator
from baselines.milp_only import MILPOnlyController


class _Stub(Controller):
    name = "Stub"
    def decide(self, state): return ControllerOutput([], {})


def _make_small_sim(seed=0, horizon=60.0, fleet_size=3, num_lines=2):
    """Build a small simulator instance for unit testing."""
    cfg = Config.from_yaml("configs/base.yaml")
    cfg.experiment.episode_horizon_seconds = horizon
    cfg.world.robots.fleet_size = fleet_size
    cfg.world.num_lines = num_lines
    cfg.world.grid.width = 6
    cfg.world.grid.height = 4
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    return cfg, sim


def test_milp_runs_on_small_instance():
    """The MILP runs to OPTIMAL on a small instance and returns commitments."""
    cfg, sim = _make_small_sim()
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()
    out = ctrl.decide(state)
    assert out.diagnostics["milp_status"] in {"OPTIMAL", "TIME_LIMIT", "SUBOPTIMAL"}
    # On a small instance with 3 robots, we should see between 0 and 3 commitments
    assert 0 <= len(out.commitments) <= 3


def test_milp_respects_robot_at_most_one_constraint():
    """No robot is assigned more than one job in the rolling horizon."""
    cfg, sim = _make_small_sim()
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()
    out = ctrl.decide(state)
    assigned_robots = [cm.robot_id for cm in out.commitments]
    assert len(assigned_robots) == len(set(assigned_robots)), (
        f"Robot assigned twice: {assigned_robots}"
    )


def test_milp_each_job_assigned_at_most_once():
    """eq. (job-service): each job served by at most one robot."""
    cfg, sim = _make_small_sim()
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()
    out = ctrl.decide(state)
    job_keys = [cm.job.key() for cm in out.commitments]
    assert len(job_keys) == len(set(job_keys))


def test_milp_zero_varrho_ignores_score_field():
    """When varrho=0, the MILP gives same solution regardless of score field."""
    cfg, sim = _make_small_sim()
    cfg.milp.weights.varrho = 0.0
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()

    # Solve once with no score field (MILPOnly default)
    out1 = ctrl.decide(state)
    obj1 = out1.diagnostics["milp_objective"]

    # Now manually inject a giant score field; varrho=0 should mute it
    from tactical.feasibility import build_feasible_set, build_job_set
    jobs = build_job_set(state, cfg.controller.candidate_pruning)
    score_field = {(0, j.line_id, j.tote_id): 100.0 for j in jobs}

    # Solve directly via the MILP
    tote_to_src, tote_to_block = ctrl._build_tote_maps()
    feasible = build_feasible_set(
        state, jobs, [r.rid for r in sim.robots],
        horizon_seconds=cfg.controller.tactical_horizon_H_seconds,
        slot_size=ctrl.slot_size, num_slots=ctrl.num_slots,
        battery_min_per_robot=ctrl._battery_min_per_robot,
        travel_to_tote_fn=ctrl._make_travel_to_tote_fn(),
        travel_to_line_fn=ctrl._make_travel_to_line_fn(),
        pickup_dur_fn=ctrl._make_pickup_fn(),
        lock_dur_fn=ctrl._make_lock_fn(),
        energy_fn=ctrl._make_energy_fn(),
        drop_seconds=cfg.world.service_times.drop_seconds,
        max_slots_per_pair=1,
    )
    n_src = len(ctrl._cell_to_src_idx)
    n_dst = cfg.world.num_lines
    sol = ctrl.milp.solve(
        state=state, feasible=feasible, jobs=jobs, score_field=score_field,
        carried_src=np.zeros((n_src, ctrl.num_slots), np.int32),
        carried_dst=np.zeros((n_dst, ctrl.num_slots), np.int32),
        carried_block=np.zeros((n_src, ctrl.num_slots), np.int32),
        battery_remaining={r.rid: 1.0 for r in sim.robots},
        capacities_src=ctrl._capacities_src,
        capacities_dst=ctrl._capacities_dst,
        capacities_block=ctrl._capacities_block,
        tote_to_src_idx=tote_to_src, line_to_dst_idx=ctrl._line_to_dst_idx,
        tote_to_block_indices=tote_to_block,
    )
    # Objective should be similar (slight differences possible due to symmetry-breaking)
    # The KEY test: number of commitments shouldn't change.
    assert len(sol.commitments) == len(out1.commitments)


def test_milp_respects_battery_constraint_globally():
    """Robot with insufficient global energy cannot be assigned an expensive mission."""
    cfg, sim = _make_small_sim()
    # Drain robot 0's battery to just above minimum
    sim.robots[0].battery = cfg.world.robots.battery_min + 0.001  # below pre_filter floor
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()
    out = ctrl.decide(state)
    assigned = {cm.robot_id for cm in out.commitments}
    # Robot 0 should NOT be eligible at all (filtered by R_n)
    assert 0 not in assigned, (
        f"Drained robot 0 was assigned a job: {assigned}"
    )


def test_milp_respects_time_limit():
    """Solver returns within configured time limit (allow 5x slack for first call overhead)."""
    cfg, sim = _make_small_sim(fleet_size=4, num_lines=3)
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()

    import time
    t0 = time.perf_counter()
    out = ctrl.decide(state)
    dt_ms = 1000 * (time.perf_counter() - t0)
    limit_ms = cfg.milp.solver.time_limit_ms

    # First-call overhead may be high (env setup); we test 5× the limit.
    assert dt_ms < limit_ms * 5, (
        f"MILP solve took {dt_ms:.1f} ms > 5x the limit ({limit_ms} ms)"
    )


def test_milp_warm_start_does_not_crash():
    """Sequential solves with warm-start succeed."""
    cfg, sim = _make_small_sim()
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()
    out1 = ctrl.decide(state)
    # Second call uses cached solution as warm start
    out2 = ctrl.decide(state)
    # Both should succeed; results may differ slightly due to symmetry but cardinality matches
    assert out1.diagnostics["milp_status"] in {"OPTIMAL", "SUBOPTIMAL", "TIME_LIMIT"}
    assert out2.diagnostics["milp_status"] in {"OPTIMAL", "SUBOPTIMAL", "TIME_LIMIT"}


def test_milp_unservable_jobs_have_v_pinned_to_zero():
    """Jobs without any feasible (r, q) — their v_j must be 0 (no penalty paid is fine)."""
    cfg, sim = _make_small_sim()
    # Drain ALL robot batteries so no robot is eligible for ANY job
    for r in sim.robots:
        r.battery = cfg.world.robots.battery_min + 0.001  # below pre_filter floor
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()
    out = ctrl.decide(state)
    # No commitments should be returned.
    assert len(out.commitments) == 0


def test_milp_objective_matches_expected_structure():
    """Sanity: objective is finite and non-negative for the small instance."""
    cfg, sim = _make_small_sim()
    ctrl = MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=1)
    state = sim._build_state()
    out = ctrl.decide(state)
    obj = out.diagnostics["milp_objective"]
    assert obj == obj   # not NaN
    # With deferral penalties, even fully-served instances have positive objective
    assert obj >= 0
