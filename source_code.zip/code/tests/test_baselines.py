"""Stage-4 tests for Reactive and UrgencyRank baselines.

These complement the MILPOnly/Random tests in the existing files.
"""

from __future__ import annotations

import pytest

from common.config import Config
from common.controller import Controller, ControllerOutput
from world.simulator import Simulator
from baselines.reactive import ReactiveThresholdController
from baselines.urgency_rank import UrgencyRankController
from shield.prioritized import PrioritizedShield


class _Stub(Controller):
    name = "stub"
    def decide(self, s): return ControllerOutput([], {})


def _build(seed=0, horizon=300.0, with_shield=True):
    cfg = Config.from_yaml("configs/base.yaml")
    cfg.experiment.episode_horizon_seconds = horizon
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    if with_shield:
        sh = PrioritizedShield(cfg=cfg.shield, grid=sim.grid,
                               slot_size=cfg.controller.slot_size_delta_seconds)
        sh.cfg.shield_repair_budget_slots = cfg.controller.shield_repair_budget_slots
        sim.shield = sh
    return cfg, sim


# ---------------------------------------------------------------------------
# Reactive
# ---------------------------------------------------------------------------

def test_reactive_idles_when_no_line_is_critical():
    """Reactive returns zero commitments at t=0 when all buffers start full."""
    cfg, sim = _build()
    # Initial buffers = 8, safety = 4 → no line critical
    ctrl = ReactiveThresholdController(slot_size=cfg.controller.slot_size_delta_seconds)
    state = sim._build_state()
    out = ctrl.decide(state)
    assert len(out.commitments) == 0
    assert out.diagnostics.get("reason") == "no_critical_lines"


def test_reactive_dispatches_to_critical_line():
    """When a line drops below safety stock, Reactive sends a robot to it."""
    cfg, sim = _build()
    # Force line 2 below safety stock
    sim.buffers[2].level = 2
    ctrl = ReactiveThresholdController(slot_size=cfg.controller.slot_size_delta_seconds)
    state = sim._build_state()
    out = ctrl.decide(state)
    # At least one commitment for line 2
    line2_commitments = [c for c in out.commitments if c.job.line_id == 2]
    assert len(line2_commitments) >= 1


def test_reactive_runs_episode_without_error():
    """End-to-end smoke test."""
    cfg, sim = _build(horizon=120.0)
    ctrl = ReactiveThresholdController(slot_size=cfg.controller.slot_size_delta_seconds)
    sim.controller = ctrl; ctrl.reset()
    result = sim.run()
    assert result.delivered_total >= 0
    # On a 2-min episode with 6 lines × consumption ~0.025/s = 0.9 totes consumed/line,
    # most buffers won't yet be critical, so deliveries are 0 or small.
    assert result.stockout_minutes < 1.0


def test_reactive_does_not_double_assign_robots():
    """No two commitments share a robot id."""
    cfg, sim = _build()
    # Put several lines below safety to force multiple dispatches
    for lid in [1, 2, 3]:
        sim.buffers[lid].level = 1
    ctrl = ReactiveThresholdController(slot_size=cfg.controller.slot_size_delta_seconds)
    state = sim._build_state()
    out = ctrl.decide(state)
    rids = [c.robot_id for c in out.commitments]
    assert len(rids) == len(set(rids)), f"Duplicate robots in commitments: {rids}"


# ---------------------------------------------------------------------------
# UrgencyRank
# ---------------------------------------------------------------------------

def test_urgency_rank_dispatches_even_when_no_line_critical():
    """UrgencyRank serves lines greedily even when none is below safety stock."""
    cfg, sim = _build()
    ctrl = UrgencyRankController(slot_size=cfg.controller.slot_size_delta_seconds)
    state = sim._build_state()
    out = ctrl.decide(state)
    # All lines start at level=8 (above safety=4). UrgencyRank still dispatches.
    assert len(out.commitments) > 0


def test_urgency_rank_prefers_more_urgent_lines():
    """When two robots are equidistant, UrgencyRank serves the more-urgent line first."""
    cfg, sim = _build()
    # Make line 0 highly urgent, line 5 healthy
    sim.buffers[0].level = 1
    sim.buffers[5].level = 12
    ctrl = UrgencyRankController(slot_size=cfg.controller.slot_size_delta_seconds)
    state = sim._build_state()
    out = ctrl.decide(state)
    # Line 0 should be served (it's the most urgent)
    line0_served = any(c.job.line_id == 0 for c in out.commitments)
    assert line0_served, f"Expected line 0 to be served first; got {[c.job.line_id for c in out.commitments]}"


def test_urgency_rank_runs_episode_without_error():
    """End-to-end smoke."""
    cfg, sim = _build(horizon=120.0)
    ctrl = UrgencyRankController(slot_size=cfg.controller.slot_size_delta_seconds)
    sim.controller = ctrl; ctrl.reset()
    result = sim.run()
    assert result.delivered_total >= 0
    assert result.stockout_minutes < 1.0


def test_urgency_rank_does_not_double_assign_robots():
    """No two commitments share a robot id."""
    cfg, sim = _build()
    ctrl = UrgencyRankController(slot_size=cfg.controller.slot_size_delta_seconds)
    state = sim._build_state()
    out = ctrl.decide(state)
    rids = [c.robot_id for c in out.commitments]
    assert len(rids) == len(set(rids))


def test_urgency_rank_does_not_double_assign_totes():
    """A tote is committed to at most one robot."""
    cfg, sim = _build()
    ctrl = UrgencyRankController(slot_size=cfg.controller.slot_size_delta_seconds)
    state = sim._build_state()
    out = ctrl.decide(state)
    tids = [c.job.tote_id for c in out.commitments]
    assert len(tids) == len(set(tids))


# ---------------------------------------------------------------------------
# Comparative end-to-end
# ---------------------------------------------------------------------------

def test_urgency_rank_delivers_more_than_reactive_on_baseline_episode():
    """On a benign episode (no surge), UrgencyRank — being non-idle — should deliver
    at least as many totes as Reactive, which idles when no line is critical."""
    cfg, sim_react = _build(seed=0, horizon=300.0)
    react = ReactiveThresholdController(slot_size=cfg.controller.slot_size_delta_seconds)
    sim_react.controller = react; react.reset()
    r_react = sim_react.run()

    cfg2, sim_urg = _build(seed=0, horizon=300.0)
    urg = UrgencyRankController(slot_size=cfg2.controller.slot_size_delta_seconds)
    sim_urg.controller = urg; urg.reset()
    r_urg = sim_urg.run()

    # UrgencyRank dispatches even when no line is critical, so it should deliver more
    # (or equal — ties allowed for very short episodes).
    assert r_urg.delivered_total >= r_react.delivered_total - 1
