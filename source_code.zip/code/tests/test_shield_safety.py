"""Shield safety-invariant tests (Stage-3 checkpoint).

These tests must pass for any acceptance of a tactical commitment set.
"""

from __future__ import annotations

import pytest

from common.config import Config
from common.controller import Controller, ControllerOutput
from common.types import Commitment, Coord, Job
from common.enums import ServiceMode
from world.simulator import Simulator
from baselines.milp_only import MILPOnlyController
from baselines.random_controller import RandomController
from shield.prioritized import PrioritizedShield
from shield.repair import RepairAction
from shield.reservation_table import ReservationTable


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _Stub(Controller):
    name = "stub"
    def decide(self, s):
        return ControllerOutput([], {})


def _make_sim_with_shield(seed=0, horizon=600.0, controller_factory=None):
    cfg = Config.from_yaml("configs/base.yaml")
    cfg.experiment.episode_horizon_seconds = horizon
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    shield = PrioritizedShield(
        cfg=cfg.shield, grid=sim.grid,
        slot_size=cfg.controller.slot_size_delta_seconds,
    )
    shield.cfg.shield_repair_budget_slots = cfg.controller.shield_repair_budget_slots
    sim.shield = shield
    if controller_factory is not None:
        ctrl = controller_factory(cfg, sim)
        sim.controller = ctrl
        ctrl.reset()
    return cfg, sim


# ---------------------------------------------------------------------------
# Unit tests on the reservation table directly
# ---------------------------------------------------------------------------

def test_reservation_table_blocks_double_booking_of_same_node():
    """Two reservations for the same (cell, t) — only the first wins."""
    table = ReservationTable(step_seconds=1.0)
    assert table.reserve_node((3, 4), t_step=10, rid=1) is True
    # Second robot trying to take the same slot must be denied
    assert table.reserve_node((3, 4), t_step=10, rid=2) is False
    # The first robot can re-claim its own slot (idempotent)
    assert table.reserve_node((3, 4), t_step=10, rid=1) is True


def test_reservation_table_detects_swap_conflicts():
    """Two robots traversing the same edge in opposite directions on the same step."""
    table = ReservationTable(step_seconds=1.0)
    # Robot 1 goes from (0,0) to (1,0) during step 5
    table.reserve_edge((0, 0), (1, 0), t_step=5, rid=1)
    # Robot 2 wants to go (1,0) -> (0,0) during step 5 — that's a swap
    assert table.is_edge_free((1, 0), (0, 0), t_step=5, ignoring_rid=2) is False
    # But the same direction (0,0)->(1,0) is fine (would be blocked by node anyway)
    assert table.is_edge_free((0, 0), (1, 0), t_step=5, ignoring_rid=2) is True


def test_reservation_table_clears_per_robot():
    """``clear_robot`` removes only that robot's reservations."""
    table = ReservationTable(step_seconds=1.0)
    table.reserve_node((0, 0), t_step=0, rid=1)
    table.reserve_node((1, 0), t_step=0, rid=2)
    table.clear_robot(1)
    assert table.is_node_free((0, 0), 0)
    assert not table.is_node_free((1, 0), 0)


# ---------------------------------------------------------------------------
# Integration: collision-freedom invariant
# ---------------------------------------------------------------------------

def _check_no_collisions(table: ReservationTable) -> None:
    """Inspect the reservation table for any double-bookings or swaps."""
    # Vertex conflicts
    seen: dict[tuple[Coord, int], int] = {}
    for (cell, t), rid in table.node_reservations.items():
        prev = seen.get((cell, t))
        if prev is not None and prev != rid:
            raise AssertionError(f"Vertex conflict: ({cell}, t={t}) held by rid={prev} AND rid={rid}")
        seen[(cell, t)] = rid

    # Swap conflicts
    for (src, dst, t), rid in table.edge_reservations.items():
        reverse = (dst, src, t)
        other = table.edge_reservations.get(reverse)
        if other is not None and other != rid:
            raise AssertionError(
                f"Swap conflict: rid={rid} traversed {src}→{dst} at t={t} "
                f"while rid={other} traversed {dst}→{src}"
            )


def test_milp_with_shield_produces_no_vertex_or_swap_conflicts():
    """End-to-end: 5-min episode under MILPOnly + Shield has zero collisions."""
    pytest.importorskip("gurobipy")
    cfg, sim = _make_sim_with_shield(
        seed=0, horizon=300.0,
        controller_factory=lambda cfg, sim: MILPOnlyController(
            cfg=cfg, sim_handle=sim, max_slots_per_pair=1
        ),
    )
    sim.run()
    _check_no_collisions(sim.shield.table)


def test_random_with_shield_produces_no_collisions():
    """Random commitments through the shield also produce collision-free trajectories."""
    cfg, sim = _make_sim_with_shield(
        seed=1, horizon=300.0,
        controller_factory=lambda cfg, sim: RandomController(seed=1),
    )
    sim.run()
    _check_no_collisions(sim.shield.table)


def test_shield_on_2_robot_head_on_collision_avoids_swap():
    """Two robots ordered to swap positions must NOT execute a head-on swap."""
    cfg, sim = _make_sim_with_shield(seed=0, horizon=120.0)
    # Place two robots adjacent to each other (force the test by overriding pos)
    sim.robots[0].pos = (5, 5)
    sim.robots[1].pos = (6, 5)

    # Place totes in the OPPOSITE positions so robots want to cross
    # (Actually the simulator's storage is preset; just trust the shield's planner.)
    # Plan two tiny trips manually
    j0 = Job(line_id=0, tote_id=0, mode=ServiceMode.DIRECT)
    j1 = Job(line_id=1, tote_id=1, mode=ServiceMode.DIRECT)
    cm0 = Commitment(robot_id=0, job=j0, start_slot=0, epoch_time=0.0, slot_size=5.0)
    cm1 = Commitment(robot_id=1, job=j1, start_slot=0, epoch_time=0.0, slot_size=5.0)

    out = sim.shield.plan(
        state=sim._build_state(),
        commitments=[cm0, cm1],
        robot_positions={0: (5, 5), 1: (6, 5)},
        line_positions={0: (0, 5), 1: (0, 5)},
        tote_columns={0: (6, 5), 1: (5, 5)},   # they cross!
        pickup_seconds_for={(0, 0, 0): 6.0, (1, 1, 1): 6.0},
        lock_seconds_for={(0, 0, 0): 0.0, (1, 1, 1): 0.0},
        drop_seconds=8.0,
    )
    # No swap-conflict by construction of the reservation table
    _check_no_collisions(sim.shield.table)


def test_shield_releases_reservations_after_drop_done():
    """A robot's reservations are cleared when it completes a mission.

    Test indirectly: after a long enough episode, the reservation table size
    should not grow unbounded — old reservations get released.
    """
    pytest.importorskip("gurobipy")
    cfg, sim = _make_sim_with_shield(
        seed=0, horizon=300.0,
        controller_factory=lambda cfg, sim: MILPOnlyController(
            cfg=cfg, sim_handle=sim, max_slots_per_pair=1
        ),
    )
    sim.run()
    # Even with continuous activity, the active-reservation count at episode
    # end should be bounded by the number of in-flight robots × few seconds
    # of trajectory each, not by the cumulative number of deliveries.
    delivered = sum(b.served_count for b in sim.buffers)
    assert delivered > 0, "Sanity: at least one delivery completed"
    # Hard bound: at most num_robots × max_trajectory_steps_per_mission
    # For our config: 10 robots × ~50 steps/mission ≈ 500 reservations max.
    n_active_reservations = len(sim.shield.table.node_reservations)
    assert n_active_reservations < delivered * 30, (
        f"Reservation table has {n_active_reservations} entries after "
        f"{delivered} deliveries — released reservations should keep this bounded"
    )
