"""Time-expanded reservation table used by the prioritized planner.

A reservation table maps ``(node, time_step)`` to a robot id, recording
which robot occupies which node at which discrete time. The shield uses
this to plan robot ``r`` against all higher-priority robots already
planned. Edge swaps are also forbidden (vertex-edge conflicts).

The temporal resolution is the floor-graph step time
``cell_size / nominal_speed``; the planner only reasons in integer steps.
Service-induced obstacles (excavation locks) are recorded as continuous-time
windows and translated to discrete steps on lookup.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from common.types import Coord


@dataclass
class ReservationTable:
    """Sparse reservation table for prioritized MAPF.

    Three indexed views:

    * ``node_reservations[(coord, t)] = rid`` for vertex conflicts
    * ``edge_reservations[(coord_a, coord_b, t)] = rid`` for swap conflicts
    * ``service_locks[(coord, t_lo, t_hi)] = rid`` for excavation footprints
      (treated as time-bounded static obstacles)
    """

    step_seconds: float
    node_reservations: dict[tuple[Coord, int], int] = field(default_factory=dict)
    edge_reservations: dict[tuple[Coord, Coord, int], int] = field(default_factory=dict)
    service_locks: list[tuple[Coord, float, float, int]] = field(default_factory=list)

    # ------------------------------------------------------------------ time conversion

    def time_to_step(self, t: float) -> int:
        """Convert continuous time (seconds) to nearest step index (floor)."""
        return int(t / self.step_seconds + 1e-9)

    def step_to_time(self, t_step: int) -> float:
        """Inverse of ``time_to_step``: continuous-time start of step."""
        return t_step * self.step_seconds

    # ------------------------------------------------------------------ Reservations

    def reserve_node(self, coord: Coord, t_step: int, rid: int) -> bool:
        """Reserve a node at a discrete time step.

        Returns True if reservation succeeded. Returns False if some other
        robot already holds this slot. Idempotent for the same robot.
        """
        key = (coord, t_step)
        owner = self.node_reservations.get(key)
        if owner is None:
            self.node_reservations[key] = rid
            return True
        return owner == rid

    def reserve_edge(self, src: Coord, dst: Coord, t_step: int, rid: int) -> bool:
        """Reserve a directed traversal during step ``[t, t+1)``.

        Conflict definition: another robot traverses the reverse edge
        (dst → src) during the same step interval — a "swap" conflict.
        Same-direction traversals are NOT a conflict (would mean two robots
        at the same source cell at the same time, which is caught by the
        node reservation instead).
        """
        # Same-edge same-direction is not a conflict (caught by node_reservations);
        # we just need to track this traversal for swap detection.
        key = (src, dst, t_step)
        owner = self.edge_reservations.get(key)
        if owner is None:
            self.edge_reservations[key] = rid
            return True
        if owner == rid:
            return True
        # Different robot taking same edge same direction — node reservation
        # should already block this; here we just record a conflict.
        return False

    def reserve_window(self, coord: Coord, t_start_step: int, t_end_step: int, rid: int) -> bool:
        """Reserve a contiguous window of node-occupancy.

        ``[t_start_step, t_end_step)`` inclusive of start, exclusive of end.
        Returns True iff every step in the window was reserve-able.
        """
        # First check all are free (or owned by us)
        for t in range(t_start_step, t_end_step):
            owner = self.node_reservations.get((coord, t))
            if owner is not None and owner != rid:
                return False
        # Now reserve them all
        for t in range(t_start_step, t_end_step):
            self.node_reservations[(coord, t)] = rid
        return True

    def reserve_service(self, coord: Coord, t_start: float, t_end: float, rid: int) -> None:
        """Mark a coord as a static obstacle for the continuous interval ``[t_start, t_end)``.

        Used for excavation lock windows ``I^lock_{rj,b}(q)``. We also expand
        this into discrete-step node reservations so the time-expanded
        planner sees them through the same lookup path.
        """
        self.service_locks.append((coord, t_start, t_end, rid))
        t0 = self.time_to_step(t_start)
        t1 = self.time_to_step(t_end + self.step_seconds * 0.999)  # ceil-ish
        for t in range(t0, t1 + 1):
            self.node_reservations[(coord, t)] = rid

    # ------------------------------------------------------------------ Queries

    def is_node_free(self, coord: Coord, t_step: int, ignoring_rid: int | None = None) -> bool:
        """Is ``coord`` free at step ``t_step``? ``None`` (not reserved) means free."""
        owner = self.node_reservations.get((coord, t_step))
        return owner is None or owner == ignoring_rid

    def is_edge_free(
        self, src: Coord, dst: Coord, t_step: int, ignoring_rid: int | None = None
    ) -> bool:
        """Is the directed traversal src→dst at step t_step admissible?

        Blocked iff the reverse edge (dst → src) at the same step is taken
        by another robot — that would be a head-on swap.
        """
        reverse = (dst, src, t_step)
        owner = self.edge_reservations.get(reverse)
        return owner is None or owner == ignoring_rid

    def is_service_blocked(self, coord: Coord, t: float) -> bool:
        """O(|service_locks|) check; only used for diagnostics."""
        for c, t0, t1, _ in self.service_locks:
            if c == coord and t0 <= t < t1:
                return True
        return False

    # ------------------------------------------------------------------ Maintenance

    def clear_robot(self, rid: int) -> None:
        """Remove all reservations held by robot ``rid``.

        Called when the robot completes a mission (drop_done) so its slots
        become available for future planning.
        """
        self.node_reservations = {
            k: v for k, v in self.node_reservations.items() if v != rid
        }
        self.edge_reservations = {
            k: v for k, v in self.edge_reservations.items() if v != rid
        }
        self.service_locks = [s for s in self.service_locks if s[3] != rid]

    def clear_before(self, t_step: int) -> None:
        """Drop reservations for steps strictly before ``t_step``.

        Used to keep the table from growing unbounded across long episodes.
        """
        self.node_reservations = {
            k: v for k, v in self.node_reservations.items() if k[1] >= t_step
        }
        self.edge_reservations = {
            k: v for k, v in self.edge_reservations.items() if k[2] >= t_step
        }

    def clear(self) -> None:
        self.node_reservations.clear()
        self.edge_reservations.clear()
        self.service_locks.clear()

    # ------------------------------------------------------------------ Diagnostics

    def __len__(self) -> int:
        return len(self.node_reservations)

    def num_robots_reserved(self) -> int:
        return len({rid for rid in self.node_reservations.values()})
