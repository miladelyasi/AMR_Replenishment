"""NullShield -- a passthrough shield used during Stage-1 simulator development.

It accepts every commitment, computes naive single-robot trajectories
(piecewise-constant: depart now, arrive at pickup, complete pickup,
arrive at drop, complete drop), and reserves no shared resources. This
is useful only for validating the simulator pipeline in isolation; the
real ``PrioritizedShield`` (Stage 3) replaces it for collision-free
multi-robot execution.

The interface matches that of ``PrioritizedShield`` so callers can swap
implementations without changes.
"""

from __future__ import annotations

from common.state import SystemState
from common.types import Commitment, Trajectory, TrajectoryStep
from shield.prioritized import ShieldOutput
from world.grid import FloorGraph
from world.robot import RobotState
from world.storage import StorageSystem


class NullShield:
    """Passthrough shield. Always accepts; produces straight-line trajectories."""

    name = "NullShield"

    def __init__(
        self,
        grid: FloorGraph,
        storage: StorageSystem,
        robots: list[RobotState],
        line_interfaces: dict[int, tuple[int, int]],
    ):
        self.grid = grid
        self.storage = storage
        self.robots = robots
        self.line_interfaces = line_interfaces  # lid -> (x, y)

    def plan(
        self,
        state: SystemState,
        commitments: list[Commitment],
        tactical_src_windows=None,
        tactical_dst_windows=None,
        tactical_block_windows=None,
    ) -> ShieldOutput:
        accepted: list[Commitment] = []
        trajectories: dict[int, Trajectory] = {}

        for c in commitments:
            r = next((r for r in self.robots if r.rid == c.robot_id), None)
            if r is None:
                continue
            tote_cell = self.storage.find_tote_column(c.job.tote_id)
            line_cell = self.line_interfaces.get(c.job.line_id)
            if tote_cell is None or line_cell is None:
                continue

            t0 = c.absolute_start_time
            t_pick_arrive = t0 + self.grid.travel_time(r.pos, tote_cell)
            traj = Trajectory(
                robot_id=c.robot_id,
                steps=[
                    TrajectoryStep(time=t0, node=r.pos),
                    TrajectoryStep(time=t_pick_arrive, node=tote_cell),
                ],
            )
            trajectories[c.robot_id] = traj
            accepted.append(c)

        return ShieldOutput(
            accepted=accepted,
            deferred=[],
            rejected=[],
            trajectories=trajectories,
            realized_src_reservations={},
            realized_dst_reservations={},
            realized_block_reservations={},
            repair_actions=[],
            runtime_ms=0.0,
        )
