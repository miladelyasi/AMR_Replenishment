"""Counterfactual: keep service occupancy; omit inter-robot travel conflicts.

This is an infeasible-motion benchmark, never a deployment policy. It uses
the same event timing, battery debit and service durations as PrioritizedShield.
"""
from .prioritized import PrioritizedShield
from .reservation_table import ReservationTable


class TravelRelaxedShield(PrioritizedShield):
    def _astar_time_expanded(self, *args, **kwargs):
        service_table = self.table
        self.table = ReservationTable(step_seconds=self.step_seconds)
        try:
            return super()._astar_time_expanded(*args, **kwargs)
        finally:
            self.table = service_table

    def _commit_to_reservations(self, mission):
        rid = int(mission.commitment.robot_id)
        for cell, lo, hi in [
            (mission.path_to_pickup[-1], mission.arrive_pickup_time, mission.pickup_done_time),
            (mission.path_to_drop[-1], mission.arrive_drop_time, mission.drop_done_time),
        ]:
            for t in range(self.table.time_to_step(lo), self.table.time_to_step(hi)):
                assert self.table.reserve_node(cell, t, rid)
