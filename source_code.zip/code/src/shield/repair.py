"""Lexicographic shield-repair logic (Section 4.3 of the manuscript).

When the nominal start slot of a tactical commitment cannot be exactly
realized on the floor graph, the shield applies, in order:

1. **Bounded local shift** — try start slots ``q +/- 1, ..., q +/- Delta_sh``.
2. **Protected waiting** — keep the start slot but insert waits / local
   reroutes on safe non-critical nodes.
3. **Selective deferral** — drop the lowest-value conflicting commitment.
   If the deferred job has ``hat_T^so_l <= T_crit``, the simulator is
   notified to trigger an early decision epoch; otherwise the deferral
   is absorbed into the next nominal review.

This module exposes only the mechanism; the policy decisions
("which commitment is lowest-value?") are encapsulated as ``priority``
callables passed in by ``PrioritizedShield``.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum

from common.types import Commitment, Trajectory


class RepairAction(IntEnum):
    """Outcome of one repair attempt."""

    NONE = 0                  # no repair needed
    SHIFTED = 1               # bounded local shift succeeded
    WAITED = 2                # protected waiting/local reroute succeeded
    DEFERRED = 3              # commitment deferred to next epoch
    DEFERRED_HIGH_URGENCY = 4 # deferred AND triggers early epoch
    REJECTED = 5              # commitment rejected outright (no plan exists)


@dataclass
class RepairResult:
    """One row of the per-epoch repair log."""

    commitment: Commitment
    action: RepairAction
    shift_slots: int = 0                   # signed; 0 if no shift
    extra_wait_seconds: float = 0.0
    new_trajectory: Trajectory | None = None
    notes: str = ""


def try_bounded_shift(
    commitment: Commitment,
    repair_budget_slots: int,
    plan_fn,                    # callable: (commitment, start_slot) -> Trajectory | None
) -> RepairResult:
    """Try ``q + k`` for ``k in [-Δ_sh, +Δ_sh]`` (excluding 0)."""
    raise NotImplementedError


def try_protected_waiting(
    commitment: Commitment,
    plan_fn_with_waits,         # callable: (commitment) -> Trajectory | None
    max_wait_steps: int,
) -> RepairResult:
    """Insert wait actions on safe non-critical nodes."""
    raise NotImplementedError


def selective_deferral(
    commitment: Commitment,
    is_high_urgency: bool,
) -> RepairResult:
    """Defer the commitment; flag early-epoch trigger if high urgency."""
    raise NotImplementedError
