"""Construction of the feasible index set ``F_n`` and candidate job set ``J_n``.

Implements:

* ``build_job_set`` — eq. (job-set) plus urgency-based pruning.
* ``build_feasible_set`` — eq. (feasible-set), enforcing all five
  conditions of Section 4.2:

  1. ``q*Delta >= tau_free_r``
  2. ``g_{l,u} = 1`` and ``m in M_{u,n}`` (mode consistent with access class)
  3. travel surrogates finite
  4. ``c_{rj}(q) <= H``
  5. ``b^r_n - b_min_r >= energy_{rj,n}``  (pointwise pre-check)

The exact battery constraint is then re-enforced as eq. (battery) inside
the MILP (global linear constraint over all simultaneously selected
commitments).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable

from common.config import CandidatePruningConfig
from common.enums import AccessClass, ServiceMode
from common.state import SystemState
from common.types import Job


# ---------------------------------------------------------------------------
# Job set (eq. job-set)
# ---------------------------------------------------------------------------

_ACCESS_TO_MODE = {
    AccessClass.DIRECT: ServiceMode.DIRECT,
    AccessClass.EXCAVATION: ServiceMode.EXCAVATION,
}


def build_job_set(
    state: SystemState,
    pruning: CandidatePruningConfig,
) -> list[Job]:
    """Construct the candidate job set ``J_n``.

    Steps:

    1. Iterate over ``(l, u)`` such that ``g_{l,u} = 1``.
    2. Determine ``m`` from ``a_{u,n}`` (eq. mode-set); skip if INFEASIBLE.
    3. Apply urgency-based pruning:
       * keep at most ``max_jobs_total`` jobs system-wide
       * keep at most ``max_jobs_per_line`` jobs per production line
       * priority is ``hat_T_so[l]`` ascending (most urgent line first),
         then prefer DIRECT over EXCAVATION (cheaper service).
    """
    jobs: list[Job] = []
    line_count: dict[int, int] = {int(lid): 0 for lid in state.line_ids}

    # Group candidates by line so per-line pruning is local.
    per_line_candidates: dict[int, list[tuple[float, int, Job]]] = {
        int(lid): [] for lid in state.line_ids
    }

    for (lid, uid), g in state.sku_compat.items():
        if g != 1:
            continue
        access = state.access.get(uid)
        if access is None or access == AccessClass.INFEASIBLE:
            continue
        mode = _ACCESS_TO_MODE[access]
        # Sort key: (urgency rank, mode preference). Smaller is better.
        urgency_rank = float(state.hat_T_so[int(lid)])
        # DIRECT (==1 in ServiceMode if we keep ordering loose); compute via enum value
        mode_priority = 0 if mode == ServiceMode.DIRECT else 1
        sort_key = (urgency_rank, mode_priority)
        per_line_candidates[int(lid)].append((urgency_rank + 1e-3 * mode_priority, uid, Job(line_id=int(lid), tote_id=int(uid), mode=mode)))

    # Per-line cap
    for lid, lst in per_line_candidates.items():
        lst.sort(key=lambda t: t[0])
        capped = lst[: pruning.max_candidates_per_line]
        for _, _, j in capped:
            jobs.append(j)
            line_count[lid] += 1

    # Global cap (if total exceeds, drop the least-urgent jobs)
    global_cap = min(pruning.max_total_candidates, pruning.max_jobs)
    if len(jobs) > global_cap:
        # Re-sort by their owning line's urgency
        jobs.sort(key=lambda j: state.hat_T_so[j.line_id])
        jobs = jobs[: global_cap]

    return jobs


# ---------------------------------------------------------------------------
# Feasible (r, j, q) triples (eq. feasible-set)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FeasibleTriple:
    """A single ``(r, j, q) in F_n`` with all derived service quantities cached."""

    robot_id: int
    job: Job
    start_slot: int

    # Cached for MILP coefficient assembly
    travel_to_tote: float           # hat_tau^xy_{r,u}
    travel_to_line: float           # hat_tau^xy_{u,l}
    pickup_seconds: float           # t^pick
    lock_seconds: float             # t^lock
    drop_seconds: float             # t^drop
    completion_time: float          # c_{rj}(q)

    risk: float                     # max(0, c - hat_T_so)
    energy: float                   # energy_{rj,n}
    crowd: float                    # congestion proxy


def build_feasible_set(
    state: SystemState,
    jobs: list[Job],
    eligible_robot_ids: Iterable[int],
    *,
    horizon_seconds: float,
    slot_size: float,
    num_slots: int,
    battery_min_per_robot: dict[int, float],
    travel_to_tote_fn: Callable[[int, int], float],   # (rid, uid) -> seconds
    travel_to_line_fn: Callable[[int, int], float],   # (uid, lid) -> seconds
    pickup_dur_fn: Callable[[int, int, ServiceMode], float],  # (depth, support, mode)
    lock_dur_fn: Callable[[int, int, ServiceMode], float],
    energy_fn: Callable[[int, Job, float, float, int, ServiceMode], float],
    drop_seconds: float,
    crowd_fn: Callable[[int, Job], float] | None = None,
    max_slots_per_pair: int | None = None,
) -> list[FeasibleTriple]:
    """Assemble the feasible index set ``F_n``.

    Returns a flat list of ``FeasibleTriple`` objects. The caller (the
    MILP builder) consumes this directly, eliminating the need for a
    separate sparsity check.

    Parameters
    ----------
    max_slots_per_pair
        If set, keep only the ``max_slots_per_pair`` smallest-``q``
        triples per ``(r, j)`` pair. Useful for size-limited solvers
        (e.g. restricted Gurobi license) and for online tractability.
        Set to ``1`` to keep only the earliest feasible start slot.

    Notes
    -----
    * Travel-surrogate functions return ``float('inf')`` when there is no
      reachable path (handled by Condition 3).
    * ``energy_fn`` takes (rid, job, travel_to_tote, travel_to_line, depth, mode)
      so callers can compute mission-specific energy without round-tripping.
    """
    triples: list[FeasibleTriple] = []
    eligible_set = set(int(r) for r in eligible_robot_ids)
    epoch_t = float(state.epoch_time)

    for rid in eligible_set:
        b_r = float(state.battery[rid])
        b_min = float(battery_min_per_robot.get(rid, 0.0))
        # tau_free is absolute time; slots are relative to epoch_time
        tau_free_r = max(0.0, float(state.tau_free[rid]) - epoch_t)

        for job in jobs:
            uid = int(job.tote_id)
            lid = int(job.line_id)

            # Condition 2 (mode consistent): we already filtered in build_job_set,
            # but recheck here in case access state changed between calls.
            access = state.access.get(uid)
            if access is None or access == AccessClass.INFEASIBLE:
                continue
            expected_mode = _ACCESS_TO_MODE[access]
            if expected_mode != job.mode:
                continue
            if state.sku_compat.get((lid, uid), 0) != 1:
                continue

            depth = int(state.stack_depth.get(uid, 0))
            support = int(state.support.get(uid, 0))

            # Condition 3 (travel surrogates finite)
            tau_rt = travel_to_tote_fn(rid, uid)
            tau_tl = travel_to_line_fn(uid, lid)
            if not (tau_rt < float("inf") and tau_tl < float("inf")):
                continue

            t_pick = pickup_dur_fn(depth, support, job.mode)
            t_lock = lock_dur_fn(depth, support, job.mode)

            # Compute completion at start_slot=0 first; if even q=0 doesn't fit,
            # this (r, j) pair is infeasible at every slot.
            base_completion_q0 = tau_rt + t_pick + tau_tl + drop_seconds
            if base_completion_q0 > horizon_seconds:
                continue

            # Condition 5 (battery pointwise pre-check)
            mission_energy = energy_fn(rid, job, tau_rt, tau_tl, depth, job.mode)
            if (b_r - b_min) < mission_energy:
                continue

            # Condition 1: q*delta >= tau_free_r ; Condition 4: completion <= H.
            # Compute the smallest feasible q (q_min) from tau_free.
            q_min = max(0, int(-(-tau_free_r // slot_size)))   # ceil(tau_free/delta)
            # Largest q such that completion fits: q*delta + base <= H
            q_max = int((horizon_seconds - base_completion_q0) // slot_size)
            if q_max < q_min:
                continue
            q_max = min(q_max, num_slots - 1)
            if q_max < q_min:
                continue

            # Risk and crowd at q_min (cheap aggregate; the MILP recomputes risk
            # for each chosen q via coefficients).
            crowd = crowd_fn(rid, job) if crowd_fn else 0.0
            hat_T_so_l = float(state.hat_T_so[lid])

            q_iter_max = q_max
            if max_slots_per_pair is not None:
                q_iter_max = min(q_max, q_min + max_slots_per_pair - 1)

            for q in range(q_min, q_iter_max + 1):
                completion = q * slot_size + base_completion_q0
                risk = max(0.0, completion - hat_T_so_l)
                triples.append(FeasibleTriple(
                    robot_id=rid,
                    job=job,
                    start_slot=q,
                    travel_to_tote=tau_rt,
                    travel_to_line=tau_tl,
                    pickup_seconds=t_pick,
                    lock_seconds=t_lock,
                    drop_seconds=drop_seconds,
                    completion_time=completion,
                    risk=risk,
                    energy=mission_energy,
                    crowd=crowd,
                ))
    return triples
