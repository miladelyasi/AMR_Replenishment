"""Service-window construction and slot-overlap indicators.

Implements equations (pickwindow), (dropwindow), (lockwindow), and the
``Gamma^src``, ``Gamma^dst``, ``Gamma^lock`` indicator functions of
Section 4.2 of the manuscript.

The MILP is indexed by *start slots* ``q in T = {0, ..., N-1}``, but its
capacity constraints are enforced over arbitrary slot intersections with
half-open continuous-time service windows. This module precomputes those
overlap indicators so the MILP build step is linear-time.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from common.enums import ServiceMode


# ---------------------------------------------------------------------------
# Service-time helpers (eq. picktime, eq. locktime)
# ---------------------------------------------------------------------------

def pickup_duration(
    depth: int,
    support: int,
    mode: ServiceMode,
    *,
    base: float,
    per_depth: float,
    excavation_overhead: float,
    epsilon_0: float,
) -> float:
    """``t^pick_{u,m,n}`` per eq. (picktime).

    Direct mode:    t = t_0 + kappa_h * d
    Excavation:     t = t_0 + kappa_h * d + kappa_e * max(d-1, 0) / max(phi, eps_0)
    """
    base_term = base + per_depth * depth
    if mode == ServiceMode.EXCAVATION:
        denom = max(float(support), epsilon_0)
        return base_term + excavation_overhead * max(depth - 1, 0) / denom
    return base_term


def lock_duration(
    depth: int,
    support: int,
    mode: ServiceMode,
    *,
    per_depth: float,
    excavation_overhead: float,
    epsilon_0: float,
) -> float:
    """``t^lock_{u,m,n}`` per eq. (locktime). Same shape as pickup_duration."""
    if mode == ServiceMode.EXCAVATION:
        denom = max(float(support), epsilon_0)
        return per_depth * depth + excavation_overhead * max(depth - 1, 0) / denom
    return per_depth * depth


# ---------------------------------------------------------------------------
# Windows (continuous time, half-open intervals)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Window:
    """A half-open continuous-time interval ``[start, end)``."""

    start: float
    end: float

    def overlaps_slot(self, slot: int, slot_size: float) -> bool:
        s_start = slot * slot_size
        s_end = s_start + slot_size
        return (self.start < s_end) and (self.end > s_start)

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


def compute_pickup_window(
    *,
    start_slot: int,
    slot_size: float,
    travel_to_tote_seconds: float,
    pickup_seconds: float,
) -> Window:
    """``I^src_{rj,z_u}(q)`` — eq. (pickwindow).

    The window starts when the robot arrives at the source column (so the
    vertical interface usage *begins*) and ends when the pickup completes.
    """
    arrival = start_slot * slot_size + travel_to_tote_seconds
    return Window(arrival, arrival + pickup_seconds)


def compute_drop_window(
    *,
    start_slot: int,
    slot_size: float,
    travel_to_tote_seconds: float,
    pickup_seconds: float,
    travel_to_line_seconds: float,
    completion_time: float,
) -> Window:
    """``I^dst_{rj,z_l}(q)`` — eq. (dropwindow)."""
    arrival_at_line = (
        start_slot * slot_size
        + travel_to_tote_seconds
        + pickup_seconds
        + travel_to_line_seconds
    )
    return Window(arrival_at_line, completion_time)


def compute_lock_window(
    *,
    start_slot: int,
    slot_size: float,
    travel_to_tote_seconds: float,
    lock_seconds: float,
) -> Window:
    """``I^lock_{rj,b}(q)`` — eq. (lockwindow).

    Local-blocking interval starts when the robot reaches the column and
    lasts ``t^lock`` seconds.
    """
    arrival = start_slot * slot_size + travel_to_tote_seconds
    return Window(arrival, arrival + lock_seconds)


# ---------------------------------------------------------------------------
# Slot-overlap indicators Γ
# ---------------------------------------------------------------------------

def slot_overlap_indicators(
    window: Window,
    num_slots: int,
    slot_size: float,
) -> np.ndarray:
    """Return a 0/1 vector of length ``num_slots``.

    Entry ``tau`` is 1 iff the slot ``[tau*delta, (tau+1)*delta)`` intersects
    ``window`` non-emptily. Used in eqs. (Γ^src), (Γ^dst), (Γ^lock).

    Half-open semantics: a window touching the slot boundary on the right
    (window.end == slot_start) does NOT count; a window starting exactly at
    a slot boundary (window.start == slot_start) DOES count.
    """
    out = np.zeros(num_slots, dtype=np.int8)
    if window.duration <= 0.0:
        return out

    # Find first slot whose right edge > window.start
    first_slot = max(0, int(np.floor(window.start / slot_size)))
    # Find last slot whose left edge < window.end
    last_slot = min(num_slots - 1, int(np.ceil(window.end / slot_size)) - 1)

    if first_slot > last_slot:
        return out

    # Double-check using the proper half-open intersection rule
    for tau in range(first_slot, last_slot + 1):
        s_start = tau * slot_size
        s_end = s_start + slot_size
        if (window.start < s_end) and (window.end > s_start):
            out[tau] = 1
    return out


def slot_indices_overlapping(
    window: Window,
    num_slots: int,
    slot_size: float,
) -> list[int]:
    """Sparse version: list of slot indices that overlap.

    Useful for MILP build (avoids materializing the dense 0/1 vector when
    most slots are empty).
    """
    if window.duration <= 0.0:
        return []
    first_slot = max(0, int(np.floor(window.start / slot_size)))
    last_slot = min(num_slots - 1, int(np.ceil(window.end / slot_size)) - 1)
    out = []
    for tau in range(first_slot, last_slot + 1):
        s_start = tau * slot_size
        s_end = s_start + slot_size
        if (window.start < s_end) and (window.end > s_start):
            out.append(tau)
    return out
