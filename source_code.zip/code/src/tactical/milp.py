"""Time-indexed assignment-and-reservation MILP (Section 4.2).

Implements the optimization model

::

    min   sum (alpha^M * risk + beta^M * travel + nu^M * energy
              + xi^M * crowd - varrho * w_{rj}) * x_{rjq}
        + sum P_j * (1 - v_j)

    s.t. (robot-at-most-one)     sum_{j,q} x_{rjq} <= 1
         (job-service)           sum_{r,q} x_{rjq} == v_j
         (reachability)          x_{rjq} = 0 for (r,j,q) ∉ F_n
         (src-capacity)          R^src + sum Γ^src * x  <=  C^V_z
         (dst-capacity)          R^dst + sum Γ^dst * x  <=  C^V_z
         (block-capacity)        R^B   + sum Γ^lock * x <=  C^B_b
         (battery)               sum energy * x  <=  b - b_min

The model uses **flat indexing**: variables ``x_k`` for ``k = 1..|F_n|``
(one per feasible triple) plus ``v_j`` per job. Sparse coefficient
assembly keeps Gurobi build time low.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from common.config import MILPConfig
from common.state import SystemState
from common.types import Commitment, Job

from .feasibility import FeasibleTriple
from .windows import (
    compute_drop_window,
    compute_lock_window,
    compute_pickup_window,
    slot_indices_overlapping,
)

if TYPE_CHECKING:
    import gurobipy as gp


# ---------------------------------------------------------------------------
# Solution container
# ---------------------------------------------------------------------------

@dataclass
class TacticalSolution:
    """Output of one MILP solve."""

    commitments: list[Commitment]
    served_jobs: list[Job]
    unserved_jobs: list[Job]
    objective: float
    runtime_ms: float
    mip_gap: float
    status: str                      # "OPTIMAL" | "TIME_LIMIT" | "INFEASIBLE" | ...
    diagnostics: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------------------

class TacticalMILP:
    """Stateful Gurobi model with warm-start support across consecutive epochs.

    The Gurobi environment is built lazily on the first call to ``solve`` so
    that simply importing this module does not require a license.
    """

    _STATUS_NAMES = {
        2: "OPTIMAL",
        3: "INFEASIBLE",
        4: "INF_OR_UNBD",
        5: "UNBOUNDED",
        9: "TIME_LIMIT",
        11: "INTERRUPTED",
        13: "SUBOPTIMAL",
    }

    def __init__(self, cfg: MILPConfig, num_slots: int, slot_size: float):
        self.cfg = cfg
        self.num_slots = num_slots
        self.slot_size = slot_size
        self._env: "gp.Env | None" = None
        # Cache of previous solution for warm-starts:
        # key (rid, lid, uid, mode_value, q) -> 1.0
        self._previous_solution_cache: dict[tuple, float] = {}

    # ------------------------------------------------------------------ API

    def solve(
        self,
        state: SystemState,
        feasible: list[FeasibleTriple],
        jobs: list[Job],
        score_field: dict[tuple[int, int, int], float],
        carried_src: np.ndarray,
        carried_dst: np.ndarray,
        carried_block: np.ndarray,
        battery_remaining: dict[int, float],
        capacities_src: np.ndarray,
        capacities_dst: np.ndarray,
        capacities_block: np.ndarray,
        tote_to_src_idx: dict[int, int],
        line_to_dst_idx: dict[int, int],
        tote_to_block_indices: dict[int, list[int]],
        ablation_flags: dict | None = None,
    ) -> TacticalSolution:
        """Build and solve the tactical MILP.

        Returns an empty solution (no commitments) if ``feasible`` is empty.
        """
        if not feasible:
            return TacticalSolution(
                commitments=[],
                served_jobs=[],
                unserved_jobs=list(jobs),
                objective=0.0,
                runtime_ms=0.0,
                mip_gap=0.0,
                status="EMPTY",
                diagnostics={"num_feasible": 0, "num_jobs": len(jobs)},
            )

        ablation_flags = ablation_flags or {}
        import gurobipy as gp

        model = self._build_model()
        x, v = self._add_decision_variables(model, feasible, jobs)
        self._add_objective(model, x, v, feasible, jobs, score_field, state, ablation_flags)
        self._add_assignment_constraints(model, x, v, feasible, jobs)
        self._add_capacity_constraints(
            model, x, feasible,
            carried_src, carried_dst, carried_block,
            capacities_src, capacities_dst, capacities_block,
            tote_to_src_idx, line_to_dst_idx, tote_to_block_indices,
            ablation_flags,
        )
        self._add_battery_constraint(model, x, feasible, battery_remaining)

        # Warm-start from the previous incumbent (if any)
        self._apply_warm_start(x, feasible)

        t0 = time.perf_counter()
        model.optimize()
        runtime_ms = 1000.0 * (time.perf_counter() - t0)

        sol = self._extract_solution(model, x, v, feasible, jobs, state.epoch_time, runtime_ms)

        # Cache solution for next warm-start
        self._previous_solution_cache.clear()
        for k, ft in enumerate(feasible):
            try:
                if x[k].X > 0.5:
                    key = self._triple_key(ft)
                    self._previous_solution_cache[key] = 1.0
            except (AttributeError, gp.GurobiError):
                pass
        return sol

    # ------------------------------------------------------------------
    # Internal: model construction
    # ------------------------------------------------------------------

    def _build_model(self) -> "gp.Model":
        import gurobipy as gp
        if self._env is None:
            self._env = gp.Env(empty=True)
            self._env.setParam("OutputFlag", 0)
            self._env.start()
        m = gp.Model(env=self._env)
        # Apply solver params from config
        s = self.cfg.solver
        m.setParam("TimeLimit", s.time_limit_ms / 1000.0)
        m.setParam("MIPGap", s.mip_gap)
        m.setParam("Threads", s.threads)
        m.setParam("Presolve", int(s.presolve))
        # We always silence here; the simulator can wrap with logging if needed.
        m.setParam("OutputFlag", 0)
        return m

    def _add_decision_variables(
        self, model: "gp.Model", feasible: list[FeasibleTriple], jobs: list[Job]
    ) -> tuple[dict, dict]:
        # x_k for each feasible triple (flat indexed)
        x = model.addVars(len(feasible), vtype="B", name="x")
        # v_j for each job (binary; whether it's served in this horizon)
        v = model.addVars(len(jobs), vtype="B", name="v")
        return x, v

    def _add_objective(
        self,
        model: "gp.Model",
        x: dict,
        v: dict,
        feasible: list[FeasibleTriple],
        jobs: list[Job],
        score_field: dict,
        state: SystemState,
        ablation_flags: dict,
    ) -> None:
        import gurobipy as gp
        w = self.cfg.weights
        eps0 = 1e-3   # avoid division by zero in P_j

        # Whether to use the RL preference scores (score_field).
        # When ablating, this is set to zero by passing an empty score_field
        # OR by setting use_rl=False here.
        use_rl = not ablation_flags.get("disable_rl_scores", False)

        # Pre-compute job-index lookup for the v[j] term coefficients
        job_to_index = {j.key(): i for i, j in enumerate(jobs)}

        # Build linear objective: sum over feasible triples + sum over jobs
        triple_obj = []
        for k, ft in enumerate(feasible):
            travel = ft.travel_to_tote + ft.travel_to_line
            score_w = 0.0
            if use_rl:
                key = (ft.robot_id, ft.job.line_id, ft.job.tote_id)
                score_w = score_field.get(key, 0.0)
            coef = (
                w.alpha_M * ft.risk
                + w.beta_M * travel
                + w.nu_M * ft.energy
                + w.xi_M * ft.crowd
                - w.varrho * score_w
            )
            triple_obj.append(coef * x[k])

        # Job non-service penalties: P_j = P_0 / max(hat_T_so_l, eps_0)
        # per Sec. 4.2 "Objective" paragraph. The base penalty P_0 must be
        # large enough that P_j dominates a typical cost-to-serve at the
        # safety-stock boundary; with the default P_0 = 10000, P_j(B=S) ≈ 60,
        # which exceeds typical (β^M * travel ≈ 25–50) at base.yaml weights.
        P0 = w.P_0
        job_penalty_terms = []
        for j_idx, job in enumerate(jobs):
            T_so = float(state.hat_T_so[job.line_id])
            P_j = P0 / max(T_so, eps0)
            job_penalty_terms.append(P_j * (1 - v[j_idx]))

        model.setObjective(gp.quicksum(triple_obj) + gp.quicksum(job_penalty_terms),
                           gp.GRB.MINIMIZE)

    def _add_assignment_constraints(
        self,
        model: "gp.Model",
        x: dict,
        v: dict,
        feasible: list[FeasibleTriple],
        jobs: list[Job],
    ) -> None:
        import gurobipy as gp

        # Group triple indices by robot and by job key
        by_robot: dict[int, list[int]] = {}
        by_job: dict[tuple, list[int]] = {}
        for k, ft in enumerate(feasible):
            by_robot.setdefault(ft.robot_id, []).append(k)
            by_job.setdefault(ft.job.key(), []).append(k)

        # eq. (robot-at-most-one):   sum_{j,q} x_{rjq} <= 1
        for rid, ks in by_robot.items():
            model.addConstr(
                gp.quicksum(x[k] for k in ks) <= 1,
                name=f"robot_one_{rid}",
            )

        # eq. (job-service):   sum_{r,q} x_{rjq} == v_j
        job_to_index = {j.key(): i for i, j in enumerate(jobs)}
        for jkey, ks in by_job.items():
            j_idx = job_to_index[jkey]
            model.addConstr(
                gp.quicksum(x[k] for k in ks) == v[j_idx],
                name=f"job_service_{j_idx}",
            )
        # Jobs without any feasible triple: pin v_j = 0 explicitly
        for jkey, j_idx in job_to_index.items():
            if jkey not in by_job:
                model.addConstr(v[j_idx] == 0, name=f"job_unservable_{j_idx}")

        # Distinct destination/mode jobs may refer to the same physical tote.
        # Singleton groups are already bounded by binary v; omitting their
        # redundant rows preserves the benchmark's one-SKU-per-line models.
        by_tote: dict[int, list[int]] = {}
        for j_idx, job in enumerate(jobs):
            by_tote.setdefault(job.tote_id, []).append(j_idx)
        for uid, indices in by_tote.items():
            if len(indices) > 1:
                model.addConstr(gp.quicksum(v[i] for i in indices) <= 1,
                                name=f"tote_unique_{uid}")

    def _add_capacity_constraints(
        self,
        model: "gp.Model",
        x: dict,
        feasible: list[FeasibleTriple],
        carried_src: np.ndarray,
        carried_dst: np.ndarray,
        carried_block: np.ndarray,
        capacities_src: np.ndarray,
        capacities_dst: np.ndarray,
        capacities_block: np.ndarray,
        tote_to_src_idx: dict[int, int],
        line_to_dst_idx: dict[int, int],
        tote_to_block_indices: dict[int, list[int]],
        ablation_flags: dict,
    ) -> None:
        import gurobipy as gp

        drop_blk = ablation_flags.get("disable_block_capacity", False)
        drop_dst = ablation_flags.get("disable_dst_capacity", False)
        drop_src = ablation_flags.get("disable_src_capacity", False)

        # Group constraint LHS by (interface_idx, slot)
        src_terms: dict[tuple[int, int], list] = {}
        dst_terms: dict[tuple[int, int], list] = {}
        blk_terms: dict[tuple[int, int], list] = {}

        for k, ft in enumerate(feasible):
            uid = int(ft.job.tote_id)
            lid = int(ft.job.line_id)

            # Source window — eq. (pickwindow)
            if not drop_src:
                w_src = compute_pickup_window(
                    start_slot=ft.start_slot,
                    slot_size=self.slot_size,
                    travel_to_tote_seconds=ft.travel_to_tote,
                    pickup_seconds=ft.pickup_seconds,
                )
                z_src = tote_to_src_idx[uid]
                for tau in slot_indices_overlapping(w_src, self.num_slots, self.slot_size):
                    src_terms.setdefault((z_src, tau), []).append(x[k])

            # Destination window — eq. (dropwindow)
            if not drop_dst:
                w_dst = compute_drop_window(
                    start_slot=ft.start_slot,
                    slot_size=self.slot_size,
                    travel_to_tote_seconds=ft.travel_to_tote,
                    pickup_seconds=ft.pickup_seconds,
                    travel_to_line_seconds=ft.travel_to_line,
                    completion_time=ft.completion_time,
                )
                z_dst = line_to_dst_idx[lid]
                for tau in slot_indices_overlapping(w_dst, self.num_slots, self.slot_size):
                    dst_terms.setdefault((z_dst, tau), []).append(x[k])

            # Lock window — eq. (lockwindow)
            if not drop_blk:
                w_lock = compute_lock_window(
                    start_slot=ft.start_slot,
                    slot_size=self.slot_size,
                    travel_to_tote_seconds=ft.travel_to_tote,
                    lock_seconds=ft.lock_seconds,
                )
                lock_slots = slot_indices_overlapping(w_lock, self.num_slots, self.slot_size)
                for blk_idx in tote_to_block_indices.get(uid, []):
                    for tau in lock_slots:
                        blk_terms.setdefault((blk_idx, tau), []).append(x[k])

        # eq. (src-capacity)
        for (z, tau), terms in src_terms.items():
            cap = float(capacities_src[z]) - float(carried_src[z, tau])
            model.addConstr(gp.quicksum(terms) <= cap, name=f"src_{z}_{tau}")

        # eq. (dst-capacity)
        for (z, tau), terms in dst_terms.items():
            cap = float(capacities_dst[z]) - float(carried_dst[z, tau])
            model.addConstr(gp.quicksum(terms) <= cap, name=f"dst_{z}_{tau}")

        # eq. (block-capacity)
        for (b, tau), terms in blk_terms.items():
            cap = float(capacities_block[b]) - float(carried_block[b, tau])
            model.addConstr(gp.quicksum(terms) <= cap, name=f"blk_{b}_{tau}")

    def _add_battery_constraint(
        self,
        model: "gp.Model",
        x: dict,
        feasible: list[FeasibleTriple],
        battery_remaining: dict[int, float],
    ) -> None:
        import gurobipy as gp
        by_robot: dict[int, list[tuple[int, float]]] = {}
        for k, ft in enumerate(feasible):
            by_robot.setdefault(ft.robot_id, []).append((k, ft.energy))
        for rid, terms in by_robot.items():
            avail = float(battery_remaining.get(rid, 0.0))
            model.addConstr(
                gp.quicksum(e * x[k] for k, e in terms) <= avail,
                name=f"battery_{rid}",
            )

    def _apply_warm_start(
        self, x: dict, feasible: list[FeasibleTriple]
    ) -> None:
        if not self._previous_solution_cache:
            return
        for k, ft in enumerate(feasible):
            key = self._triple_key(ft)
            if key in self._previous_solution_cache:
                x[k].Start = 1.0
            else:
                x[k].Start = 0.0

    def _extract_solution(
        self,
        model: "gp.Model",
        x: dict,
        v: dict,
        feasible: list[FeasibleTriple],
        jobs: list[Job],
        epoch_time: float,
        runtime_ms: float,
    ) -> TacticalSolution:
        import gurobipy as gp

        status = self._STATUS_NAMES.get(model.Status, f"STATUS_{model.Status}")
        if model.SolCount == 0:
            # No feasible solution found within the time limit
            return TacticalSolution(
                commitments=[],
                served_jobs=[],
                unserved_jobs=list(jobs),
                objective=float("inf"),
                runtime_ms=runtime_ms,
                mip_gap=float("inf"),
                status=status,
                diagnostics={"sol_count": 0},
            )

        commitments: list[Commitment] = []
        served_keys: set = set()
        for k, ft in enumerate(feasible):
            if x[k].X > 0.5:
                commitments.append(Commitment(
                    robot_id=ft.robot_id,
                    job=ft.job,
                    start_slot=ft.start_slot,
                    epoch_time=epoch_time,
                    slot_size=self.slot_size,
                ))
                served_keys.add(ft.job.key())

        served_jobs = [j for j in jobs if j.key() in served_keys]
        unserved_jobs = [j for j in jobs if j.key() not in served_keys]

        try:
            mip_gap = model.MIPGap
        except (AttributeError, gp.GurobiError):
            mip_gap = 0.0

        return TacticalSolution(
            commitments=commitments,
            served_jobs=served_jobs,
            unserved_jobs=unserved_jobs,
            objective=float(model.ObjVal),
            runtime_ms=runtime_ms,
            mip_gap=float(mip_gap),
            status=status,
            diagnostics={
                "num_vars": int(model.NumVars),
                "num_constrs": int(model.NumConstrs),
                "num_feasible_triples": len(feasible),
                "num_jobs": len(jobs),
                "num_commitments": len(commitments),
            },
        )

    # ------------------------------------------------------------------
    @staticmethod
    def _triple_key(ft: FeasibleTriple) -> tuple:
        return (
            ft.robot_id,
            ft.job.line_id,
            ft.job.tote_id,
            ft.job.mode.value,
            ft.start_slot,
        )
