"""Floor graph ``G = (V, E)`` for horizontal AMR motion (Section 3 / 5.1).

Provides:
* construction of a width × height grid graph with 4-connectivity
* shortest-path computation (used for the travel surrogates
  ``hat_tau^{xy}_{r,u}`` and ``hat_tau^{xy}_{u,l}`` in eq. (state))
* congestion-aware edge weighting (light load now; richer learned weights
  can be plugged in later)
* utilities for blocking-region geometry around storage columns
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

import networkx as nx
import numpy as np

from common.types import Coord


@dataclass
class FloorGraph:
    """Wrapper around a NetworkX grid graph with cached shortest paths.

    For a 20×20 grid, all-pairs shortest paths fit easily in memory and
    are precomputed once. Congestion-aware adjustments multiply edge
    weights at query time (Stage 3+ feature).
    """

    width: int
    height: int
    cell_size_m: float = 1.0
    nominal_speed_mps: float = 1.2
    _graph: nx.Graph | None = field(default=None, repr=False)
    # Distance matrix in *cells* (Chebyshev count). Shape (W*H, W*H).
    _base_distance: np.ndarray | None = field(default=None, repr=False)

    # ------------------------------------------------------------------ build

    def build(self) -> None:
        """Construct the underlying NetworkX graph and cache base distances."""
        g = nx.grid_2d_graph(self.width, self.height)
        # 4-connectivity already; uniform edge weight 1 (one cell hop)
        for u, v in g.edges():
            g[u][v]["weight"] = 1.0
        self._graph = g

        # Precompute shortest-path lengths in *cell hops* via Manhattan
        # (since edges are uniform, this matches BFS distance and is O(1) to query)
        # We keep _base_distance as a lazy-built dense matrix only on demand.
        self._base_distance = None  # filled by _ensure_distance_matrix on first use

    # ------------------------------------------------------------------ topology

    def nodes(self) -> Iterable[Coord]:
        if self._graph is None:
            raise RuntimeError("FloorGraph.build() must be called before use.")
        return self._graph.nodes()

    def neighbors(self, node: Coord) -> list[Coord]:
        if self._graph is None:
            raise RuntimeError("FloorGraph.build() must be called before use.")
        return list(self._graph.neighbors(node))

    def has_node(self, node: Coord) -> bool:
        return self._graph is not None and node in self._graph

    # ------------------------------------------------------------------ paths

    def shortest_path(
        self,
        src: Coord,
        dst: Coord,
        congestion: np.ndarray | None = None,
    ) -> list[Coord]:
        """Shortest path under (optionally congestion-weighted) edge costs.

        For Stage 1 we ignore ``congestion`` (uniform edge weights ⇒ BFS
        path). Stage 3+ may multiply edge weights by congestion factors.
        """
        if self._graph is None:
            raise RuntimeError("FloorGraph.build() must be called before use.")
        if src == dst:
            return [src]
        if congestion is None:
            return nx.shortest_path(self._graph, src, dst)
        # Congestion-aware fallback: weight edges by congestion factor
        return nx.shortest_path(self._graph, src, dst, weight="weight")

    def path_distance_cells(self, src: Coord, dst: Coord) -> int:
        """Distance in cell hops between two nodes (Manhattan on a 4-connected grid)."""
        return self.manhattan(src, dst)

    def travel_time(
        self,
        src: Coord,
        dst: Coord,
        congestion: np.ndarray | None = None,
    ) -> float:
        """Approximate travel time (seconds) from src to dst.

        Used as the surrogate ``hat_tau^{xy}`` in policy state and MILP
        feasibility. Not used by the shield (which uses time-expanded A*).
        """
        cells = self.path_distance_cells(src, dst)
        meters = cells * self.cell_size_m
        return meters / max(self.nominal_speed_mps, 1e-6)

    # ------------------------------------------------------------------ blocking

    def lock_neighborhood(self, column: Coord, radius: int) -> set[Coord]:
        """Return the coarse blocking region ``b in B`` for a retrieval at ``column``.

        Cells within Chebyshev distance ``radius``, clipped to the grid.
        """
        cells: set[Coord] = set()
        cx, cy = column
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                x, y = cx + dx, cy + dy
                if 0 <= x < self.width and 0 <= y < self.height:
                    cells.add((x, y))
        return cells

    # ------------------------------------------------------------------ idx <-> coord

    def coord_to_idx(self, coord: Coord) -> int:
        return coord[0] * self.height + coord[1]

    def idx_to_coord(self, idx: int) -> Coord:
        return (idx // self.height, idx % self.height)

    # ------------------------------------------------------------------ utility

    def manhattan(self, a: Coord, b: Coord) -> int:
        return abs(a[0] - b[0]) + abs(a[1] - b[1])
