"""Eligible robot set ``R_n`` construction.

Implements the formal definition from Section 3 (Robot Eligibility):

::

    R_n = { r in R | tau_free_r <= kappa_n + H,
                     b^r_n >= b_min_r + underline{e},
                     chi^r_n not shield-locked }

This is an *availability + battery + shield-lock* pre-filter. The exact
mission-specific battery check is then re-applied at the F_n level
(eq. feasible-set, Condition 5) and again as a global linear constraint
in the MILP (eq. battery).
"""

from __future__ import annotations

from typing import Sequence

from common.state import SystemState

from .robot import RobotState


def build_eligible_set(
    robots: Sequence[RobotState],
    state: SystemState,
    horizon_seconds: float,
    battery_pre_filter_floor: float,
    battery_min: float,
) -> list[int]:
    """Return the list of robot ids that satisfy all three eligibility conditions.

    Parameters
    ----------
    robots
        All AMRs in the fleet.
    state
        Current system state (provides ``epoch_time``).
    horizon_seconds
        Tactical horizon ``H``; a robot is eligible only if it can be
        dispatched before ``kappa_n + H``.
    battery_pre_filter_floor
        Prescribed additional energy reserve for candidate eligibility
        (``\\underline{e}`` in the manuscript).
    battery_min
        Minimum admissible residual energy ``b_min_r``.

    Notes
    -----
    This reserve is not a universal lower bound on feasible mission energy.
    It conservatively restricts eligibility — see the
    "layered energy feasibility" discussion in Section 4.4.
    """
    deadline = state.epoch_time + horizon_seconds
    eligible: list[int] = []
    for r in robots:
        # Condition 1: availability within the tactical horizon
        if r.tau_free > deadline:
            continue
        # Condition 2: battery pre-filter
        if r.battery < battery_min + battery_pre_filter_floor:
            continue
        # Condition 3: not under a shield reservation
        if r.shield_locked:
            continue
        eligible.append(r.rid)
    return eligible
