"""Storage columns and tote accessibility logic (Section 3.2).

Implements:
* ``StorageColumn`` — vertical stack of totes at a grid cell
* ``StorageSystem`` — collection of all columns + accessibility queries
* ``compute_access_class`` — produces ``a_{u,n} in {0, 1, 2}`` for each tote
  (eq. mode-set, three-way distinction in the manuscript)

The excavation feasibility check uses the coarse abstraction described in
Section 5.1: a buried tote is excavation-feasible iff a sufficient number
of admissible neighboring cells are available for temporary placement
(``support_threshold`` in the config).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from common.enums import AccessClass
from common.types import Cell, Coord, Tote


@dataclass
class StorageColumn:
    """A vertical stack at one grid cell.

    Convention: ``stack[0]`` is the *top* tote. Direct retrieval returns
    ``stack[0]``; excavation may serve any ``stack[k]`` for ``k > 0``.
    """

    cell: Cell
    capacity: int
    stack: list[int] = field(default_factory=list)   # tote uids, top-first

    def is_empty(self) -> bool:
        return len(self.stack) == 0

    def is_full(self) -> bool:
        return len(self.stack) >= self.capacity

    def slack(self) -> int:
        """How many more totes this column can hold."""
        return self.capacity - len(self.stack)

    def top(self) -> int | None:
        return self.stack[0] if self.stack else None

    def depth_of(self, tote_uid: int) -> int | None:
        """Return depth (0 = top) of a tote, or None if not in this column."""
        try:
            return self.stack.index(tote_uid)
        except ValueError:
            return None

    def remove(self, tote_uid: int) -> None:
        """Remove a specific tote (used when a retrieval completes)."""
        self.stack.remove(tote_uid)

    def push(self, tote_uid: int) -> None:
        """Push a tote onto the top (used for replenishment / re-stack)."""
        if self.is_full():
            raise RuntimeError(f"Column {self.cell} is full; cannot push tote {tote_uid}.")
        self.stack.insert(0, tote_uid)


class StorageSystem:
    """Collection of all storage columns plus accessibility computations."""

    # 4-connected neighbor offsets used for support
    _NEIGHBOR_OFFSETS = ((1, 0), (-1, 0), (0, 1), (0, -1))

    def __init__(
        self,
        columns: dict[Cell, StorageColumn],
        max_stack_depth: int,
        support_threshold: int,
    ):
        self.columns: dict[Cell, StorageColumn] = columns
        self.max_stack_depth = max_stack_depth
        self.support_threshold = support_threshold

        # Reverse index: tote uid -> Cell (current column).
        # Maintained by register_totes / execute_retrieval / execute_drop.
        self._tote_column: dict[int, Cell] = {}

        # Static metadata: tote uid -> SKU. Set by register_totes.
        self._tote_sku: dict[int, int] = {}

    # ------------------------------------------------------------------ Tote registry

    def register_totes(self, totes: Iterable[Tote]) -> None:
        """Place each tote in its declared column / depth.

        Within each column, totes are arranged so that the smallest declared
        depth is at index 0 (the top). If two totes share a column, their
        ``depth`` attributes simply provide the desired stacking order.
        """
        # Group by column then sort by declared depth (ascending = top first).
        by_column: dict[Cell, list[Tote]] = {}
        for t in totes:
            self._tote_sku[t.uid] = t.sku
            by_column.setdefault(t.column, []).append(t)

        for cell, ts in by_column.items():
            if cell not in self.columns:
                raise KeyError(f"Tote registered in unknown column {cell}.")
            ts.sort(key=lambda x: x.depth)
            col = self.columns[cell]
            col.stack = [t.uid for t in ts]
            for t in ts:
                self._tote_column[t.uid] = cell

    def find_tote_column(self, tote_uid: int) -> Cell | None:
        return self._tote_column.get(tote_uid)

    def stack_depth(self, tote_uid: int) -> int:
        """``d_{u,n}`` — current depth of tote (0 = top)."""
        cell = self._tote_column.get(tote_uid)
        if cell is None:
            raise KeyError(f"Tote {tote_uid} not in storage.")
        col = self.columns[cell]
        d = col.depth_of(tote_uid)
        if d is None:
            raise KeyError(f"Tote {tote_uid} not in expected column {cell}.")
        return d

    def sku_of(self, tote_uid: int) -> int:
        return self._tote_sku[tote_uid]

    def all_tote_ids(self) -> list[int]:
        return list(self._tote_column.keys())

    # ------------------------------------------------------------------ Accessibility

    def neighbor_support_count(self, cell: Cell, locked_cells: set[Coord]) -> int:
        """Number of admissible neighboring cells for excavation buffering.

        ``phi_{u,n}`` in the manuscript. A neighbor is admissible if its
        column has spare capacity AND it is not currently locked by an
        in-progress retrieval.
        """
        cx, cy = cell
        count = 0
        for dx, dy in self._NEIGHBOR_OFFSETS:
            ncell = (cx + dx, cy + dy)
            if ncell in locked_cells:
                continue
            col = self.columns.get(ncell)
            if col is None:
                continue
            if col.slack() > 0:
                count += 1
        return count

    def compute_access_class(self, tote_uid: int, locked_cells: set[Coord]) -> AccessClass:
        """Compute ``a_{u,n}`` for one tote (eq. mode-set).

        * depth=0, cell not locked -> DIRECT
        * depth>=1, cell not locked, support>=threshold -> EXCAVATION
        * otherwise -> INFEASIBLE
        """
        cell = self._tote_column.get(tote_uid)
        if cell is None:
            return AccessClass.INFEASIBLE
        if cell in locked_cells:
            return AccessClass.INFEASIBLE
        col = self.columns[cell]
        d = col.depth_of(tote_uid)
        if d is None:
            return AccessClass.INFEASIBLE
        if d == 0:
            return AccessClass.DIRECT
        # Buried: needs excavation support
        support = self.neighbor_support_count(cell, locked_cells)
        if support >= self.support_threshold:
            return AccessClass.EXCAVATION
        return AccessClass.INFEASIBLE

    def compute_access_map(self, locked_cells: set[Coord]) -> dict[int, AccessClass]:
        """Bulk version: produce the ``AccessibilityMap`` for the whole system."""
        return {
            uid: self.compute_access_class(uid, locked_cells)
            for uid in self._tote_column
        }

    def support_value(self, tote_uid: int, locked_cells: set[Coord]) -> int:
        """Return ``phi_{u,n}`` for the column containing tote ``uid``."""
        cell = self._tote_column.get(tote_uid)
        if cell is None:
            return 0
        return self.neighbor_support_count(cell, locked_cells)

    # ------------------------------------------------------------------ Mutations

    def execute_retrieval(self, tote_uid: int) -> None:
        """Remove a tote from its column when retrieval completes."""
        cell = self._tote_column.pop(tote_uid, None)
        if cell is None:
            return
        col = self.columns[cell]
        if tote_uid in col.stack:
            col.remove(tote_uid)

    def execute_drop(self, tote_uid: int, target_column: Cell, sku: int) -> None:
        """Push a tote onto a column (used by external resupply)."""
        col = self.columns.get(target_column)
        if col is None:
            raise KeyError(f"Unknown target column {target_column}.")
        col.push(tote_uid)
        self._tote_column[tote_uid] = target_column
        self._tote_sku[tote_uid] = sku

    # ------------------------------------------------------------------ Diagnostics

    def total_tote_count(self) -> int:
        return len(self._tote_column)

    def totes_by_sku(self) -> dict[int, list[int]]:
        out: dict[int, list[int]] = {}
        for uid, sku in self._tote_sku.items():
            out.setdefault(sku, []).append(uid)
        return out
