"""Schedule runtime: exact execution of admitted discrete mission schedules.

Inactive robots are held outside the shared travel graph at their current access
coordinate. A robot enters that graph only at its reserved start step and leaves
it at delivery completion. This mission-level abstraction does not model parking
capacity or certify physical safety/liveness of a deployed fleet.
"""
from __future__ import annotations
import heapq
import math
import numpy as np
from collections import defaultdict
from common.enums import AccessClass, ServiceMode
from common.types import ReservationView
from tactical.windows import slot_indices_overlapping
from .simulator import (Simulator, EV_CONSUMPTION, EV_ARRIVE_PICKUP,
                        EV_PICKUP_DONE, EV_ARRIVE_DROP, EV_DROP_DONE)


def carried_peak_occupancy(intervals, nresources, nslots, delta, epoch_time):
    """Maximum simultaneous inherited usage in each coarse slot.

    Summing interval-overlap indicators incorrectly counts sequential service
    intervals as concurrent when both intersect one MILP slot. Existing usage
    is instead the maximum of its continuous-time occupancy on that slot.
    New commitments still use whole-slot indicators, a conservative addition.
    """
    events=defaultdict(list)
    for resource,lo,hi in intervals:
        if hi>lo:
            events[resource].extend([(lo,1),(hi,-1)])
    out=np.zeros((nresources,nslots),dtype=np.int32)
    for resource,ev in events.items():
        active=0;previous=None
        for time,change in sorted(ev):
            if previous is not None and time>previous and active:
                qlo=max(0,int(math.floor((previous-epoch_time)/delta+1e-9)))
                qhi=min(nslots,int(math.ceil((time-epoch_time)/delta-1e-9)))
                if qhi>qlo:out[resource,qlo:qhi]=np.maximum(out[resource,qlo:qhi],active)
            active+=change;previous=time
        assert active==0
    return out


class ScheduleSimulator(Simulator):
    def reset(self):
        super().reset()
        self.active_missions = {}
        self.reserved_totes = set()
        self._idle_accounted_until = {r.rid: 0.0 for r in self.robots}
        self._src_index = {cell:i for i,cell in enumerate(sorted(self.storage.columns))}
        self.energy_deferrals = 0
        self.executed_schedule_mismatches = 0
        self.missed_completion_deadlines = 0
        self.completed_schedules = 0
        self.buffer_accepted_units = 0
        self.buffer_overflow_units = 0
        self.min_battery_observed = min(r.battery for r in self.robots)
        self._running_repair_count = 0
        # Exogenous consumption is independent of inventory, restocking and fleet
        # random draws, so matched seeds mean identical consumption event streams.
        self.demand.rng = np.random.default_rng(np.random.SeedSequence([self.seed, 20260927]))
        self._eq = [event for event in self._eq if event[2] != EV_CONSUMPTION]
        heapq.heapify(self._eq)
        for lid in range(len(self.buffers)):
            self._push(self.demand.sample_next_event_time(lid,0.0),EV_CONSUMPTION,lid)

    def _handle_review(self):
        # Recharge for actual idle time, not a full review interval if a robot
        # only became idle partway through it. All mission energy is paid once
        # at admission; idle drain is excluded from this benchmark.
        rate = self.cfg.world.robots.charge_per_second_idle
        for robot in self.robots:
            if robot.current_commitment is None:
                elapsed=max(0.,self.t_now-self._idle_accounted_until[robot.rid])
                robot.battery=min(self.cfg.world.robots.battery_capacity,robot.battery+rate*elapsed)
            self._idle_accounted_until[robot.rid]=self.t_now
        self.missed_completion_deadlines += sum(m.drop_done_time < self.t_now-1e-7 for m in self.active_missions.values())
        # Prevent the base class from charging again.
        self.cfg.world.robots.charge_per_second_idle=0.
        try:
            super()._handle_review()
        finally:
            self.cfg.world.robots.charge_per_second_idle=rate

    def _build_state(self):
        state=super()._build_state()
        if not hasattr(self,'active_missions'):
            return state
        for uid in self.reserved_totes:
            if uid in state.access:
                state.access[uid]=AccessClass.INFEASIBLE
        # Slots are relative to the current decision epoch; carry all accepted
        # source/destination service intervals, including future starts.
        nsrc=len(self._src_index); nslots=int(round(self.cfg.controller.tactical_horizon_H_seconds/self.cfg.controller.slot_size_delta_seconds))
        source_intervals=[];destination_intervals=[]
        delta=self.cfg.controller.slot_size_delta_seconds
        for mission in self.active_missions.values():
            si=self._src_index[mission.path_to_pickup[-1]]
            li=mission.commitment.job.line_id
            source_intervals.append((si,mission.arrive_pickup_time,mission.pickup_done_time))
            destination_intervals.append((li,mission.arrive_drop_time,mission.drop_done_time))
        src=carried_peak_occupancy(source_intervals,nsrc,nslots,delta,self.t_now)
        dst=carried_peak_occupancy(destination_intervals,len(self.buffers),nslots,delta,self.t_now)
        block=src.copy()
        # Every physical service coordinate in this benchmark is exclusive.
        assert src.max(initial=0)<=1 and dst.max(initial=0)<=1
        state.reservations=ReservationView(src=src,dst=dst,block=block)
        self._last_decision_state=state
        return state

    def _apply_commitments_with_shield(self,commitments):
        from tactical.windows import pickup_duration,lock_duration
        st=self.cfg.world.service_times
        valid=[];columns={};picks={};locks={};metadata={};seen=set()
        for cm in commitments:
            rid=int(cm.robot_id);uid=int(cm.job.tote_id)
            if rid>=len(self.robots) or self.robots[rid].current_commitment is not None:continue
            if uid in self.reserved_totes or uid in seen:continue
            cell=self.storage.find_tote_column(uid)
            if cell is None or cell in self._locked_cells:continue
            access=self.storage.compute_access_class(uid,set(self._locked_cells))
            expected=ServiceMode.DIRECT if access==AccessClass.DIRECT else ServiceMode.EXCAVATION
            if access==AccessClass.INFEASIBLE or expected!=cm.job.mode:continue
            d=self.storage.stack_depth(uid);phi=self.storage.support_value(uid,set(self._locked_cells))
            key=(rid,int(cm.job.line_id),uid)
            columns[uid]=cell
            picks[key]=pickup_duration(d,phi,cm.job.mode,base=st.pickup_base_seconds,per_depth=st.pickup_per_depth_seconds,excavation_overhead=st.pickup_excavation_overhead,epsilon_0=st.epsilon_0)
            locks[key]=lock_duration(d,phi,cm.job.mode,per_depth=st.lock_per_depth_seconds,excavation_overhead=st.lock_excavation_overhead,epsilon_0=st.epsilon_0)
            metadata[uid]=(d,expected==ServiceMode.EXCAVATION)
            valid.append(cm);seen.add(uid)
        if not valid:return 0,0,0,0.
        out=self.shield.plan(state=self._last_decision_state,commitments=valid,
            robot_positions={r.rid:tuple(r.pos) for r in self.robots},
            line_positions={i:p for i,p in enumerate(self.line_positions)},tote_columns=columns,
            pickup_seconds_for=picks,lock_seconds_for=locks,drop_seconds=st.drop_seconds)
        accepted=0;energy_deferred=0;repairs=0
        for mission in out.accepted:
            cm=mission.commitment;rid=int(cm.robot_id);uid=int(cm.job.tote_id);robot=self.robots[rid]
            depth,excav=metadata[uid]
            energy=(self.energy_model.cost_for_distance(mission.travel_distance_m)+
                    self.energy_model.cost_for_pickup(mode_excavation=excav,depth=depth)+self.energy_model.cost_for_drop())
            # Recheck the REALIZED route, not its optimistic Manhattan surrogate.
            if robot.battery-energy < self.cfg.world.robots.battery_min-1e-10:
                self.shield.release_robot(rid);energy_deferred+=1;continue
            robot.battery-=energy;robot.cumulative_energy+=energy
            robot.cumulative_distance_m+=mission.travel_distance_m
            self.min_battery_observed=min(self.min_battery_observed,robot.battery)
            assert robot.battery>=self.cfg.world.robots.battery_min-1e-9
            robot.current_commitment=cm;robot.shield_locked=True;robot.tau_free=mission.drop_done_time
            self.active_missions[rid]=mission;self.reserved_totes.add(uid)
            payload=dict(rid=rid,commitment=cm,tote_uid=uid,cell=columns[uid],line_id=int(cm.job.line_id),depth=depth,excavation=excav)
            for t,kind in [(mission.arrive_pickup_time,EV_ARRIVE_PICKUP),(mission.pickup_done_time,EV_PICKUP_DONE),
                           (mission.arrive_drop_time,EV_ARRIVE_DROP),(mission.drop_done_time,EV_DROP_DONE)]:
                assert t>=self.t_now-1e-8
                self._push(t,kind,payload)
            accepted+=1;repairs+=int(0<mission.repair_action.value<3)
        self.energy_deferrals+=energy_deferred
        return accepted,len(out.deferred)+len(out.rejected)+energy_deferred,repairs,out.runtime_ms

    def _handle_arrive_pickup(self,payload):
        if self.shield is None:return super()._handle_arrive_pickup(payload)
        self.robots[payload['rid']].pos=payload['cell']
        assert payload['cell'] not in self._locked_cells
        self._locked_cells[payload['cell']]=payload['rid']

    def _handle_pickup_done(self,payload):
        if self.shield is None:return super()._handle_pickup_done(payload)
        robot=self.robots[payload['rid']]
        robot.pickups_completed+=1
        robot.excavations_completed+=int(payload['excavation'])
        assert self.storage.find_tote_column(payload['tote_uid']) is not None
        self.storage.execute_retrieval(payload['tote_uid'])
        assert self._locked_cells.pop(payload['cell'])==payload['rid']

    def _handle_arrive_drop(self,payload):
        if self.shield is None:return super()._handle_arrive_drop(payload)
        self.robots[payload['rid']].pos=self.line_positions[payload['line_id']]

    def _handle_drop_done(self,payload):
        if self.shield is None:return super()._handle_drop_done(payload)
        rid=payload['rid'];robot=self.robots[rid];mission=self.active_missions.pop(rid)
        if abs(mission.drop_done_time-self.t_now)>1e-7:self.executed_schedule_mismatches+=1
        assert abs(mission.drop_done_time-self.t_now)<1e-7
        robot.drops_completed+=1;buf=self.buffers[payload['line_id']]
        starved=buf.starvation_started_at is not None
        accepted=buf.deposit(self.t_now,1)
        self.buffer_accepted_units+=accepted;self.buffer_overflow_units+=1-accepted
        self._delivered_total+=1;self._delivered_on_time+=int(not starved)
        robot.current_commitment=None;robot.shield_locked=False;robot.tau_free=self.t_now
        self._idle_accounted_until[rid]=self.t_now
        self.reserved_totes.remove(payload['tote_uid'])
        self.shield.release_robot(rid)
        self.completed_schedules+=1
