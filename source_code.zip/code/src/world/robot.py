"""AMR robot state and energy model (Section 3, Section 5.1)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from common.types import Commitment, Coord, Trajectory

if TYPE_CHECKING:
    from common.config import RobotsConfig


@dataclass
class RobotState:
    """Live state of a single AMR. Mutable; updated by the simulator."""

    rid: int
    pos: Coord
    battery: float                   # b^r_n
    tau_free: float = 0.0            # earliest dispatch time within tactical horizon
    current_commitment: Commitment | None = None
    current_trajectory: Trajectory | None = None
    shield_locked: bool = False      # chi^r busy under shield reservation

    # Diagnostic counters (updated by simulator)
    cumulative_distance_m: float = 0.0
    cumulative_energy: float = 0.0
    pickups_completed: int = 0
    drops_completed: int = 0
    excavations_completed: int = 0


class EnergyModel:
    """Linear energy model: distance + service overhead.

    energy = a*meters + b*pickups + c*drops + d*idle_seconds.
    Calibrated by ``RobotsConfig`` (Section 5.1). Excavation pays a
    per-depth premium because the hoist must lift more totes.
    """

    def __init__(self, cfg: "RobotsConfig"):
        self.cfg = cfg

    def cost_for_distance(self, meters: float) -> float:
        return self.cfg.energy_per_meter * meters

    def cost_for_pickup(self, *, mode_excavation: bool, depth: int) -> float:
        """Energy cost of one pickup; excavation pays a per-depth premium.

        Direct: e = energy_per_pickup
        Excavation: e = energy_per_pickup * (1 + 0.5*max(d-1, 0))
        """
        base = self.cfg.energy_per_pickup
        if not mode_excavation:
            return base
        return base * (1.0 + 0.5 * max(depth - 1, 0))

    def cost_for_drop(self) -> float:
        return self.cfg.energy_per_drop

    def cost_for_idle(self, seconds: float) -> float:
        return self.cfg.energy_per_second_idle * seconds
