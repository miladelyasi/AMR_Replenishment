"""Discrete-event simulator for line-side replenishment (Section 5.1).

This is the central object that:

1. Builds the world: floor graph, storage, robots, buffers, demand.
2. Drives the demand process and robot service execution.
3. At each decision epoch ``kappa_n``, builds a ``SystemState``, calls
   ``controller.decide(state)``, executes the resulting commitments,
   and advances the clock to the next epoch.
4. Collects metrics aligned with Sec. 5.1 "Performance metrics".

Stage 1 simplifications
-----------------------
* No shield. Robot trajectories execute via teleport-on-arrival; we track
  cumulative travel distance but not the intermediate motion. Stages 3+
  introduce shielded execution.
* Excavation is modeled at the *coarse* level described in Sec. 5.1: the
  retrieval cell is locked for ``t^lock``; we do not simulate intermediate
  tote relocations.
* Periodic external resupply keeps storage from running dry over long
  episodes (the paper does not model storage-level replenishment).
"""

from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from common.config import Config
from common.controller import Controller, ControllerOutput
from common.enums import AccessClass, ServiceMode
from common.state import SystemState
from common.types import Commitment, ReservationView, Tote

from .buffer import DemandGenerator, LineBuffer
from .eligibility import build_eligible_set
from .grid import FloorGraph
from .robot import EnergyModel, RobotState
from .storage import StorageColumn, StorageSystem

if TYPE_CHECKING:
    pass


# ---------------------------------------------------------------------------
# Result containers
# ---------------------------------------------------------------------------

@dataclass
class EpochRecord:
    """One row of the per-epoch log."""

    epoch_index: int
    epoch_time: float
    holding_time: float
    num_candidates: int
    num_commitments: int
    num_shield_repairs: int = 0
    num_shield_rejections: int = 0
    milp_solve_ms: float = 0.0
    shield_solve_ms: float = 0.0
    reward: float = 0.0



class MechanismLogger:
    """Per-(epoch, line) telemetry writer for the cliff-mechanism diagnostic.

    Writes one JSONL row per (epoch, line) capturing: time, line_id,
    buffer_level, hat_T_so, is_critical, is_stockout, n_dispatched_this_epoch,
    n_deferred_this_epoch, n_shield_rejected_this_epoch, n_candidates.
    File is opened once and appended-to per epoch; closed at episode end.
    """
    def __init__(self, path):
        import pathlib
        self.path = pathlib.Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._f = open(self.path, 'w', buffering=1)

    def log(self, t, epoch_index, buffers, hat_T_so, n_dispatched, n_deferred, n_repaired, n_candidates):
        import json
        for lid, buf in enumerate(buffers):
            row = {
                "t": float(t),
                "epoch": int(epoch_index),
                "line_id": int(lid),
                "buffer_level": int(buf.level),
                "safety_stock": int(buf.safety_stock),
                "is_critical": bool(buf.is_critical()),
                "is_stockout": bool(buf.level <= 0),
                "hat_T_so": float(hat_T_so[lid]) if hat_T_so is not None else None,
                "n_dispatched_epoch": int(n_dispatched),
                "n_deferred_epoch": int(n_deferred),
                "n_repaired_epoch": int(n_repaired),
                "n_candidates_epoch": int(n_candidates),
            }
            self._f.write(json.dumps(row) + "\n")

    def close(self):
        try:
            self._f.close()
        except Exception:
            pass

@dataclass
class SimulatorResult:
    """Result of a single simulation episode."""

    seed: int
    controller_name: str
    horizon_seconds: float

    stockout_minutes: float = 0.0
    on_time_ratio: float = 0.0
    line_reliability: float = 0.0
    total_travel_m: float = 0.0
    total_energy: float = 0.0
    congestion_index: float = 0.0
    shield_interventions: int = 0
    rejected_commitments: int = 0
    total_milp_solve_ms: float = 0.0
    total_shield_solve_ms: float = 0.0

    epoch_records: list[EpochRecord] = field(default_factory=list)
    worst_decile_stockout_minutes: float = 0.0
    surge_summary_lag_seconds: float = 0.0

    # Per-line stockout breakdown
    per_line_stockout_seconds: dict[int, float] = field(default_factory=dict)
    delivered_total: int = 0
    delivered_on_time: int = 0


# ---------------------------------------------------------------------------
# Internal event types
# ---------------------------------------------------------------------------

EV_REVIEW = 0
EV_CONSUMPTION = 1
EV_ARRIVE_PICKUP = 2
EV_PICKUP_DONE = 3
EV_ARRIVE_DROP = 4
EV_DROP_DONE = 5
EV_RESTOCK = 6


# ---------------------------------------------------------------------------
# Simulator
# ---------------------------------------------------------------------------

class Simulator:
    """Discrete-event simulator for the line-side replenishment system."""

    def __init__(
        self,
        cfg: Config,
        controller: Controller,
        shield=None,                    # optional in Stage 1
        seed: int = 0,
        allow_early_epochs: bool = False,
    ):
        self.cfg = cfg
        self.controller = controller
        self.shield = shield
        self.seed = seed
        self.allow_early_epochs = allow_early_epochs

        self.rng = np.random.default_rng(seed)

        # Sub-systems (constructed in ``reset``)
        self.grid: FloorGraph | None = None
        self.storage: StorageSystem | None = None
        self.robots: list[RobotState] = []
        self.buffers: list[LineBuffer] = []
        self.demand: DemandGenerator | None = None
        self.energy_model: EnergyModel | None = None

        # Static layout
        self.line_positions: list[tuple[int, int]] = []   # one (x, y) per line
        self.line_skus: list[int] = []                    # SKU consumed by each line

        # Locked cells (active retrieval footprints) — Stage 1: cell-level only
        self._locked_cells: dict[tuple[int, int], int] = {}   # cell -> rid holding lock

        # Running clocks
        self.t_now: float = 0.0
        self.epoch_index: int = 0

        # Event queue: (time, seq, kind, payload)
        self._eq: list[tuple[float, int, int, object]] = []
        self._seq: int = 0

        # Tote uid generator (for restocking)
        self._next_tote_uid: int = 0

        # Cumulative metrics
        self._epoch_records: list[EpochRecord] = []
        self._delivered_total = 0
        self._delivered_on_time = 0
        self._cumulative_deferred = 0
        self._mech_logger = None  # set externally before run()
        self._cumulative_shield_ms = 0.0
        # Reward snapshot taken at the start of each epoch
        self._reward_snapshot_stockout = 0.0
        self._reward_snapshot_travel = 0.0
        self._reward_snapshot_energy = 0.0
        self._reward_snapshot_delivered_on_time = 0
        self._reward_snapshot_repairs = 0
        self._reward_snapshot_rejects = 0

    # ------------------------------------------------------------------ helpers

    def _push(self, t: float, kind: int, payload: object) -> None:
        heapq.heappush(self._eq, (t, self._seq, kind, payload))
        self._seq += 1

    def _new_tote_uid(self) -> int:
        uid = self._next_tote_uid
        self._next_tote_uid += 1
        return uid

    # ------------------------------------------------------------------ reset

    def reset(self) -> None:
        """Construct/reinitialize all subsystems for a fresh episode."""
        wcfg = self.cfg.world

        # ---- floor graph
        self.grid = FloorGraph(
            width=wcfg.grid.width,
            height=wcfg.grid.height,
            cell_size_m=wcfg.grid.cell_size_m,
            nominal_speed_mps=wcfg.robots.nominal_speed_mps,
        )
        self.grid.build()

        # ---- storage layout
        # Lines occupy x=0 column; storage occupies x>=1.
        num_lines = wcfg.num_lines
        line_y = np.linspace(0, wcfg.grid.height - 1, num_lines).astype(int)
        self.line_positions = [(0, int(y)) for y in line_y]
        # Each line consumes its own SKU; SKUs are 0..num_lines-1
        self.line_skus = list(range(num_lines))

        columns: dict[tuple[int, int], StorageColumn] = {}
        for x in range(1, wcfg.grid.width):
            for y in range(wcfg.grid.height):
                columns[(x, y)] = StorageColumn(
                    cell=(x, y),
                    capacity=wcfg.storage.max_stack_depth,
                )
        self.storage = StorageSystem(
            columns=columns,
            max_stack_depth=wcfg.storage.max_stack_depth,
            support_threshold=wcfg.storage.support_threshold,
        )

        # ---- initial inventory: ~80% fill, balanced across SKUs
        slot_list = [(c, d) for c in columns for d in range(wcfg.storage.max_stack_depth)]
        # Sort by depth ascending so depth-0 slots get filled first per column
        # (the StorageSystem.register_totes will re-order anyway, but this is cleaner).
        slot_list.sort(key=lambda s: s[1])
        self.rng.shuffle(slot_list)

        target_fill = int(0.8 * len(slot_list))
        initial_totes: list[Tote] = []
        for i in range(target_fill):
            cell, depth = slot_list[i]
            sku = i % num_lines
            uid = self._new_tote_uid()
            initial_totes.append(Tote(uid=uid, sku=sku, column=cell, depth=depth))
        self.storage.register_totes(initial_totes)

        # ---- robots (random initial positions in storage area)
        self.robots = []
        for r in range(wcfg.robots.fleet_size):
            x = int(self.rng.integers(1, wcfg.grid.width))
            y = int(self.rng.integers(0, wcfg.grid.height))
            self.robots.append(RobotState(
                rid=r,
                pos=(x, y),
                battery=wcfg.robots.battery_capacity,
            ))

        # ---- buffers
        self.buffers = []
        for lid in range(num_lines):
            self.buffers.append(LineBuffer(
                lid=lid,
                capacity=wcfg.buffers.capacity,
                safety_stock=wcfg.buffers.safety_stock,
                level=wcfg.buffers.initial_level,
                hat_lambda=self.cfg.demand.baseline_rate,
                filter_alpha=self.cfg.demand.filter_alpha,
            ))

        # ---- demand process
        line_ids = np.arange(num_lines)
        self.demand = DemandGenerator(
            line_ids=line_ids,
            baseline_rate=self.cfg.demand.baseline_rate,
            surge_multiplier=self.cfg.demand.surge_multiplier,
            surge_duration=self.cfg.demand.surge_duration_seconds,
            surge_start_window=self.cfg.demand.surge_start_window,
            surge_lines_fraction=self.cfg.demand.surge_lines_fraction,
            rng=self.rng,
        )
        self.demand.schedule_surge()

        # ---- energy model
        self.energy_model = EnergyModel(wcfg.robots)

        # ---- clocks + event queue
        self.t_now = 0.0
        self.epoch_index = 0
        self._eq = []
        self._seq = 0
        self._epoch_records = []
        self._repairs_so_far = 0
        self._delivered_total = 0
        self._delivered_on_time = 0
        self.controller.reset()

        # Schedule first review at t=0
        self._push(0.0, EV_REVIEW, None)
        # Schedule first consumption per line
        for lid in range(num_lines):
            t_next = self.demand.sample_next_event_time(lid, 0.0)
            self._push(t_next, EV_CONSUMPTION, lid)

        # Schedule periodic restocking (so storage doesn't run dry over 8 hours)
        # Average consumption: lambda * num_lines totes/sec.
        # We resupply once per minute, refilling enough to match average consumption.
        self._restock_interval = 60.0
        self._push(self._restock_interval, EV_RESTOCK, None)

    # ------------------------------------------------------------------ run

    def run(self) -> SimulatorResult:
        """Run a full episode and return aggregated metrics."""
        if self.grid is None:
            self.reset()

        T_horizon = self.cfg.experiment.episode_horizon_seconds

        while self._eq and self._eq[0][0] <= T_horizon:
            t, _, kind, payload = heapq.heappop(self._eq)
            self.t_now = t

            if kind == EV_REVIEW:
                self._handle_review()
            elif kind == EV_CONSUMPTION:
                self._handle_consumption(payload)
            elif kind == EV_ARRIVE_PICKUP:
                self._handle_arrive_pickup(payload)
            elif kind == EV_PICKUP_DONE:
                self._handle_pickup_done(payload)
            elif kind == EV_ARRIVE_DROP:
                self._handle_arrive_drop(payload)
            elif kind == EV_DROP_DONE:
                self._handle_drop_done(payload)
            elif kind == EV_RESTOCK:
                self._handle_restock()
            else:
                raise RuntimeError(f"Unknown event kind {kind}")

        # Close any open starvation intervals at horizon
        self.t_now = T_horizon
        for buf in self.buffers:
            buf.close_starvation_at_horizon(T_horizon)

        return self._build_result()

    # ------------------------------------------------------------------ event handlers

    def _handle_review(self) -> None:
        """Build state, query the controller, dispatch new commitments."""
        K = self.cfg.controller.review_period_K_seconds
        prev_t = max(0.0, self.t_now - K)
        holding_time = self.t_now - prev_t if self.epoch_index > 0 else K

        # Apply passive idle recharge to all currently-idle robots.
        # Robots that are mid-mission don't recharge.
        charge_rate = self.cfg.world.robots.charge_per_second_idle
        if charge_rate > 0.0 and holding_time > 0.0:
            cap = self.cfg.world.robots.battery_capacity
            for r in self.robots:
                if r.current_commitment is None and r.battery < cap:
                    r.battery = min(cap, r.battery + charge_rate * holding_time)

        state = self._build_state()
        decision: ControllerOutput = self.controller.decide(state)

        # Dispatch through the shield if one is provided; otherwise fall back to
        # the Stage-1 teleport-on-arrival path.
        if self.shield is not None:
            n_dispatched, n_deferred, n_repaired, shield_ms = self._apply_commitments_with_shield(
                decision.commitments
            )
            self._cumulative_deferred += n_deferred
            self._cumulative_shield_ms += shield_ms
        else:
            n_dispatched = self._apply_commitments_no_shield(decision.commitments)
            n_deferred = 0
            n_repaired = 0
            shield_ms = 0.0

        n_candidates = decision.diagnostics.get("num_candidates", 0)
        # ---- Reward over the previous holding interval (eq. reward) ---------
        # We use deltas in cumulative metrics. Note: the stockout delta
        # captures TIME-INTEGRATED stockout exposure that occurred during
        # the just-ended interval, since starvation_total_seconds is updated
        # incrementally as deposits close starvation windows (and the
        # close_starvation_at_horizon accounts for the final interval).
        rw = self.cfg.reward
        cur_stockout = sum(buf.starvation_total_seconds for buf in self.buffers)
        cur_travel = sum(r.cumulative_distance_m for r in self.robots)
        cur_energy = sum(r.cumulative_energy for r in self.robots)
        cur_repairs = getattr(self, "_repairs_so_far", 0)
        cur_rejects = self._cumulative_deferred
        cur_on_time = self._delivered_on_time

        d_stockout = cur_stockout - self._reward_snapshot_stockout
        d_travel = cur_travel - self._reward_snapshot_travel
        d_energy = cur_energy - self._reward_snapshot_energy
        d_repairs = cur_repairs - self._reward_snapshot_repairs
        d_rejects = cur_rejects - self._reward_snapshot_rejects
        d_on_time = cur_on_time - self._reward_snapshot_delivered_on_time

        reward = (
            -rw.alpha * d_stockout
            -rw.beta * d_travel
            -rw.nu * d_energy
            -rw.omega * d_repairs
            -rw.omega_rej * d_rejects
            +rw.delta_ot * d_on_time
        )

        self._reward_snapshot_stockout = cur_stockout
        self._reward_snapshot_travel = cur_travel
        self._reward_snapshot_energy = cur_energy
        self._reward_snapshot_repairs = cur_repairs
        self._reward_snapshot_rejects = cur_rejects
        self._reward_snapshot_delivered_on_time = cur_on_time

        rec = EpochRecord(
            epoch_index=self.epoch_index,
            epoch_time=self.t_now,
            holding_time=holding_time,
            num_candidates=int(n_candidates),
            num_commitments=n_dispatched,
            num_shield_repairs=n_repaired,
            num_shield_rejections=n_deferred,
            shield_solve_ms=shield_ms,
            milp_solve_ms=float(decision.diagnostics.get("milp_solve_ms", 0.0)),
            reward=float(reward),
        )
        self._epoch_records.append(rec)
        self._repairs_so_far = cur_repairs + n_repaired
        if self._mech_logger is not None:
            # hat_T_so was already computed inside _build_state; recompute lightly here
            kappa = self.cfg.demand.conservative_inflation
            eps0 = self.cfg.world.service_times.epsilon_0
            hat_T_so_now = [buf.projected_time_to_stockout(kappa, eps0) for buf in self.buffers]
            self._mech_logger.log(
                t=self.t_now, epoch_index=self.epoch_index,
                buffers=self.buffers, hat_T_so=hat_T_so_now,
                n_dispatched=n_dispatched, n_deferred=n_deferred,
                n_repaired=n_repaired, n_candidates=n_candidates,
            )
        self.epoch_index += 1

        # Schedule next review (fixed-period; early epochs not used in Stage 1)
        next_review = self.t_now + K
        if next_review <= self.cfg.experiment.episode_horizon_seconds:
            self._push(next_review, EV_REVIEW, None)

    def _handle_consumption(self, line_id: int) -> None:
        buf = self.buffers[line_id]
        # Update filter using the (assumed) current rate as instantaneous proxy.
        buf.update_filter(self.demand.instantaneous_rate(line_id, self.t_now))
        buf.consume(self.t_now)

        # Schedule next consumption for this line
        t_next = self.demand.sample_next_event_time(line_id, self.t_now)
        if t_next <= self.cfg.experiment.episode_horizon_seconds:
            self._push(t_next, EV_CONSUMPTION, line_id)

    def _handle_arrive_pickup(self, payload: dict) -> None:
        """Robot arrives at the source column — start the pickup phase."""
        rid = payload["rid"]
        commitment: Commitment = payload["commitment"]
        cell = payload["cell"]
        mode_excav = payload["excavation"]
        depth = payload["depth"]
        pickup_seconds = payload["pickup_seconds"]
        lock_seconds = payload["lock_seconds"]

        robot = self.robots[rid]
        robot.pos = cell

        # Lock the column for the lock-window duration
        self._locked_cells[cell] = rid
        # Pickup completion event
        t_pickup_done = self.t_now + pickup_seconds
        self._push(t_pickup_done, EV_PICKUP_DONE, {
            "rid": rid,
            "commitment": commitment,
            "cell": cell,
            "tote_uid": payload["tote_uid"],
            "excavation": mode_excav,
            "depth": depth,
            "lock_seconds": lock_seconds,
            "lock_started_at": self.t_now,
            "drop_seconds": payload["drop_seconds"],
        })

    def _handle_pickup_done(self, payload: dict) -> None:
        """Pickup phase complete — remove tote from storage, start travel-to-drop."""
        rid = payload["rid"]
        commitment: Commitment = payload["commitment"]
        cell = payload["cell"]
        tote_uid = payload["tote_uid"]
        depth = payload["depth"]
        excav = payload["excavation"]

        robot = self.robots[rid]

        # Pay pickup energy
        e_pick = self.energy_model.cost_for_pickup(mode_excavation=excav, depth=depth)
        robot.battery -= e_pick
        robot.cumulative_energy += e_pick
        robot.pickups_completed += 1
        if excav:
            robot.excavations_completed += 1

        # Tote leaves storage
        self.storage.execute_retrieval(tote_uid)

        # Release the lock if the lock-window has expired; otherwise keep it locked
        # until the lock-window ends (we model lock_window >= pickup_window).
        lock_started = payload["lock_started_at"]
        lock_seconds = payload["lock_seconds"]
        lock_release_t = lock_started + lock_seconds
        if lock_release_t <= self.t_now:
            self._locked_cells.pop(cell, None)
        else:
            # Schedule a lock-release through a "drop" event side-effect.
            # We use a self-event by reusing the existing event queue with
            # a small payload; for simplicity we just leave it locked and
            # release when the robot returns or at horizon. For now,
            # release at lock_release_t via a synthetic ARRIVE_DROP-tail
            # cleanup hook: easier to just release immediately here, since
            # excavation lock_seconds <= pickup_seconds in our parameterization.
            self._locked_cells.pop(cell, None)

        # Schedule travel to the destination line
        line_id = commitment.job.line_id
        line_pos = self.line_positions[line_id]
        travel_cells = self.grid.path_distance_cells(cell, line_pos)
        travel_meters = travel_cells * self.grid.cell_size_m
        travel_seconds = travel_meters / max(self.grid.nominal_speed_mps, 1e-6)
        e_travel = self.energy_model.cost_for_distance(travel_meters)
        robot.battery -= e_travel
        robot.cumulative_energy += e_travel
        robot.cumulative_distance_m += travel_meters

        t_arrive_drop = self.t_now + travel_seconds
        self._push(t_arrive_drop, EV_ARRIVE_DROP, {
            "rid": rid,
            "commitment": commitment,
            "tote_uid": tote_uid,
            "line_id": line_id,
            "drop_seconds": payload["drop_seconds"],
        })

    def _handle_arrive_drop(self, payload: dict) -> None:
        """Robot arrives at the destination line — start the drop phase."""
        rid = payload["rid"]
        line_id = payload["line_id"]
        drop_seconds = payload["drop_seconds"]
        robot = self.robots[rid]
        robot.pos = self.line_positions[line_id]

        t_done = self.t_now + drop_seconds
        self._push(t_done, EV_DROP_DONE, {
            "rid": rid,
            "commitment": payload["commitment"],
            "tote_uid": payload["tote_uid"],
            "line_id": line_id,
        })

    def _handle_drop_done(self, payload: dict) -> None:
        """Drop complete — deposit tote into line buffer, free the robot."""
        rid = payload["rid"]
        line_id = payload["line_id"]
        commitment: Commitment = payload["commitment"]
        robot = self.robots[rid]

        # Pay drop energy
        e_drop = self.energy_model.cost_for_drop()
        robot.battery -= e_drop
        robot.cumulative_energy += e_drop
        robot.drops_completed += 1

        # Deliver to buffer
        buf = self.buffers[line_id]
        was_critical = buf.is_critical()
        was_starved = buf.starvation_started_at is not None
        buf.deposit(self.t_now, n_units=1)

        # On-time tracking: a delivery is "on time" if the line wasn't already
        # in a starvation interval at the time of arrival.
        self._delivered_total += 1
        if not was_starved:
            self._delivered_on_time += 1

        # Robot is now free
        robot.current_commitment = None
        robot.tau_free = self.t_now
        robot.shield_locked = False

        # Release the robot's reservations from the shield's table so its slots
        # become available for future planning.
        if self.shield is not None:
            self.shield.release_robot(rid)

    def _handle_restock(self) -> None:
        """Periodic external resupply.

        Adds totes to fill some empty slots, keeping average inventory
        roughly stable over the episode. Distribution is balanced across
        SKUs proportional to consumption.
        """
        n_lines = len(self.buffers)
        avg_rate_per_line = self.cfg.demand.baseline_rate
        # Expected consumption over one restock interval
        expected_consumed = avg_rate_per_line * self._restock_interval * n_lines
        # Add ~1.0x of expected consumption back as totes
        n_to_add = int(round(expected_consumed))

        empty_slots: list[tuple[int, int]] = [
            cell for cell, col in self.storage.columns.items()
            if col.slack() > 0 and cell not in self._locked_cells
        ]
        if not empty_slots or n_to_add <= 0:
            self._reschedule_restock()
            return

        for _ in range(n_to_add):
            if not empty_slots:
                break
            idx = int(self.rng.integers(0, len(empty_slots)))
            cell = empty_slots[idx]
            sku = int(self.rng.integers(0, n_lines))
            uid = self._new_tote_uid()
            self.storage.execute_drop(uid, cell, sku)
            # If now full, drop it from candidate slots
            if self.storage.columns[cell].slack() == 0:
                empty_slots.pop(idx)

        self._reschedule_restock()

    def _reschedule_restock(self) -> None:
        next_t = self.t_now + self._restock_interval
        if next_t <= self.cfg.experiment.episode_horizon_seconds:
            self._push(next_t, EV_RESTOCK, None)

    # ------------------------------------------------------------------ commit dispatch

    def _apply_commitments_no_shield(self, commitments: list[Commitment]) -> int:
        """Stage-1 dispatch: schedule robot events directly, no MAPF.

        Returns the number of commitments actually dispatched (some may be
        dropped if the robot is no longer eligible by the time we get here).
        """
        st_cfg = self.cfg.world.service_times
        n_dispatched = 0

        for cm in commitments:
            rid = cm.robot_id
            if rid >= len(self.robots):
                continue
            robot = self.robots[rid]
            if robot.current_commitment is not None:
                continue   # already busy

            # Battery feasibility: refuse dispatch if robot would go below floor
            # AFTER paying for the round-trip travel. This makes the simulator
            # the source of truth for battery feasibility.
            min_battery = self.cfg.world.robots.battery_min
            if robot.battery < min_battery + self.cfg.world.robots.battery_pre_filter_floor:
                continue

            tote_uid = cm.job.tote_id
            cell = self.storage.find_tote_column(tote_uid)
            if cell is None:
                continue   # tote already gone (e.g. another robot grabbed it)
            if cell in self._locked_cells:
                continue
            depth = self.storage.stack_depth(tote_uid)
            support = self.storage.support_value(tote_uid, set(self._locked_cells))
            mode_excav = (cm.job.mode == ServiceMode.EXCAVATION)
            if mode_excav and depth == 0:
                # Mode mismatch — fall back to direct
                mode_excav = False
            if (not mode_excav) and depth > 0:
                # Scheduled as direct but tote is buried; reject
                continue

            # ---- pickup duration (from windows.pickup_duration logic, inlined to avoid Stage-2 dep)
            base = st_cfg.pickup_base_seconds
            kappa_h = st_cfg.pickup_per_depth_seconds
            kappa_e = st_cfg.pickup_excavation_overhead
            eps0 = st_cfg.epsilon_0
            if mode_excav:
                pickup_seconds = base + kappa_h * depth + kappa_e * max(depth - 1, 0) / max(support, eps0)
            else:
                pickup_seconds = base + kappa_h * depth
            # ---- lock duration
            klh = st_cfg.lock_per_depth_seconds
            kle = st_cfg.lock_excavation_overhead
            if mode_excav:
                lock_seconds = klh * depth + kle * max(depth - 1, 0) / max(support, eps0)
            else:
                lock_seconds = klh * depth

            # ---- travel to pickup
            travel_cells = self.grid.path_distance_cells(robot.pos, cell)
            travel_meters = travel_cells * self.grid.cell_size_m
            travel_seconds = travel_meters / max(self.grid.nominal_speed_mps, 1e-6)
            e_travel = self.energy_model.cost_for_distance(travel_meters)
            robot.battery -= e_travel
            robot.cumulative_energy += e_travel
            robot.cumulative_distance_m += travel_meters

            # ---- start_slot: MILP may schedule a delayed start
            slot_delay = max(0.0, float(cm.start_slot) * float(cm.slot_size))

            # Mark robot as committed
            robot.current_commitment = cm
            robot.tau_free = self.t_now + slot_delay + travel_seconds + pickup_seconds + 9999.0  # filled in by drop_done

            t_arrive = self.t_now + slot_delay + travel_seconds
            self._push(t_arrive, EV_ARRIVE_PICKUP, {
                "rid": rid,
                "commitment": cm,
                "cell": cell,
                "tote_uid": tote_uid,
                "depth": depth,
                "excavation": mode_excav,
                "pickup_seconds": pickup_seconds,
                "lock_seconds": lock_seconds,
                "drop_seconds": st_cfg.drop_seconds,
            })
            n_dispatched += 1

        return n_dispatched

    # ------------------------------------------------------------------ shielded dispatch

    def _apply_commitments_with_shield(
        self, commitments: list[Commitment]
    ) -> tuple[int, int, int, float]:
        """Dispatch commitments through the prioritized shield.

        Returns ``(n_dispatched, n_deferred, n_repaired, shield_solve_ms)``.
        """
        st_cfg = self.cfg.world.service_times
        # Build inputs for shield.plan
        robot_positions = {r.rid: tuple(r.pos) for r in self.robots}
        line_positions = {l: tuple(self.line_positions[l])
                          for l in range(len(self.line_positions))}

        tote_columns: dict[int, tuple[int, int]] = {}
        pickup_seconds_for: dict[tuple, float] = {}
        lock_seconds_for: dict[tuple, float] = {}
        valid_commitments: list[Commitment] = []
        for cm in commitments:
            rid = cm.robot_id
            if rid >= len(self.robots) or self.robots[rid].current_commitment is not None:
                continue   # robot busy from prior epoch
            tote_uid = cm.job.tote_id
            cell = self.storage.find_tote_column(tote_uid)
            if cell is None or cell in self._locked_cells:
                continue
            depth = self.storage.stack_depth(tote_uid)
            support = self.storage.support_value(tote_uid, set(self._locked_cells))
            mode_excav = (cm.job.mode == ServiceMode.EXCAVATION)
            if mode_excav and depth == 0:
                mode_excav = False
            if (not mode_excav) and depth > 0:
                continue

            base = st_cfg.pickup_base_seconds
            kappa_h = st_cfg.pickup_per_depth_seconds
            kappa_e = st_cfg.pickup_excavation_overhead
            eps0 = st_cfg.epsilon_0
            if mode_excav:
                pickup_seconds = base + kappa_h * depth + kappa_e * max(depth - 1, 0) / max(support, eps0)
            else:
                pickup_seconds = base + kappa_h * depth
            klh = st_cfg.lock_per_depth_seconds
            kle = st_cfg.lock_excavation_overhead
            if mode_excav:
                lock_seconds = klh * depth + kle * max(depth - 1, 0) / max(support, eps0)
            else:
                lock_seconds = klh * depth

            ck = (cm.robot_id, cm.job.line_id, cm.job.tote_id)
            tote_columns[tote_uid] = cell
            pickup_seconds_for[ck] = pickup_seconds
            lock_seconds_for[ck] = lock_seconds
            valid_commitments.append(cm)

        if not valid_commitments:
            return 0, 0, 0, 0.0

        # Plan
        state = self._build_state()
        out = self.shield.plan(
            state=state,
            commitments=valid_commitments,
            robot_positions=robot_positions,
            line_positions=line_positions,
            tote_columns=tote_columns,
            pickup_seconds_for=pickup_seconds_for,
            lock_seconds_for=lock_seconds_for,
            drop_seconds=st_cfg.drop_seconds,
        )

        # Count repairs (shifts) for diagnostics
        n_repaired = sum(
            1 for m in out.accepted
            if m.repair_action.value > 0 and m.repair_action.value < 3
        )

        # Schedule events for accepted missions
        n_dispatched = 0
        for mission in out.accepted:
            cm = mission.commitment
            rid = cm.robot_id
            robot = self.robots[rid]
            tote_uid = cm.job.tote_id
            cell = tote_columns[tote_uid]
            depth = self.storage.stack_depth(tote_uid)
            mode_excav = (cm.job.mode == ServiceMode.EXCAVATION) and depth > 0
            ck = (cm.robot_id, cm.job.line_id, cm.job.tote_id)
            pickup_seconds = pickup_seconds_for[ck]
            lock_seconds = lock_seconds_for[ck]

            # Charge travel energy based on the SHIELD'S realized distance
            # (cells actually moved through, possibly more than Manhattan due to detours)
            e_travel = self.energy_model.cost_for_distance(mission.travel_distance_m)
            robot.battery -= e_travel
            robot.cumulative_energy += e_travel
            robot.cumulative_distance_m += mission.travel_distance_m

            # Mark robot as committed; tau_free filled in at drop_done
            robot.current_commitment = cm
            robot.shield_locked = True
            robot.tau_free = mission.drop_done_time

            # Schedule events at the SHIELD-PLANNED times (in absolute simulator time)
            # Note: shield internally uses time relative to t=0 (the table's clock origin),
            # so we add self.t_now? Actually the shield uses commitment.epoch_time as
            # the start, which IS self.t_now at the time of the call. So the times
            # produced by shield are already absolute simulator time.
            self._push(mission.arrive_pickup_time, EV_ARRIVE_PICKUP, {
                "rid": rid,
                "commitment": cm,
                "cell": cell,
                "tote_uid": tote_uid,
                "depth": depth,
                "excavation": mode_excav,
                "pickup_seconds": pickup_seconds,
                "lock_seconds": lock_seconds,
                "drop_seconds": st_cfg.drop_seconds,
            })
            n_dispatched += 1

        return n_dispatched, len(out.deferred) + len(out.rejected), n_repaired, out.runtime_ms

    # ------------------------------------------------------------------ state assembly

    def _build_state(self) -> SystemState:
        """Assemble the ``SystemState`` for the current epoch."""
        n_lines = len(self.buffers)
        n_robots = len(self.robots)

        line_ids = np.arange(n_lines)
        B = np.array([buf.level for buf in self.buffers], dtype=np.int32)
        S = np.array([buf.safety_stock for buf in self.buffers], dtype=np.int32)
        hat_lambda = np.array([buf.hat_lambda for buf in self.buffers], dtype=np.float32)
        eps0 = self.cfg.world.service_times.epsilon_0
        kappa = self.cfg.demand.conservative_inflation
        hat_T_so = np.array([
            buf.projected_time_to_stockout(kappa, eps0) for buf in self.buffers
        ], dtype=np.float32)

        robot_ids = np.arange(n_robots)
        robot_pos = np.array([r.pos for r in self.robots], dtype=np.int32)
        tau_free = np.array([r.tau_free for r in self.robots], dtype=np.float32)
        battery = np.array([r.battery for r in self.robots], dtype=np.float32)
        commitment_busy = np.array(
            [r.current_commitment is not None for r in self.robots], dtype=bool
        )
        shield_locked = np.array([r.shield_locked for r in self.robots], dtype=bool)

        # Reservations: empty in Stage 1
        H = self.cfg.controller.tactical_horizon_H_seconds
        D = self.cfg.controller.slot_size_delta_seconds
        N_slots = int(round(H / D))
        # |Z^src| = number of storage cells; |Z^dst| = number of lines; |B| = lock regions
        n_src = len(self.storage.columns)
        n_dst = n_lines
        n_blk = len(self.storage.columns)
        reservations = ReservationView(
            src=np.zeros((n_src, N_slots), dtype=np.int32),
            dst=np.zeros((n_dst, N_slots), dtype=np.int32),
            block=np.zeros((n_blk, N_slots), dtype=np.int32),
        )

        access = self.storage.compute_access_map(set(self._locked_cells))

        # Stack depth and support phi for each tote (lazy: only fill what's mapped)
        stack_depth: dict[int, int] = {}
        support: dict[int, int] = {}
        locked = set(self._locked_cells)
        for uid in access:
            try:
                stack_depth[uid] = self.storage.stack_depth(uid)
                support[uid] = self.storage.support_value(uid, locked)
            except KeyError:
                continue

        # SKU compatibility map: g_{l,u} = 1 iff sku(u) == line.sku
        # We store it as a closure-friendly dict for the controller.
        sku_compat: dict[tuple[int, int], int] = {}
        sku_lines = {}
        for lid, line_sku in enumerate(self.line_skus):
            sku_lines.setdefault(line_sku, []).append(lid)
        for uid in self.storage._tote_column:
            for lid in sku_lines.get(self.storage._tote_sku[uid], []):
                sku_compat[(lid, uid)] = 1

        # Per-epoch geometry: column of each tote, position of each line
        tote_columns: dict[int, tuple[int, int]] = {
            int(uid): tuple(cell) for uid, cell in self.storage._tote_column.items()
        }
        line_positions = {l: tuple(self.line_positions[l]) for l in range(n_lines)}

        return SystemState(
            epoch_index=self.epoch_index,
            epoch_time=self.t_now,
            line_ids=line_ids,
            B=B,
            S=S,
            hat_lambda=hat_lambda,
            hat_T_so=hat_T_so,
            robot_ids=robot_ids,
            robot_pos=robot_pos,
            tau_free=tau_free,
            battery=battery,
            commitment_busy=commitment_busy,
            shield_locked=shield_locked,
            reservations=reservations,
            access=access,
            stack_depth=stack_depth,
            support=support,
            sku_compat=sku_compat,
            tote_columns=tote_columns,
            line_positions=line_positions,
        )

    # ------------------------------------------------------------------ result

    def _build_result(self) -> SimulatorResult:
        T = self.cfg.experiment.episode_horizon_seconds
        # Stockout minutes
        if self._mech_logger is not None:
            self._mech_logger.close()
        stockout_seconds = sum(buf.starvation_total_seconds for buf in self.buffers)
        stockout_minutes = stockout_seconds / 60.0

        # Per-line stockout
        per_line = {buf.lid: buf.starvation_total_seconds for buf in self.buffers}

        # Line reliability: fraction of time NO line is starving simultaneously.
        # Approximation: compute over per-line starvation seconds. If lines starve
        # disjointly, this gives 1 - (sum / T). If they overlap, worst case is
        # 1 - (max / T). We report the optimistic union estimate clipped at 0.
        union_starv = min(stockout_seconds, T * len(self.buffers))   # safety
        reliability = max(0.0, 1.0 - (union_starv / max(T * len(self.buffers), 1.0)))

        # On-time ratio
        on_time_ratio = (
            self._delivered_on_time / self._delivered_total
            if self._delivered_total > 0 else 0.0
        )

        # Travel + energy
        total_travel = sum(r.cumulative_distance_m for r in self.robots)
        total_energy = sum(r.cumulative_energy for r in self.robots)

        return SimulatorResult(
            seed=self.seed,
            controller_name=getattr(self.controller, "name", "Unknown"),
            horizon_seconds=T,
            stockout_minutes=stockout_minutes,
            on_time_ratio=on_time_ratio,
            line_reliability=reliability,
            total_travel_m=total_travel,
            total_energy=total_energy,
            congestion_index=0.0,
            shield_interventions=sum(r.num_shield_repairs for r in self._epoch_records),
            rejected_commitments=self._cumulative_deferred,
            total_milp_solve_ms=sum(r.milp_solve_ms for r in self._epoch_records),
            total_shield_solve_ms=self._cumulative_shield_ms,
            epoch_records=self._epoch_records,
            per_line_stockout_seconds=per_line,
            delivered_total=self._delivered_total,
            delivered_on_time=self._delivered_on_time,
        )
