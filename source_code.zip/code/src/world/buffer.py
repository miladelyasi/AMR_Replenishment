"""Line-side buffers and consumption process (Section 3, Section 5.1).

The buffer for production line ``l`` holds ``B_l`` totes (capacity
``B^max_l``, safety stock ``S_l``). Totes are consumed at a Poisson rate
``lambda_l`` that may be modulated by surge events.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class LineBuffer:
    """Line-side input buffer for production line ``l``."""

    lid: int
    capacity: int                       # B^max_l
    safety_stock: int                   # S_l
    level: int                          # B_{l,n}

    # Filtered estimate hat_lambda_{l,n} (eq. state)
    hat_lambda: float = 0.0
    filter_alpha: float = 0.05          # smoothing factor

    # Cumulative metrics (used by the Simulator's MetricsCollector)
    served_count: int = 0
    consumption_count: int = 0
    starvation_started_at: float | None = None
    starvation_total_seconds: float = 0.0

    # ------------------------------------------------------------------ filter
    def update_filter(self, instantaneous_rate: float) -> None:
        """Exponentially smooth the demand rate estimate."""
        a = self.filter_alpha
        self.hat_lambda = (1.0 - a) * self.hat_lambda + a * instantaneous_rate

    def projected_time_to_stockout(self, conservative_inflation: float, eps: float) -> float:
        """``hat_T^so_{l,n}`` per eq. (tso)."""
        rate_hi = (1.0 + conservative_inflation) * self.hat_lambda
        return max(self.level, 0) / (rate_hi + eps)

    # ------------------------------------------------------------------ mutations
    def consume(self, t: float) -> bool:
        """Process one consumption event at time ``t``.

        Returns ``True`` if a tote was consumed; ``False`` if the buffer was
        empty and the line is now (or already) starved. The simulator uses
        the return value to decide whether to charge stockout-time.
        """
        self.consumption_count += 1
        if self.level > 0:
            self.level -= 1
            return True
        # Already empty: starvation continues
        if self.starvation_started_at is None:
            self.starvation_started_at = t
        return False

    def deposit(self, t: float, n_units: int = 1) -> int:
        """Add ``n_units`` totes; closes any open starvation interval.

        Returns the number actually accepted (clamped at capacity).
        """
        accepted = min(n_units, self.capacity - self.level)
        self.level += accepted
        self.served_count += accepted

        # Close starvation interval if any
        if self.starvation_started_at is not None and self.level > 0:
            self.starvation_total_seconds += t - self.starvation_started_at
            self.starvation_started_at = None
        return accepted

    def close_starvation_at_horizon(self, t_horizon: float) -> None:
        """Called once at episode end to close any still-open starvation interval."""
        if self.starvation_started_at is not None:
            self.starvation_total_seconds += t_horizon - self.starvation_started_at
            self.starvation_started_at = None

    def is_critical(self) -> bool:
        return self.level <= self.safety_stock


class DemandGenerator:
    """Stochastic consumption process driving each ``LineBuffer``.

    For ``type == "poisson"``, generates Poisson events at rate ``lambda_l``.
    For ``type == "poisson_surge"``, applies a surge multiplier on a
    contiguous window for a randomly selected subset of lines (Sec. 5.4).
    """

    def __init__(
        self,
        line_ids: np.ndarray,
        baseline_rate: float,
        surge_multiplier: float = 1.0,
        surge_duration: float = 0.0,
        surge_start_window: tuple[float, float] = (0.0, 0.0),
        surge_lines_fraction: float = 0.0,
        rng: np.random.Generator | None = None,
    ):
        self.line_ids = np.asarray(line_ids)
        self.baseline_rate = float(baseline_rate)
        self.surge_multiplier = float(surge_multiplier)
        self.surge_duration = float(surge_duration)
        self.surge_start_window = tuple(surge_start_window)
        self.surge_lines_fraction = float(surge_lines_fraction)
        self.rng = rng if rng is not None else np.random.default_rng(0)

        self._surge_lines: set[int] = set()
        self._surge_start: float = 0.0
        self._surge_end: float = 0.0

    # ------------------------------------------------------------------ surge

    def schedule_surge(self) -> None:
        """Sample which lines surge, when, and for how long. Called once per episode."""
        if self.surge_multiplier <= 1.0 or self.surge_duration <= 0.0:
            self._surge_lines = set()
            self._surge_start = 0.0
            self._surge_end = 0.0
            return

        n_surge = int(round(self.surge_lines_fraction * len(self.line_ids)))
        if n_surge <= 0:
            self._surge_lines = set()
            return

        surge_lines = self.rng.choice(self.line_ids, size=n_surge, replace=False)
        self._surge_lines = set(int(x) for x in surge_lines)

        lo, hi = self.surge_start_window
        if hi > lo:
            self._surge_start = float(self.rng.uniform(lo, hi))
        else:
            self._surge_start = float(lo)
        self._surge_end = self._surge_start + self.surge_duration

    def is_surging(self, line_id: int, t: float) -> bool:
        return (
            line_id in self._surge_lines
            and self._surge_start <= t < self._surge_end
        )

    # ------------------------------------------------------------------ events

    def instantaneous_rate(self, line_id: int, t: float) -> float:
        """Return ``lambda_l(t)`` accounting for active surges."""
        rate = self.baseline_rate
        if self.is_surging(line_id, t):
            rate *= self.surge_multiplier
        return rate

    def sample_next_event_time(self, line_id: int, t_now: float) -> float:
        """Inverse-CDF sample of the next consumption event for ``line_id``.

        We use the *current* rate at ``t_now`` (piecewise-constant rate
        approximation). Within a surge window the higher rate is sampled;
        outside, the baseline rate. This is a thinning approximation that
        is adequate for the present setting.
        """
        rate = self.instantaneous_rate(line_id, t_now)
        if rate <= 0.0:
            return float("inf")
        # Exp(rate) inter-arrival
        gap = float(self.rng.exponential(1.0 / rate))
        return t_now + gap

    # ------------------------------------------------------------------ diagnostics

    def surge_window(self) -> tuple[float, float] | None:
        if not self._surge_lines:
            return None
        return (self._surge_start, self._surge_end)

    def surge_lines(self) -> set[int]:
        return set(self._surge_lines)
