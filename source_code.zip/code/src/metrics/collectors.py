"""Online metrics collector (Section 5.1 "Performance metrics").

Tracks the seven primary metrics:

1. Stockout minutes (cumulative line-starvation time)
2. On-time delivery ratio
3. Line reliability (fraction of time all lines non-starved)
4. Travel + energy
5. Congestion indicators
6. Shield interventions
7. Computational latency (MILP, shield, end-to-end per epoch)

Plus tail-risk diagnostics: worst-decile stockout, surge-response lag.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from world.simulator import EpochRecord


@dataclass
class MetricsCollector:
    """Stateful accumulator updated by the simulator on each epoch."""

    line_ids: np.ndarray
    horizon_seconds: float

    # Cumulative counters
    stockout_minutes: float = 0.0
    served_count: int = 0
    on_time_count: int = 0
    total_travel_m: float = 0.0
    total_energy: float = 0.0
    shield_intervention_count: int = 0
    rejected_commitment_count: int = 0
    total_milp_solve_ms: float = 0.0
    total_shield_solve_ms: float = 0.0

    # All-lines-up time tracker
    all_up_seconds: float = 0.0

    # Per-line stockout time (for line_reliability)
    line_stockout_seconds: dict[int, float] = field(default_factory=dict)

    # Per-epoch trace
    epoch_log: list[EpochRecord] = field(default_factory=list)

    # Demand-surge bookkeeping
    surge_start_time: float | None = None
    first_summary_during_surge: float | None = None

    # ------------------------------------------------------------------ API

    def record_epoch(self, record: EpochRecord) -> None:
        raise NotImplementedError

    def record_consumption_event(self, line_id: int, t: float, caused_stockout: bool) -> None:
        raise NotImplementedError

    def record_delivery(self, line_id: int, t: float, was_on_time: bool) -> None:
        raise NotImplementedError

    def record_travel(self, robot_id: int, distance_m: float, energy: float) -> None:
        raise NotImplementedError

    def record_shield_repair(self, n_repairs: int, n_rejections: int) -> None:
        raise NotImplementedError

    def finalize(self) -> dict:
        """Compute final aggregate metrics from accumulated counters.

        Returns a dict ready to be turned into a ``SimulatorResult``.
        """
        raise NotImplementedError
