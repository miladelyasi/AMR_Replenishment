"""Reward function ``r_n`` from eq. (reward) of Section 4.1.

::

    r_n = -alpha * StockoutMin_n
          - beta * Travel_n
          - nu * Energy_n
          - xi * Congestion_n
          - omega * ShieldInt_n
          - omega_rej * Reject_n
          + delta_ot * OnTime_n

All terms are computed over the holding interval ``[kappa_n, kappa_{n+1})``.
This is distinct from the MILP objective in Sec. 4.2; see the discussion
in Section 4.2 paragraph "Objective".
"""

from __future__ import annotations

from dataclasses import dataclass

from common.config import RewardWeights


@dataclass
class RewardComponents:
    """The seven raw quantities entering eq. (reward)."""

    stockout_minutes: float        # StockoutMin_n
    travel_m: float                # Travel_n
    energy: float                  # Energy_n
    congestion: float              # Congestion_n
    shield_interventions: int      # ShieldInt_n
    rejections: int                # Reject_n
    on_time_count: int             # OnTime_n


def compute_reward(components: RewardComponents, weights: RewardWeights) -> float:
    """Linear combination per eq. (reward)."""
    raise NotImplementedError
