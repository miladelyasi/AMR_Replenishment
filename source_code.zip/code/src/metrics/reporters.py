"""Paper-ready aggregation and CSV/LaTeX writers.

Aggregates per-replication ``SimulatorResult`` objects into the tables
shown in Section 5 of the manuscript, including:

* Mean ± IQR / 95% CI
* Worst-decile (tail-risk) statistics
* Pareto frontier coordinates (energy vs. stockout)
* Solver-runtime histograms
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from world.simulator import SimulatorResult


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

@dataclass
class AggregateStats:
    mean: float
    median: float
    p25: float
    p75: float
    p10: float
    p90: float
    std: float


def summarize_replications(
    results: list[SimulatorResult],
    metric_name: str,
) -> AggregateStats:
    """Compute summary statistics for one metric across replications."""
    raise NotImplementedError


def build_paper_dataframe(
    results_by_method: dict[str, list[SimulatorResult]],
    metrics: list[str] | None = None,
) -> pd.DataFrame:
    """Long-format DataFrame ``(method, metric, replication, value)``.

    Suitable for piping into seaborn / pandas.groupby for paper figures.
    """
    raise NotImplementedError


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def write_paper_csv(df: pd.DataFrame, path: str | Path) -> None:
    """Save raw long-format results to CSV."""
    raise NotImplementedError


def write_paper_table(
    df: pd.DataFrame,
    path: str | Path,
    metrics: list[str],
    methods: list[str],
    booktabs: bool = True,
) -> None:
    """Write a LaTeX table with mean ± IQR per (method, metric).

    Output uses the ``booktabs`` style by default (compatible with the
    ``\\toprule / \\midrule / \\bottomrule`` conventions in the manuscript).
    """
    raise NotImplementedError
