"""
src/baselines/_milp_logger.py   (v2 — uses real SystemState fields)

Per-epoch JSONL logger for MILPOnly. Produces the schema consumed by
pruner/pruner.py, now with:
  * real decision time (state.epoch_time) and epoch_index
  * per-job T_so / buffer / lambda pulled from state via line_ids
  * real stack_depth / support pulled from state (keyed by tote)
  * a compact state_features block for the F2 terminal-value critic
  * fixed falsy-`mode` bug

Reward for F2 is NOT logged here; it is reconstructed offline from the
logged buffer trajectory (B) and holding time (epoch_time deltas), so the
logger stays completely non-invasive.
"""
from __future__ import annotations
import json, os
from typing import Any, Dict, List, Tuple

import numpy as np


# --------------------------------------------------------------------------- #
# small helpers
# --------------------------------------------------------------------------- #
def _num(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


def _as_list(a):
    try:
        return [float(v) for v in np.asarray(a).ravel().tolist()]
    except Exception:
        return []


def _line_index_map(state) -> Dict[int, int]:
    """line_id -> row index into the per-line arrays."""
    try:
        ids = np.asarray(state.line_ids).ravel().tolist()
        return {int(lid): i for i, lid in enumerate(ids)}
    except Exception:
        return {}


def _job_triplet(j: Any) -> Tuple[Any, Any, Any]:
    """Return (line_id, tote_id, mode) from a job object or tuple.
    Uses explicit None checks (NOT `a or b`) so mode==0 is preserved."""
    if isinstance(j, tuple):
        t = list(j) + [None, None, None]
        return t[0], t[1], t[2]
    lid = getattr(j, "line_id", None)
    if lid is None:
        lid = getattr(j, "lid", None)
    uid = getattr(j, "tote_id", None)
    if uid is None:
        uid = getattr(j, "uid", None)
    mode = getattr(j, "mode", None)
    if mode is None:
        mode = getattr(j, "service_mode", None)
    return lid, uid, mode


def _job_key(j: Any) -> str:
    lid, uid, mode = _job_triplet(j)
    return f"{lid}_{uid}_{mode}"


def _unpack_commitment(c: Any):
    """Return (rid, job_key, slot) or None. Tuple or object form."""
    if isinstance(c, tuple) and len(c) >= 3:
        return (c[0], _job_key(c[1]), int(c[2]))
    rid = getattr(c, "rid", None)
    if rid is None:
        rid = getattr(c, "robot_id", None)
    if rid is None:
        return None
    job = getattr(c, "job", None)
    if job is None:
        job = getattr(c, "jid", None)
    if job is None:
        job = getattr(c, "job_id", None)
    q = getattr(c, "q", None)
    if q is None:
        q = getattr(c, "start_slot", None)
    if q is None:
        q = getattr(c, "slot", None)
    if q is None:
        return None
    return (rid, _job_key(job), int(q))


# --------------------------------------------------------------------------- #
class MILPRolloutLogger:
    """One instance per episode; reused across that episode's epochs."""

    def __init__(self, rollout_path: str, episode_id: int = 0):
        self.path = rollout_path
        self.episode_id = int(episode_id)
        self._n = 0
        os.makedirs(os.path.dirname(rollout_path) or ".", exist_ok=True)
        self._fh = open(rollout_path, "w", buffering=1)

    # ------------------------------------------------------------------ #
    def log_solve(self, *, decision_time_s, state, feasible, jobs, sol,
                  robots, sim, pickup_fn, lock_fn) -> None:

        # --- real time / index from the state -------------------------- #
        epoch_time = _num(getattr(state, "epoch_time", decision_time_s))
        epoch_index = int(getattr(state, "epoch_index", self._n))

        # --- per-line lookups ----------------------------------------- #
        lidx = _line_index_map(state)
        B = np.asarray(getattr(state, "B", []), dtype=float).ravel()
        S = np.asarray(getattr(state, "S", []), dtype=float).ravel()
        lam = np.asarray(getattr(state, "hat_lambda", []), dtype=float).ravel()
        Tso = np.asarray(getattr(state, "hat_T_so", []), dtype=float).ravel()

        def line_stats(lid):
            i = lidx.get(int(lid)) if lid is not None else None
            if i is None:
                return {}
            out = {}
            if i < len(Tso):
                out["T_so"] = float(Tso[i])
            if i < len(B):
                out["B"] = float(B[i])
            if i < len(S):
                out["S"] = float(S[i])
            if i < len(lam):
                out["lambda"] = float(lam[i])
            return out

        stack_depth = getattr(state, "stack_depth", {}) or {}
        support = getattr(state, "support", {}) or {}
        tau_ru_map = getattr(state, "tau_xy_ru", {}) or {}
        tau_ul_map = getattr(state, "tau_xy_ul", {}) or {}

        # --- selected (r, jkey, q) from the MILP solution ------------- #
        sel = set()
        commitments = list(getattr(sol, "commitments", []) or [])
        for c in commitments:
            up = _unpack_commitment(c)
            if up is not None:
                sel.add(up)
        sel_pairs = {(rid, jk): q for (rid, jk, q) in sel}

        # --- candidate pairs from feasible ---------------------------- #
        seen = {}
        pair_rows: List[dict] = []
        job_feats_out: Dict[str, dict] = {}
        feas_list = list(feasible)

        for entry in feas_list:
            up = _unpack_commitment(entry)
            if up is None:
                continue
            rid, jk, q = up
            if (rid, jk) in seen:
                continue
            seen[(rid, jk)] = True

            jobj = entry[1] if (isinstance(entry, tuple) and len(entry) >= 2) else None
            lid, uid, mode = _job_triplet(jobj if jobj is not None else jk)
            # if jk was a string we can't triplet it; re-parse from key
            if jobj is None:
                try:
                    lid, uid, mode = jk.split("_")
                    lid, uid = int(lid), int(uid)
                except Exception:
                    pass

            ls = line_stats(lid)
            depth = stack_depth.get(uid)
            sup = support.get(uid)

            # pair features: prefer the surrogate travel times the MILP used
            feats: Dict[str, float] = {}
            tru = tau_ru_map.get((rid, uid))
            tul = tau_ul_map.get((uid, lid))
            if tru is None:
                # recompute via sim as a fallback
                try:
                    cell = sim.storage.find_tote_column(uid)
                    if cell is not None:
                        tru = float(sim.grid.travel_time(
                            tuple(sim.robots[rid].pos), cell))
                except Exception:
                    tru = None
            if tul is None:
                try:
                    cell = sim.storage.find_tote_column(uid)
                    if cell is not None and lid is not None \
                            and lid < len(sim.line_positions):
                        tul = float(sim.grid.travel_time(
                            cell, sim.line_positions[lid]))
                except Exception:
                    tul = None
            if tru is not None:
                feats["tau_xy_ru"] = float(tru)
            if tul is not None:
                feats["tau_xy_ul"] = float(tul)
            if depth is not None:
                feats["depth"] = float(depth)
            if sup is not None:
                feats["support"] = float(sup)
            if mode is not None:
                feats["is_excavation"] = 1.0 if str(mode).upper().endswith("E") \
                    or str(mode) == "2" else 0.0
            # urgency signal AT THE PAIR LEVEL (this is what was missing) ---
            if "T_so" in ls:
                feats["T_so"] = ls["T_so"]
            if "B" in ls:
                feats["buffer"] = ls["B"]
            if "S" in ls:
                feats["safety"] = ls["S"]
            if "lambda" in ls:
                feats["lambda"] = ls["lambda"]
            try:
                feats["pickup_seconds"] = float(pickup_fn(
                    depth if depth is not None else 0,
                    sup if sup is not None else 1.0, mode))
                feats["lock_seconds"] = float(lock_fn(
                    depth if depth is not None else 0,
                    sup if sup is not None else 1.0, mode))
            except Exception:
                pass

            slot = sel_pairs.get((rid, jk), -1)
            pair_rows.append({
                "robot_id": str(rid),
                "job_id": jk,
                "features": feats,
                "selected": int(slot >= 0),
                "selected_slot": int(slot),
            })
            # per-job feature dict (now non-empty)
            jf = dict(ls)
            if depth is not None:
                jf["depth"] = float(depth)
            if sup is not None:
                jf["support"] = float(sup)
            job_feats_out[jk] = jf

        # --- robot features ------------------------------------------- #
        rb = np.asarray(getattr(state, "battery", []), dtype=float).ravel()
        tf = np.asarray(getattr(state, "tau_free", []), dtype=float).ravel()
        rpos = getattr(state, "robot_pos", None)
        robot_ids = np.asarray(getattr(state, "robot_ids", []),
                               dtype=float).ravel().tolist()
        robot_feats = {}
        for i, rid in enumerate(robot_ids):
            d = {}
            if i < len(rb):
                d["battery"] = float(rb[i])
            if i < len(tf):
                d["tau_free"] = float(tf[i])
            try:
                d["pos_x"] = float(rpos[i][0]); d["pos_y"] = float(rpos[i][1])
            except Exception:
                pass
            robot_feats[str(int(rid))] = d

        # --- state_features block for the F2 critic ------------------- #
        cong = getattr(state, "congestion_summary", None)
        n_critical = int(np.sum(Tso <= 30.0)) if Tso.size else 0
        state_features = {
            "epoch_time": epoch_time,
            "epoch_index": epoch_index,
            "B": _as_list(B),
            "S": _as_list(S),
            "hat_lambda": _as_list(lam),
            "hat_T_so": _as_list(Tso),
            "battery": _as_list(rb),
            "tau_free": _as_list(tf),
            "congestion_norm": float(np.linalg.norm(np.asarray(cong)))
                if cong is not None else 0.0,
            "n_lines_critical": n_critical,
            "min_T_so": float(Tso.min()) if Tso.size else 0.0,
            "mean_buffer": float(B.mean()) if B.size else 0.0,
        }

        rec = {
            "episode_id": self.episode_id,
            "epoch_id": self._n,
            "epoch_index": epoch_index,
            "decision_time_s": epoch_time,
            "global_features": {
                "n_pairs": float(len(pair_rows)),
                "n_jobs": float(len(job_feats_out)),
                "n_robots": float(len(robot_feats)),
                "n_lines_critical": float(n_critical),
                "min_T_so": state_features["min_T_so"],
            },
            "robots": robot_feats,
            "jobs": job_feats_out,
            "pairs": pair_rows,
            "v_selected": {},
            "state_features": state_features,
            "milp_meta": {
                "solve_time_ms": _num(getattr(sol, "runtime_ms", 0.0)),
                "objective": _num(getattr(sol, "objective", float("nan")),
                                   float("nan")),
                "gap": _num(getattr(sol, "mip_gap", float("nan")),
                            float("nan")),
                "n_binaries": len(feas_list),
                "incumbent_found": int(bool(commitments)),
                "status": 2,
            },
        }
        self._fh.write(json.dumps(rec, separators=(",", ":")) + "\n")
        self._n += 1

    # ------------------------------------------------------------------ #
    def close(self):
        if self._fh and not self._fh.closed:
            self._fh.flush()
            try:
                os.fsync(self._fh.fileno())
            except Exception:
                pass
            self._fh.close()


# --- record capture shim: lets CandidatePrunerRuntime reuse log_solve's exact
#     feature/record construction without writing to disk -------------------- #
class _CaptureFH:
    def __init__(self):
        self.last = None
    def write(self, s):
        import json as _json
        self.last = _json.loads(s)
    def flush(self): pass
    def fileno(self): raise OSError("capture")
    @property
    def closed(self): return False
    def close(self): pass


def _build_record(builder, *, decision_time_s, state, feasible, jobs, sol,
                  robots, sim, pickup_fn, lock_fn, return_only=False):
    cap = _CaptureFH()
    saved = builder._fh
    builder._fh = cap
    try:
        builder.log_solve(decision_time_s=decision_time_s, state=state,
                          feasible=feasible, jobs=jobs, sol=sol,
                          robots=robots, sim=sim,
                          pickup_fn=pickup_fn, lock_fn=lock_fn)
    finally:
        builder._fh = saved
        builder._n -= 1  # undo the counter bump; this was not a real epoch
    return cap.last


# =========================================================================== #
# Inference-time pruner. Loads a trained F1 checkpoint and filters the feasible
# set to the learned top-k (plus an urgency floor). Reuses MILPRolloutLogger's
# record builder so inference features are byte-identical to training features.
# =========================================================================== #

class CandidatePrunerRuntime:
    """Drop-in candidate filter for MILPOnly.

    Usage (inside MILPOnlyController.decide, after `feasible` is built):
        feasible = self._pruner_rt.filter(
            state, feasible, self.sim,
            self._make_pickup_fn(), self._make_lock_fn())
    """

    def __init__(self, ckpt_path: str, index_path: str, k: int = 80,
                 T_crit: float = 30.0):
        import sys
        from pathlib import Path
        _root = Path(__file__).resolve().parents[2]
        if str(_root) not in sys.path:
            sys.path.insert(0, str(_root))
        import torch
        from pruner.pruner import FeatureIndex, PrunerNetwork
        self._torch = torch
        self.idx = FeatureIndex.load(index_path)
        ck = torch.load(ckpt_path, map_location="cpu")
        self.net = PrunerNetwork(in_dim=ck["config"]["in_dim"],
                                 hidden=ck["config"]["hidden"],
                                 depth=ck["config"]["depth"])
        self.net.load_state_dict(ck["model_state"])
        self.net.eval()
        self.k = int(k)
        self.T_crit = float(T_crit)
        # one logger-less record builder; sol is faked (no labels needed)
        self._builder = MILPRolloutLogger.__new__(MILPRolloutLogger)
        self._builder.episode_id = 0
        self._builder._n = 0
        self._builder._fh = None

    class _NoSol:
        commitments = []
        runtime_ms = 0.0
        objective = float("nan")
        mip_gap = float("nan")

    def _vectorize(self, rec):
        """Replicate pruner.pruner.EpochDataset.__getitem__ feature assembly."""
        import numpy as np
        idx = self.idx

        def vec(d, keys):
            return np.asarray([float(d.get(k, 0.0))
                               if isinstance(d.get(k), (int, float)) else 0.0
                               for k in keys], dtype=np.float32)

        def std(v, m, s):
            return (v - np.asarray(m, np.float32)) / np.asarray(s, np.float32)

        g = std(vec(rec.get("global_features", {}), idx.global_keys),
                idx.global_mean, idx.global_std)
        robots = rec.get("robots", {}) or {}
        jobs = rec.get("jobs", {}) or {}
        rv = {r: std(vec(f, idx.robot_keys), idx.robot_mean, idx.robot_std)
              for r, f in robots.items()}
        jv = {j: std(vec(f, idx.job_keys), idx.job_mean, idx.job_std)
              for j, f in jobs.items()}
        pairs = rec.get("pairs", [])
        Fr, Fj, Fp, Fg = (len(idx.robot_keys), len(idx.job_keys),
                          len(idx.pair_keys), len(idx.global_keys))
        feats = np.zeros((len(pairs), Fr + Fj + Fp + Fg), dtype=np.float32)
        for k, p in enumerate(pairs):
            r_ = rv.get(p["robot_id"], np.zeros(Fr, np.float32))
            j_ = jv.get(p["job_id"], np.zeros(Fj, np.float32))
            pv = std(vec(p.get("features", {}), idx.pair_keys),
                     idx.pair_mean, idx.pair_std)
            feats[k] = np.concatenate([r_, j_, pv, g])
        return feats, pairs

    def filter(self, state, feasible, sim, pickup_fn, lock_fn, k=None):
        import numpy as np
        feas_list = list(feasible)
        if not feas_list:
            return feas_list
        k_use = int(k if k is not None else self.k)

        # Build the SAME record the logger would write (labels irrelevant).
        rec = MILPRolloutLogger.log_solve.__wrapped__ if hasattr(
            MILPRolloutLogger.log_solve, "__wrapped__") else None
        # Direct call into a record-building helper:
        rec = _build_record(self._builder, decision_time_s=0.0, state=state,
                            feasible=feas_list, jobs=None,
                            sol=CandidatePrunerRuntime._NoSol(),
                            robots=sim.robots, sim=sim,
                            pickup_fn=pickup_fn, lock_fn=lock_fn,
                            return_only=True)
        feats, pairs = self._vectorize(rec)
        if len(pairs) == 0:
            return feas_list

        torch = self._torch
        with torch.no_grad():
            x = torch.from_numpy(feats).unsqueeze(0)
            m = torch.ones((1, x.shape[1]), dtype=torch.bool)
            scores = self.net(x, m).squeeze(0).numpy()

        # urgency floor: keep any pair whose job line has T_so <= T_crit
        keep_idx = set()
        for i, p in enumerate(pairs):
            tso = p["features"].get("T_so")
            if isinstance(tso, (int, float)) and tso <= self.T_crit:
                keep_idx.add(i)
        order = np.argsort(-scores)
        for i in order:
            if len(keep_idx) >= k_use:
                break
            keep_idx.add(int(i))

        # map kept pair-(robot_id,job_id) back to feasible (r,j,q) entries
        kept_keys = {(pairs[i]["robot_id"], pairs[i]["job_id"])
                     for i in keep_idx}
        out = []
        for entry in feas_list:
            up = _unpack_commitment(entry)
            if up is None:
                continue
            rid, jk, q = up
            if (str(rid), jk) in kept_keys:
                out.append(entry)
        return out if out else feas_list