"""Hierarchical urgency-ranking heuristic (Section 5.2 of the manuscript).

Ranks ALL lines by predicted depletion urgency (ascending hat_T_so), then
greedily matches the nearest eligible robot to a compatible tote, preferring
directly retrievable. Unlike the Reactive controller, this baseline serves
even non-critical lines as long as robots are available, providing a
mid-tier comparison between greedy industrial heuristics and the proposed
joint-optimization approach.

It does NOT solve the joint assignment-and-reservation problem — it has
no foresight into future congestion or shared-interface contention. The
manuscript notes this as the key limitation that motivates the full
neuro-symbolic architecture.
"""

from __future__ import annotations

from common.controller import Controller, ControllerOutput
from common.enums import AccessClass, ServiceMode
from common.state import SystemState
from common.types import Commitment, Job


class UrgencyRankController(Controller):
    name = "UrgencyRank"

    def __init__(self, slot_size: float = 5.0, only_below_full: bool = True, urgency_horizon: float = float("inf")):
        """``only_below_full``: skip lines whose buffer is at capacity already."""
        self.slot_size = slot_size
        self.only_below_full = only_below_full
        self.urgency_horizon = urgency_horizon

    def decide(self, state: SystemState) -> ControllerOutput:
        # 1. Eligible robots
        eligible = [
            int(rid) for rid in state.robot_ids
            if not state.commitment_busy[int(rid)]
            and not state.shield_locked[int(rid)]
        ]
        if not eligible:
            return ControllerOutput(commitments=[], diagnostics={"num_candidates": 0})

        # 2. Rank all lines by urgency (smallest hat_T_so first)
        line_order = sorted(
            [int(l) for l in state.line_ids if float(state.hat_T_so[int(l)]) <= self.urgency_horizon],
            key=lambda l: float(state.hat_T_so[l]),
        )

        # 3. Pre-bucket compatible totes by line
        compatible_by_line: dict[int, list[int]] = {l: [] for l in line_order}
        for (lid, uid), g in state.sku_compat.items():
            if g != 1 or lid not in compatible_by_line:
                continue
            ac = state.access.get(uid, AccessClass.INFEASIBLE)
            if ac == AccessClass.INFEASIBLE:
                continue
            compatible_by_line[lid].append(uid)

        n_candidates = sum(len(v) for v in compatible_by_line.values())

        # 4. Greedy: for each line in urgency order, assign closest available
        #    robot to its best (DIRECT-preferred) compatible tote.
        commitments: list[Commitment] = []
        used_robots: set[int] = set()
        used_totes: set[int] = set()

        for lid in line_order:
            if not eligible or len(used_robots) == len(eligible):
                break
            # Skip lines that are already at full capacity (no space to deposit)
            # if only_below_full is True. (We don't see capacity in state directly,
            # but level near max is a reasonable proxy.)
            #
            # Heuristic: if hat_T_so is very large (line is healthy), don't bother.
            # We still serve lines down the queue as long as robots remain.

            tote_pool = [u for u in compatible_by_line[lid] if u not in used_totes]
            if not tote_pool:
                continue

            # Prefer DIRECT, then shallow excavation
            tote_pool.sort(key=lambda u: (
                0 if state.access[u] == AccessClass.DIRECT else 1,
                state.stack_depth.get(u, 99),
            ))

            best_rid: int | None = None
            best_uid: int | None = None
            best_dist = float("inf")

            for uid in tote_pool:
                tote_cell = state.tote_columns.get(uid)
                if tote_cell is None:
                    continue
                for rid in eligible:
                    if rid in used_robots:
                        continue
                    rx, ry = state.robot_pos[rid]
                    tx, ty = tote_cell
                    d = abs(int(rx) - tx) + abs(int(ry) - ty)
                    if d < best_dist:
                        best_dist = d
                        best_rid = rid
                        best_uid = uid

            if best_rid is None or best_uid is None:
                continue

            mode = (
                ServiceMode.DIRECT
                if state.access[best_uid] == AccessClass.DIRECT
                else ServiceMode.EXCAVATION
            )
            cm = Commitment(
                robot_id=best_rid,
                job=Job(line_id=lid, tote_id=best_uid, mode=mode),
                start_slot=0,
                epoch_time=state.epoch_time,
                slot_size=self.slot_size,
            )
            commitments.append(cm)
            used_robots.add(best_rid)
            used_totes.add(best_uid)

        return ControllerOutput(
            commitments=commitments,
            diagnostics={
                "num_candidates": n_candidates,
                "num_eligible_robots": len(eligible),
                "num_lines_served": len(commitments),
            },
        )
