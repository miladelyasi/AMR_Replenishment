"""End-to-end DRL with soft constraint handling (Section 5.2 of the manuscript).

The policy directly proposes commitments without an embedded MILP
projector. Hard constraints are encouraged by reward penalties only
(plus a lightweight feasibility filter pre-shield). The downstream
shield still guarantees physical safety, so the comparison isolates
the value of *structural* feasibility enforcement.
"""

from __future__ import annotations

from common.config import Config
from common.controller import Controller, ControllerOutput
from common.state import SystemState
from policy.actor_critic import ActorCritic


class SoftDRLController(Controller):
    name = "DRL-Soft"

    def __init__(self, cfg: Config, actor_critic: ActorCritic, training: bool = True):
        self.cfg = cfg
        self.actor_critic = actor_critic
        self.training = training

    def decide(self, state: SystemState) -> ControllerOutput:
        raise NotImplementedError
