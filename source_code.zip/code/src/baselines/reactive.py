"""Reactive threshold-based dispatching (Section 5.2 of the manuscript).

Whenever a line's buffer drops at or below its safety stock, dispatch the
closest eligible robot to a SKU-compatible tote. Prefer directly retrievable
totes over excavation-feasible ones. No reservation logic, no anticipation —
when several robots could serve the same need, the closest wins; when several
lines compete, the most urgent (smallest hat_T_so) gets first pick.

This is the simplest "industrial heuristic" benchmark — useful as a sanity
floor for the more sophisticated MILP and RL methods.
"""

from __future__ import annotations

from common.controller import Controller, ControllerOutput
from common.enums import AccessClass, ServiceMode
from common.state import SystemState
from common.types import Commitment, Job


class ReactiveThresholdController(Controller):
    name = "Reactive"

    def __init__(self, slot_size: float = 5.0, prefer_direct: bool = True, safety_mult: float = 1.0):
        self.slot_size = slot_size
        self.prefer_direct = prefer_direct
        self.safety_mult = safety_mult

    def decide(self, state: SystemState) -> ControllerOutput:
        # 1. Eligible robots = idle, not shield-locked
        eligible = [
            int(rid) for rid in state.robot_ids
            if not state.commitment_busy[int(rid)]
            and not state.shield_locked[int(rid)]
        ]
        if not eligible:
            return ControllerOutput(commitments=[], diagnostics={"num_candidates": 0})

        # 2. Critical lines (B_l <= S_l), ranked by urgency (smallest hat_T_so first)
        critical = sorted(
            [int(lid) for lid in state.line_ids
             if state.B[int(lid)] <= self.safety_mult * state.S[int(lid)]],
            key=lambda l: float(state.hat_T_so[l]),
        )

        if not critical:
            # No line below safety stock — reactive policy idles
            return ControllerOutput(commitments=[], diagnostics={"num_candidates": 0,
                                                                  "reason": "no_critical_lines"})

        # 3. Pre-bucket compatible totes by line and access class
        compatible_by_line: dict[int, list[int]] = {l: [] for l in critical}
        for (lid, uid), g in state.sku_compat.items():
            if g != 1 or lid not in compatible_by_line:
                continue
            ac = state.access.get(uid, AccessClass.INFEASIBLE)
            if ac == AccessClass.INFEASIBLE:
                continue
            compatible_by_line[lid].append(uid)

        # 4. Greedy assign closest robot to a tote for each critical line
        commitments: list[Commitment] = []
        used_robots: set[int] = set()
        used_totes: set[int] = set()
        n_candidates = sum(len(v) for v in compatible_by_line.values())

        for lid in critical:
            tote_pool = [u for u in compatible_by_line[lid] if u not in used_totes]
            if not tote_pool:
                continue

            # Prefer directly-retrievable; tiebreak by depth ascending
            tote_pool.sort(key=lambda u: (
                0 if state.access[u] == AccessClass.DIRECT else 1,
                state.stack_depth.get(u, 99),
            ))

            best_rid: int | None = None
            best_uid: int | None = None
            best_dist: float = float("inf")

            # Find (closest robot, tote) pair via Manhattan distance
            for uid in tote_pool:
                tote_cell = state.tote_columns.get(uid)
                if tote_cell is None:
                    continue
                for rid in eligible:
                    if rid in used_robots:
                        continue
                    rx, ry = state.robot_pos[rid]
                    tx, ty = tote_cell
                    d = abs(int(rx) - tx) + abs(int(ry) - ty)
                    if d < best_dist:
                        best_dist = d
                        best_rid = rid
                        best_uid = uid

            if best_rid is None or best_uid is None:
                continue   # no robot available

            mode = (
                ServiceMode.DIRECT
                if state.access[best_uid] == AccessClass.DIRECT
                else ServiceMode.EXCAVATION
            )
            cm = Commitment(
                robot_id=best_rid,
                job=Job(line_id=lid, tote_id=best_uid, mode=mode),
                start_slot=0,
                epoch_time=state.epoch_time,
                slot_size=self.slot_size,
            )
            commitments.append(cm)
            used_robots.add(best_rid)
            used_totes.add(best_uid)

        return ControllerOutput(
            commitments=commitments,
            diagnostics={
                "num_candidates": n_candidates,
                "num_critical_lines": len(critical),
                "num_eligible_robots": len(eligible),
            },
        )
