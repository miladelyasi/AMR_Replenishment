"""Nearest-robot / shortest-travel baseline — Section 5.2.

Greedily forms the globally shortest robot->tote assignments by Manhattan
travel surrogate, with NO urgency, contention, or joint-feasibility
reasoning. It serves any line that has a compatible, retrievable tote and
an available robot, always taking the cheapest remaining (robot, tote)
pair. This isolates the value of urgency- and optimization-based logic:
the difference between this and UrgencyRank measures the contribution of
urgency ordering; the difference between this and MILPOnly measures the
contribution of joint optimization.
"""

from __future__ import annotations

from common.controller import Controller, ControllerOutput
from common.enums import AccessClass, ServiceMode
from common.state import SystemState
from common.types import Commitment, Job


class NearestRobotController(Controller):
    name = "NearestRobot"

    def __init__(self, slot_size: float = 5.0):
        self.slot_size = slot_size

    def reset(self) -> None:
        pass

    def decide(self, state: SystemState) -> ControllerOutput:
        eligible = [
            int(rid) for k, rid in enumerate(state.robot_ids)
            if not bool(state.commitment_busy[k])
            and not bool(state.shield_locked[k])
        ]
        if not eligible or state.sku_compat is None:
            return ControllerOutput(
                commitments=[],
                diagnostics={"num_candidates": 0,
                             "num_eligible_robots": len(eligible)},
            )

        rid_to_idx = {int(rid): k for k, rid in enumerate(state.robot_ids)}

        # Build the full feasible (robot, line, tote) candidate list with
        # Manhattan travel cost; only compatible, retrievable totes.
        cands: list[tuple[int, int, int, int]] = []  # (dist, rid, lid, uid)
        for (lid, uid), g in state.sku_compat.items():
            if g != 1:
                continue
            lid = int(lid)
            uid = int(uid)
            ac = state.access.get(uid, AccessClass.INFEASIBLE)
            if ac == AccessClass.INFEASIBLE:
                continue
            cell = state.tote_columns.get(uid)
            if cell is None:
                continue
            tx, ty = cell
            for rid in eligible:
                rx, ry = state.robot_pos[rid_to_idx[rid]]
                d = abs(int(rx) - tx) + abs(int(ry) - ty)
                cands.append((d, rid, lid, uid))

        n_cand = len(cands)
        if not cands:
            return ControllerOutput(
                commitments=[],
                diagnostics={"num_candidates": 0,
                             "num_eligible_robots": len(eligible)},
            )

        # Greedy global shortest-first matching: each robot and each tote
        # used at most once; a line may receive multiple totes if cheap.
        cands.sort(key=lambda t: (t[0], t[1], t[2], t[3]))
        used_r: set[int] = set()
        used_u: set[int] = set()
        commitments: list[Commitment] = []
        for d, rid, lid, uid in cands:
            if rid in used_r or uid in used_u:
                continue
            if len(used_r) == len(eligible):
                break
            mode = (ServiceMode.DIRECT
                    if state.access[uid] == AccessClass.DIRECT
                    else ServiceMode.EXCAVATION)
            commitments.append(Commitment(
                robot_id=rid,
                job=Job(line_id=lid, tote_id=uid, mode=mode),
                start_slot=0,
                epoch_time=state.epoch_time,
                slot_size=self.slot_size,
            ))
            used_r.add(rid)
            used_u.add(uid)

        return ControllerOutput(
            commitments=commitments,
            diagnostics={
                "num_candidates": n_cand,
                "num_eligible_robots": len(eligible),
                "num_lines_served": len(commitments),
            },
        )