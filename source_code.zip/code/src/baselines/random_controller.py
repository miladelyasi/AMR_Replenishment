"""Trivial random controller for smoke-testing the simulator (Stage 1).

For each idle, eligible robot, picks a uniformly random feasible
(line, tote, mode) candidate. Used only to validate the simulator
pipeline before the real baselines are wired in.
"""

from __future__ import annotations

import numpy as np

from common.controller import Controller, ControllerOutput
from common.enums import AccessClass, ServiceMode
from common.state import SystemState
from common.types import Commitment, Job


class RandomController(Controller):
    name = "Random"

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)

    def decide(self, state: SystemState) -> ControllerOutput:
        commitments: list[Commitment] = []

        # Build the set of eligible idle robots (Stage-1 simplification:
        # any robot not currently committed; we don't enforce battery here
        # since the simulator already reports battery).
        eligible_robots = [
            int(r) for r in state.robot_ids
            if not state.commitment_busy[int(r)]
        ]
        if not eligible_robots:
            return ControllerOutput(commitments=[], diagnostics={"num_candidates": 0})
        self.rng.shuffle(eligible_robots)

        # Build candidate jobs from the access map.
        # We prefer to send robots toward critical lines, but pick uniformly
        # at random among lines with B <= safety_stock; otherwise any line.
        critical_lines = [
            int(lid) for lid in state.line_ids
            if state.B[int(lid)] <= state.S[int(lid)]
        ]
        if critical_lines:
            target_lines = critical_lines
        else:
            target_lines = list(state.line_ids.tolist())

        # Pre-bucket totes by SKU compatibility per line.
        # state.sku_compat is a (lid, uid) -> {0,1} dict.
        compatible_by_line: dict[int, list[int]] = {int(lid): [] for lid in target_lines}
        for (lid, uid), g in state.sku_compat.items():
            if g == 1 and lid in compatible_by_line:
                ac = state.access.get(uid, AccessClass.INFEASIBLE)
                if ac != AccessClass.INFEASIBLE:
                    compatible_by_line[lid].append(uid)

        n_candidates = sum(len(v) for v in compatible_by_line.values())

        # Assign one job per idle robot at random
        for rid in eligible_robots:
            # Pick a target line at random (preferring critical)
            target_line = int(self.rng.choice(target_lines))
            tote_pool = compatible_by_line.get(target_line, [])
            if not tote_pool:
                continue
            uid = int(self.rng.choice(tote_pool))

            # Determine mode from access class
            ac = state.access.get(uid, AccessClass.INFEASIBLE)
            if ac == AccessClass.DIRECT:
                mode = ServiceMode.DIRECT
            elif ac == AccessClass.EXCAVATION:
                mode = ServiceMode.EXCAVATION
            else:
                continue

            job = Job(line_id=target_line, tote_id=uid, mode=mode)
            cm = Commitment(
                robot_id=rid,
                job=job,
                start_slot=0,             # Stage 1: no slot semantics
                epoch_time=state.epoch_time,
                slot_size=1.0,
            )
            commitments.append(cm)

            # Remove this tote from other lines' pools so we don't
            # double-assign in the same epoch.
            for pool in compatible_by_line.values():
                if uid in pool:
                    pool.remove(uid)

        return ControllerOutput(
            commitments=commitments,
            diagnostics={"num_candidates": n_candidates},
        )
