"""First-Come-First-Served (oldest-request) baseline — Section 5.2.

Serves production lines in the order their replenishment need *first
arose*, the canonical FCFS industrial discipline. ``SystemState`` does
not expose a per-line request timestamp, so this controller maintains its
own monotonic "first fell to/below safety stock" clock across decision
epochs: the epoch at which a line first became needy is its request time,
cleared once the line is comfortably above safety again. This is
self-contained and needs no simulator change.

Like the other heuristics it has no joint-feasibility / contention
foresight; it exists to isolate the value of urgency- and
optimization-based logic over a pure arrival-order rule.
"""

from __future__ import annotations

import numpy as np

from common.controller import Controller, ControllerOutput
from common.enums import AccessClass, ServiceMode
from common.state import SystemState
from common.types import Commitment, Job


class FIFOController(Controller):
    name = "FIFO"

    def __init__(self, slot_size: float = 5.0):
        self.slot_size = slot_size
        # line_id -> epoch_index when it first became needy (None = not needy)
        self._needy_since: dict[int, int] = {}

    def reset(self) -> None:
        self._needy_since.clear()

    def decide(self, state: SystemState) -> ControllerOutput:
        line_ids = [int(l) for l in state.line_ids]

        # --- update the FCFS arrival clock -------------------------------
        # A line is "needy" once its buffer is at/below safety stock; it
        # stops being needy (clock resets) once it recovers above safety.
        for i, lid in enumerate(line_ids):
            below = bool(state.B[i] <= state.S[i])
            if below and lid not in self._needy_since:
                self._needy_since[lid] = int(state.epoch_index)
            elif not below and lid in self._needy_since:
                del self._needy_since[lid]

        # Eligible robots (same eligibility contract as UrgencyRank)
        eligible = [
            int(rid) for k, rid in enumerate(state.robot_ids)
            if not bool(state.commitment_busy[k])
            and not bool(state.shield_locked[k])
        ]
        if not eligible or not self._needy_since:
            return ControllerOutput(
                commitments=[],
                diagnostics={"num_candidates": 0,
                             "num_eligible_robots": len(eligible)},
            )

        # Robot index lookup for position access
        rid_to_idx = {int(rid): k for k, rid in enumerate(state.robot_ids)}

        # Lines ordered by arrival time (oldest request first), tie-break
        # by line id for determinism.
        order = sorted(self._needy_since,
                       key=lambda l: (self._needy_since[l], l))

        # Pre-bucket compatible, retrievable totes per line.
        compat: dict[int, list[int]] = {l: [] for l in order}
        if state.sku_compat is not None:
            for (lid, uid), g in state.sku_compat.items():
                if g != 1 or int(lid) not in compat:
                    continue
                ac = state.access.get(int(uid), AccessClass.INFEASIBLE)
                if ac == AccessClass.INFEASIBLE:
                    continue
                compat[int(lid)].append(int(uid))
        n_cand = sum(len(v) for v in compat.values())

        commitments: list[Commitment] = []
        used_r: set[int] = set()
        used_u: set[int] = set()

        for lid in order:
            if len(used_r) == len(eligible):
                break
            pool = [u for u in compat[lid] if u not in used_u]
            if not pool:
                continue
            # Prefer DIRECT, then shallower stacks (cheaper service).
            pool.sort(key=lambda u: (
                0 if state.access[u] == AccessClass.DIRECT else 1,
                state.stack_depth.get(u, 99),
            ))
            best_r = best_u = None
            best_d = float("inf")
            for uid in pool:
                cell = state.tote_columns.get(uid)
                if cell is None:
                    continue
                tx, ty = cell
                for rid in eligible:
                    if rid in used_r:
                        continue
                    rx, ry = state.robot_pos[rid_to_idx[rid]]
                    d = abs(int(rx) - tx) + abs(int(ry) - ty)
                    if d < best_d:
                        best_d, best_r, best_u = d, rid, uid
            if best_r is None:
                continue
            mode = (ServiceMode.DIRECT
                    if state.access[best_u] == AccessClass.DIRECT
                    else ServiceMode.EXCAVATION)
            commitments.append(Commitment(
                robot_id=best_r,
                job=Job(line_id=lid, tote_id=best_u, mode=mode),
                start_slot=0,
                epoch_time=state.epoch_time,
                slot_size=self.slot_size,
            ))
            used_r.add(best_r)
            used_u.add(best_u)

        return ControllerOutput(
            commitments=commitments,
            diagnostics={
                "num_candidates": n_cand,
                "num_eligible_robots": len(eligible),
                "num_lines_served": len(commitments),
                "num_needy_lines": len(self._needy_since),
            },
        )