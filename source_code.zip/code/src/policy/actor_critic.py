"""Actor-critic network with masked Gaussian over the variable-size candidate set.

Implements eqs. (policy-action), (logprob) of Section 4.1.
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn

from common.config import PolicyConfig

from .encoders import GlobalEncoder, JobEncoder, PairwiseHead, RobotEncoder


_LOG_TWO_PI = math.log(2.0 * math.pi)


def _standard_normal_log_prob(eps: torch.Tensor) -> torch.Tensor:
    """log φ(eps) for ε ~ N(0, 1)."""
    return -0.5 * (eps ** 2 + _LOG_TWO_PI)


class ActorCritic(nn.Module):
    """Joint actor-critic with shared encoders."""

    def __init__(
        self,
        global_in_dim: int,
        robot_in_dim: int,
        job_in_dim: int,
        pair_in_dim: int,
        cfg: PolicyConfig,
    ):
        super().__init__()
        ec = cfg.encoders

        self.global_encoder = GlobalEncoder(global_in_dim, ec)
        self.robot_encoder = RobotEncoder(robot_in_dim, ec)
        self.job_encoder = JobEncoder(job_in_dim, ec)
        self.pair_head = PairwiseHead(
            global_dim=ec.global_dim,
            robot_dim=ec.robot_dim,
            job_dim=ec.job_dim,
            pair_feat_dim=pair_in_dim,
            cfg=ec,
        )

        # Critic: linear from h^G to scalar value
        self.value_head = nn.Linear(ec.global_dim, 1)

        # Actor noise (learnable per actor cfg)
        self.log_sigma = nn.Parameter(
            torch.tensor(float(cfg.actor.init_log_sigma)),
            requires_grad=cfg.actor.learn_sigma,
        )

    # ------------------------------------------------------------------ encoding

    def encode(
        self,
        global_in: torch.Tensor,
        robot_in: torch.Tensor,
        job_in: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        h_G = self.global_encoder(global_in)
        h_R = self.robot_encoder(robot_in)
        h_J = self.job_encoder(job_in)
        return h_G, h_R, h_J

    def actor_means(
        self,
        global_in: torch.Tensor,
        robot_in: torch.Tensor,
        job_in: torch.Tensor,
        pair_feats: torch.Tensor,
        pair_indices: torch.Tensor,
        pair_mask: torch.Tensor,
    ) -> torch.Tensor:
        h_G, h_R, h_J = self.encode(global_in, robot_in, job_in)
        return self.pair_head(h_G, h_R, h_J, pair_feats, pair_indices, pair_mask)

    def value(self, global_in: torch.Tensor) -> torch.Tensor:
        h_G = self.global_encoder(global_in)
        return self.value_head(h_G).squeeze(-1)

    # ------------------------------------------------------------------ sampling

    def sample(
        self,
        means: torch.Tensor,            # (B, |C_n|)
        pair_mask: torch.Tensor,        # (B, |C_n|)
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Sample ``w_{rj}`` and return ``(samples, mean_log_prob)``.

        ``mean_log_prob`` is the per-action scalar from eq. (logprob):
        the average per-pair log-probability over the feasible set.
        """
        sigma = self.log_sigma.exp()
        eps = torch.randn_like(means)
        samples = means + sigma * eps
        # zero out infeasible entries
        samples = samples * pair_mask.float()
        # log-prob per pair (only over feasible entries)
        log_prob_per_pair = _standard_normal_log_prob(eps) - self.log_sigma
        log_prob_per_pair = log_prob_per_pair * pair_mask.float()
        # mean over feasible pairs (per batch item)
        mask_count = pair_mask.float().sum(dim=-1).clamp(min=1.0)
        mean_log_prob = log_prob_per_pair.sum(dim=-1) / mask_count
        return samples, mean_log_prob

    def log_prob_of(
        self,
        means: torch.Tensor,
        samples: torch.Tensor,
        pair_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Recompute mean log-probability of an existing action under current ``mu``."""
        sigma = self.log_sigma.exp()
        # eps = (sample - mean) / sigma, but only for feasible pairs
        eps = (samples - means) / sigma
        eps = eps * pair_mask.float()
        log_prob_per_pair = _standard_normal_log_prob(eps) - self.log_sigma
        log_prob_per_pair = log_prob_per_pair * pair_mask.float()
        mask_count = pair_mask.float().sum(dim=-1).clamp(min=1.0)
        return log_prob_per_pair.sum(dim=-1) / mask_count
