"""SMDP-aware PPO update (eqs. ppo, td, gae, critic in Section 4.1).

Per-transition update for simplicity (variable-size actions otherwise need
padding). Numerically equivalent to a minibatch=1 PPO loop; the user can
batch later by padding pair_indices/pair_mask to the max ``|C_n|`` in the
batch and masking the loss accordingly.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import torch

from common.config import PPOConfig

from .rollout import RolloutBuffer, Transition

if TYPE_CHECKING:
    from .actor_critic import ActorCritic


def features_to_tensors(features: dict[str, np.ndarray], device: torch.device) -> dict:
    """Convert numpy state-features dict into batched (B=1) tensors."""
    return {
        "global": torch.as_tensor(features["global"], dtype=torch.float32, device=device).unsqueeze(0),
        "robot": torch.as_tensor(features["robot"], dtype=torch.float32, device=device).unsqueeze(0),
        "job": torch.as_tensor(features["job"], dtype=torch.float32, device=device).unsqueeze(0),
        "pair": torch.as_tensor(features["pair"], dtype=torch.float32, device=device).unsqueeze(0),
        "pair_indices": torch.as_tensor(features["pair_indices"], dtype=torch.long, device=device).unsqueeze(0),
        "pair_mask": torch.as_tensor(features["pair_mask"], dtype=torch.bool, device=device).unsqueeze(0),
    }


def ppo_update(
    actor_critic: "ActorCritic",
    optimizer: torch.optim.Optimizer,
    buffer: RolloutBuffer,
    cfg: PPOConfig,
    K_review: float,
    n_updates: int = 4,
    minibatch_iters: int = 1,
    device: torch.device = torch.device("cpu"),
) -> dict:
    """Run ``n_updates`` PPO epochs over the buffer.

    Returns a dict of mean losses for diagnostics.
    """
    if len(buffer) == 0:
        return {"actor_loss": 0.0, "critic_loss": 0.0, "entropy": 0.0, "n_transitions": 0}

    # Compute advantages once (using the current critic at update time)
    def value_fn(features: dict) -> float:
        with torch.no_grad():
            global_t = torch.as_tensor(features["global"], dtype=torch.float32, device=device).unsqueeze(0)
            v = actor_critic.value(global_t)
            return float(v.item())

    buffer.compute_advantages(
        critic_value_fn=value_fn,
        gamma=cfg.discount_gamma,
        zeta=cfg.gae_zeta,
        K=K_review,
    )

    # Normalize advantages (PPO standard trick)
    advs = np.asarray(buffer.advantages, dtype=np.float32)
    adv_mean = float(advs.mean()) if advs.size else 0.0
    adv_std = float(advs.std()) if advs.size else 1.0
    advs_norm = (advs - adv_mean) / max(adv_std, 1e-6)

    actor_losses = []
    critic_losses = []
    entropies = []

    for _ in range(n_updates):
        # Shuffle transitions
        order = np.random.permutation(len(buffer))
        for idx in order:
            t = buffer.transitions[idx]
            adv = float(advs_norm[idx])
            ret = float(buffer.returns[idx])

            tens = features_to_tensors(t.state, device)
            action = torch.as_tensor(t.action, dtype=torch.float32, device=device).unsqueeze(0)

            # Forward pass — current means
            means = actor_critic.actor_means(
                tens["global"], tens["robot"], tens["job"],
                tens["pair"], tens["pair_indices"], tens["pair_mask"],
            )
            log_prob_new = actor_critic.log_prob_of(
                means, action, tens["pair_mask"],
            ).squeeze(0)

            # PPO importance ratio
            ratio = (log_prob_new - t.log_prob_old).exp()
            unclipped = ratio * adv
            clipped = ratio.clamp(1 - cfg.clip_eps, 1 + cfg.clip_eps) * adv
            actor_loss = -torch.min(unclipped, clipped)

            # Critic loss (SMDP target = return = adv + V(s))
            value_pred = actor_critic.value(tens["global"]).squeeze(0)
            critic_loss = (value_pred - ret) ** 2

            # Entropy bonus (per-pair Gaussian entropy)
            sigma = actor_critic.log_sigma.exp()
            entropy = (0.5 + 0.5 * np.log(2 * np.pi) + actor_critic.log_sigma).item()

            loss = actor_loss + cfg.value_coef * critic_loss - cfg.entropy_coef * actor_critic.log_sigma

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(actor_critic.parameters(), cfg.max_grad_norm)
            optimizer.step()

            actor_losses.append(float(actor_loss.item()))
            critic_losses.append(float(critic_loss.item()))
            entropies.append(entropy)

    return {
        "actor_loss": float(np.mean(actor_losses)) if actor_losses else 0.0,
        "critic_loss": float(np.mean(critic_losses)) if critic_losses else 0.0,
        "entropy": float(np.mean(entropies)) if entropies else 0.0,
        "n_transitions": len(buffer),
        "adv_mean": adv_mean,
        "adv_std": adv_std,
    }
