"""Encoder networks and pairwise scoring head (eq. pairwise-score, Sec. 4.1).

The architecture follows the manuscript's variable-action-space design:

    h^G    = f^G(s_n)                       # global state
    h^R_r  = f^R(z^R_{r,n})                 # one per eligible robot
    h^J_j  = f^J(z^J_{j,n})                 # one per candidate job
    mu_rj  = f^pair(h^G, h^R_r, h^J_j, psi_{rj,n})

All encoders share weights across robots/jobs (no fixed cardinality).
Padding + masks are used only for batch packing during PPO updates.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from common.config import EncoderConfig
from common.enums import AccessClass, ServiceMode


# Feature dimensions used throughout this module.
# Keep these as module-level constants so the trainer and controller
# build features and networks consistently.
GLOBAL_FEAT_DIM = 8
ROBOT_FEAT_DIM = 6
JOB_FEAT_DIM = 8
PAIR_FEAT_DIM = 6


def _mlp(in_dim: int, hidden: int, out_dim: int) -> nn.Module:
    """Simple 2-layer MLP with tanh activation."""
    return nn.Sequential(
        nn.Linear(in_dim, hidden),
        nn.Tanh(),
        nn.Linear(hidden, out_dim),
        nn.Tanh(),
    )


# ---------------------------------------------------------------------------
# Encoder modules
# ---------------------------------------------------------------------------

class GlobalEncoder(nn.Module):
    """``f^G(s_n)`` — encodes the global state into ``h^G``."""

    def __init__(self, in_dim: int, cfg: EncoderConfig):
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = cfg.global_dim
        self.net = _mlp(in_dim, cfg.global_dim, cfg.global_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class RobotEncoder(nn.Module):
    """``f^R(z^R_r)`` — per-robot encoder applied independently across the fleet."""

    def __init__(self, in_dim: int, cfg: EncoderConfig):
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = cfg.robot_dim
        self.net = _mlp(in_dim, cfg.robot_dim, cfg.robot_dim)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        # z: (B, R_n, in_dim) → (B, R_n, robot_dim)
        return self.net(z)


class JobEncoder(nn.Module):
    """``f^J(z^J_j)`` — per-job encoder."""

    def __init__(self, in_dim: int, cfg: EncoderConfig):
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = cfg.job_dim
        self.net = _mlp(in_dim, cfg.job_dim, cfg.job_dim)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)


class PairwiseHead(nn.Module):
    """``f^pair(h^G, h^R_r, h^J_j, psi_{rj})`` — scalar mean ``mu_{rj}``."""

    def __init__(
        self,
        global_dim: int,
        robot_dim: int,
        job_dim: int,
        pair_feat_dim: int,
        cfg: EncoderConfig,
    ):
        super().__init__()
        in_dim = global_dim + robot_dim + job_dim + pair_feat_dim
        self.hidden_dim = cfg.pair_hidden_dim
        self.out_dim = cfg.pair_output_dim
        self.net = nn.Sequential(
            nn.Linear(in_dim, self.hidden_dim),
            nn.Tanh(),
            nn.Linear(self.hidden_dim, self.hidden_dim),
            nn.Tanh(),
            nn.Linear(self.hidden_dim, self.out_dim),
        )

    def forward(
        self,
        h_global: torch.Tensor,         # (B, G)
        h_robot: torch.Tensor,          # (B, R_n, R)
        h_job: torch.Tensor,            # (B, J_n, J)
        psi_pair: torch.Tensor,         # (B, |C_n|, P)
        pair_indices: torch.Tensor,     # (B, |C_n|, 2): (r_idx, j_idx)
        pair_mask: torch.Tensor,        # (B, |C_n|): bool, True iff feasible
    ) -> torch.Tensor:
        """Return mean scores ``mu_{rj}`` of shape ``(B, |C_n|)``."""
        B, C, _ = pair_indices.shape
        # Gather robot/job features per pair
        r_idx = pair_indices[..., 0]   # (B, C)
        j_idx = pair_indices[..., 1]   # (B, C)
        # gather along dim=1 of h_robot/h_job
        h_r_gathered = torch.gather(
            h_robot, 1, r_idx.unsqueeze(-1).expand(-1, -1, h_robot.shape[-1])
        )                              # (B, C, R)
        h_j_gathered = torch.gather(
            h_job, 1, j_idx.unsqueeze(-1).expand(-1, -1, h_job.shape[-1])
        )                              # (B, C, J)
        # broadcast global to per-pair
        h_g_broad = h_global.unsqueeze(1).expand(-1, C, -1)   # (B, C, G)

        x = torch.cat([h_g_broad, h_r_gathered, h_j_gathered, psi_pair], dim=-1)
        scores = self.net(x).squeeze(-1)   # (B, C)

        # Zero out infeasible pairs (the actor masks again at sampling time)
        scores = scores * pair_mask.float()
        return scores


# ---------------------------------------------------------------------------
# Feature builders (state → numpy arrays)
# ---------------------------------------------------------------------------

def build_global_features(state) -> np.ndarray:
    """Build the ``GLOBAL_FEAT_DIM``-vector summarizing the system state."""
    n_lines = len(state.line_ids)
    n_robots = len(state.robot_ids)

    B = state.B.astype(np.float32)
    S = state.S.astype(np.float32)
    T_so = state.hat_T_so.astype(np.float32)

    # Buffer fill ratio: how full are buffers on average (0..1)
    avg_fill = float(np.mean(B / np.maximum(S * 3, 1.0)))   # rough scaling
    # Min T_so (most urgent line)
    min_T_so = float(np.min(T_so) / 300.0)   # scale down to ~O(1)
    # Mean T_so
    mean_T_so = float(np.mean(T_so) / 300.0)
    # Frac of lines below safety stock
    frac_critical = float(np.mean(B <= S))
    # Fleet utilization (fraction of busy robots)
    busy = float(np.mean(state.commitment_busy.astype(np.float32)))
    # Fraction of robots low on battery
    low_batt = float(np.mean((state.battery < 0.3).astype(np.float32)))
    # Mean battery
    mean_batt = float(np.mean(state.battery))
    # Epoch index normalized
    norm_epoch = float(state.epoch_index / 1000.0)

    return np.array([
        avg_fill, min_T_so, mean_T_so, frac_critical,
        busy, low_batt, mean_batt, norm_epoch,
    ], dtype=np.float32)


def build_robot_features(
    state,
    robot_id: int,
    grid_width: int,
    grid_height: int,
) -> np.ndarray:
    """Per-robot ``ROBOT_FEAT_DIM``-vector."""
    pos = state.robot_pos[robot_id]
    norm_x = float(pos[0]) / max(grid_width, 1)
    norm_y = float(pos[1]) / max(grid_height, 1)
    battery = float(state.battery[robot_id])
    busy = 1.0 if state.commitment_busy[robot_id] else 0.0
    locked = 1.0 if state.shield_locked[robot_id] else 0.0
    # Time to availability (clipped)
    avail = max(0.0, float(state.tau_free[robot_id]) - float(state.epoch_time))
    norm_avail = min(avail / 300.0, 1.0)
    return np.array([norm_x, norm_y, battery, busy, locked, norm_avail], dtype=np.float32)


def build_job_features(
    state,
    job,            # Job(line_id, tote_id, mode)
) -> np.ndarray:
    """Per-job ``JOB_FEAT_DIM``-vector."""
    lid = job.line_id
    uid = job.tote_id
    T_so = float(state.hat_T_so[lid]) / 300.0
    B_l = float(state.B[lid]) / 12.0   # buffer level normalized to capacity
    S_l = float(state.S[lid]) / 12.0
    deficit = max(0.0, S_l - B_l)
    depth = float(state.stack_depth.get(uid, 0)) / 10.0
    support = float(state.support.get(uid, 0)) / 4.0
    mode_excav = 1.0 if job.mode == ServiceMode.EXCAVATION else 0.0
    lambda_l = float(state.hat_lambda[lid]) * 100.0   # rate scaled up
    return np.array(
        [T_so, B_l, S_l, deficit, depth, support, mode_excav, lambda_l],
        dtype=np.float32,
    )


def build_pair_features(
    state,
    rid: int,
    job,
    grid_width: int,
    grid_height: int,
) -> np.ndarray:
    """Per-pair ``PAIR_FEAT_DIM``-vector with travel surrogates and pair-specific signals."""
    rx, ry = state.robot_pos[rid]
    tote_cell = state.tote_columns.get(job.tote_id, (0, 0))
    line_pos = state.line_positions.get(job.line_id, (0, 0))
    # Manhattan distances
    d_rt = abs(int(rx) - tote_cell[0]) + abs(int(ry) - tote_cell[1])
    d_tl = abs(tote_cell[0] - line_pos[0]) + abs(tote_cell[1] - line_pos[1])
    d_total = d_rt + d_tl
    grid_diag = max(grid_width + grid_height, 1)
    # Normalize
    norm_d_rt = d_rt / grid_diag
    norm_d_tl = d_tl / grid_diag
    norm_d_total = d_total / grid_diag
    # Battery slack vs estimated mission energy proxy (distance × 0.001)
    batt_slack = float(state.battery[rid]) - d_total * 0.001
    # Expected lateness (very rough): travel_seconds vs T_so
    travel_seconds = d_total * 0.83   # 1m at 1.2 m/s
    expected_lateness = max(0.0, travel_seconds - float(state.hat_T_so[job.line_id])) / 300.0
    return np.array(
        [norm_d_rt, norm_d_tl, norm_d_total, batt_slack, expected_lateness, 1.0],
        dtype=np.float32,
    )
