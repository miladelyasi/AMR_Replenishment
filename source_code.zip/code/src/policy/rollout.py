"""On-policy rollout buffer for SMDP PPO.

Stores ``(s_n, a_n, log_pi_old, r_n, Theta_n, s_{n+1}, done)`` per transition,
where ``Theta_n`` is the variable holding time between epochs (Sec. 4.1).

Variable-size actions are stored as numpy arrays of length ``|C_n|`` along
with their pair masks. Batch updates happen per-transition for simplicity
(no padding needed).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class Transition:
    """A single SMDP transition produced by one decision epoch."""

    # State features (numpy arrays)
    state: dict[str, np.ndarray]
    # Action: (|C_n|,) sampled w_{rj}
    action: np.ndarray
    # Old log-prob (scalar)
    log_prob_old: float
    # Reward over [kappa_n, kappa_{n+1})
    reward: float
    # Holding time Theta_n in seconds
    holding_time: float
    # Bootstrap value of next state
    next_state: dict[str, np.ndarray]
    # Done flag (episode terminated this step)
    done: bool


class RolloutBuffer:
    """A simple FIFO buffer for on-policy rollouts."""

    def __init__(self):
        self.transitions: list[Transition] = []
        # Filled during ``compute_advantages``
        self.advantages: list[float] = []
        self.returns: list[float] = []

    def __len__(self) -> int:
        return len(self.transitions)

    def add(self, t: Transition) -> None:
        self.transitions.append(t)

    def clear(self) -> None:
        self.transitions.clear()
        self.advantages = []
        self.returns = []

    def compute_advantages(
        self,
        critic_value_fn,                # callable: state -> scalar
        gamma: float,
        zeta: float,                    # GAE smoothing parameter
        K: float,                       # nominal review period for SMDP discount
    ) -> None:
        """Compute SMDP-discounted advantages (eq. gae) and returns.

        ``A_n = delta_n + (gamma^{Theta_n/K} * zeta) * A_{n+1}``
        where ``delta_n = r_n + gamma^{Theta_n/K} * V(s_{n+1}) - V(s_n)``.
        """
        n = len(self.transitions)
        self.advantages = [0.0] * n
        self.returns = [0.0] * n
        next_advantage = 0.0
        next_value = 0.0   # If done, V(s_T) = 0.

        # Iterate in reverse
        for i in reversed(range(n)):
            t = self.transitions[i]
            value_n = float(critic_value_fn(t.state))
            if t.done:
                # Terminal: bootstrap V(s_{n+1}) = 0
                value_next = 0.0
                next_advantage = 0.0
            else:
                value_next = float(critic_value_fn(t.next_state))

            discount = gamma ** (t.holding_time / max(K, 1e-6))
            delta = t.reward + discount * value_next - value_n
            self.advantages[i] = delta + discount * zeta * next_advantage
            next_advantage = self.advantages[i]
            self.returns[i] = self.advantages[i] + value_n


# ---------------------------------------------------------------------------
# State serialization for buffer storage
# ---------------------------------------------------------------------------

def state_dict_to_features(features: dict[str, Any]) -> dict[str, np.ndarray]:
    """Pass-through; stored features are already numpy arrays.

    Provided as a hook for future serialization (e.g., to disk for
    distributed training).
    """
    return {k: np.asarray(v) for k, v in features.items()}
