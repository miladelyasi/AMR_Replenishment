"""The proposed neuro-symbolic controller, exposed via the ``Controller`` API.

Glues together:

* Feature builder      (``policy.encoders.build_*``)
* Actor-critic network (``ActorCritic``)
* Tactical MILP        (``TacticalMILP``)

At each decision epoch:

1. Build candidate set ``C_n``.
2. Encode the state and emit pairwise means ``mu_{rj}``.
3. Sample ``w_{rj}`` from the masked Gaussian (eq. policy-action).
4. Pass ``{w_{rj}}`` to the MILP, which produces tactical commitments.
5. Cache features + sampled action + log-prob for the rollout buffer.

The controller is evaluation-mode-aware: when ``self.training`` is
False, it uses ``mu_{rj}`` directly (no noise) for deterministic deployment.
"""

from __future__ import annotations

import numpy as np
import torch

from common.config import Config
from common.controller import Controller, ControllerOutput
from common.enums import ServiceMode
from common.state import SystemState
from common.types import Commitment, Job
from tactical.feasibility import build_feasible_set, build_job_set
from tactical.milp import TacticalMILP
from tactical.windows import lock_duration, pickup_duration
from world.eligibility import build_eligible_set

from .actor_critic import ActorCritic
from .encoders import (
    GLOBAL_FEAT_DIM, JOB_FEAT_DIM, PAIR_FEAT_DIM, ROBOT_FEAT_DIM,
    build_global_features, build_job_features, build_pair_features,
    build_robot_features,
)


class RLController(Controller):
    """The full strategic + tactical controller (proposed method)."""

    name = "NeuroSymbolic"

    def __init__(
        self,
        cfg: Config,
        actor_critic: ActorCritic,
        sim_handle,
        device: str = "cpu",
        training: bool = True,
        max_slots_per_pair: int = 1,
    ):
        self.cfg = cfg
        self.ac = actor_critic
        self.sim = sim_handle
        self.device = torch.device(device)
        self.training = training
        self.max_slots_per_pair = max_slots_per_pair

        # MILP solver (one per controller for warm-start state)
        H = cfg.controller.tactical_horizon_H_seconds
        D = cfg.controller.slot_size_delta_seconds
        self.num_slots = int(round(H / D))
        self.slot_size = D
        self.milp = TacticalMILP(cfg=cfg.milp, num_slots=self.num_slots, slot_size=D)

        # Static maps cached on first decide()
        self._cell_to_src_idx = None
        self._line_to_dst_idx = None
        self._capacities_src = None
        self._capacities_dst = None
        self._capacities_block = None
        self._battery_min_per_robot = None

        # Buffer hook — populated each decide() so trainer can log
        self.last_features: dict | None = None
        self.last_action: np.ndarray | None = None
        self.last_log_prob: float | None = None

    # ------------------------------------------------------------------ helpers

    def reset(self) -> None:
        self.last_features = None
        self.last_action = None
        self.last_log_prob = None

    def _ensure_static_maps(self) -> None:
        if self._cell_to_src_idx is not None:
            return
        cells = sorted(self.sim.storage.columns.keys())
        self._cell_to_src_idx = {c: i for i, c in enumerate(cells)}
        self._line_to_dst_idx = {l: l for l in range(self.cfg.world.num_lines)}
        n_src = len(cells)
        self._capacities_src = np.full(n_src, self.cfg.world.interfaces.src_capacity, np.int32)
        self._capacities_dst = np.full(self.cfg.world.num_lines,
                                       self.cfg.world.interfaces.dst_capacity, np.int32)
        self._capacities_block = np.full(n_src, self.cfg.world.interfaces.block_capacity, np.int32)
        self._battery_min_per_robot = {
            int(r.rid): self.cfg.world.robots.battery_min for r in self.sim.robots
        }

    def _build_tote_maps(self):
        cell_idx = self._cell_to_src_idx
        tote_to_src: dict[int, int] = {}
        tote_to_block: dict[int, list[int]] = {}
        for uid, cell in self.sim.storage._tote_column.items():
            idx = cell_idx[cell]
            tote_to_src[uid] = idx
            tote_to_block[uid] = [idx]
        return tote_to_src, tote_to_block

    def _make_helpers(self):
        sim = self.sim
        st = self.cfg.world.service_times
        em = sim.energy_model

        def travel_to_tote(rid, uid):
            cell = sim.storage.find_tote_column(uid)
            if cell is None:
                return float("inf")
            return sim.grid.travel_time(tuple(sim.robots[rid].pos), cell)

        def travel_to_line(uid, lid):
            cell = sim.storage.find_tote_column(uid)
            if cell is None:
                return float("inf")
            return sim.grid.travel_time(cell, sim.line_positions[lid])

        def pick_dur(d, s, m):
            return pickup_duration(
                d, s, m,
                base=st.pickup_base_seconds, per_depth=st.pickup_per_depth_seconds,
                excavation_overhead=st.pickup_excavation_overhead, epsilon_0=st.epsilon_0,
            )

        def lock_dur(d, s, m):
            return lock_duration(
                d, s, m,
                per_depth=st.lock_per_depth_seconds,
                excavation_overhead=st.lock_excavation_overhead,
                epsilon_0=st.epsilon_0,
            )

        def energy(rid, job, tau_rt, tau_tl, depth, mode):
            mode_excav = (mode == ServiceMode.EXCAVATION)
            travel_meters = (tau_rt + tau_tl) * sim.grid.nominal_speed_mps
            return (
                em.cost_for_distance(travel_meters)
                + em.cost_for_pickup(mode_excavation=mode_excav, depth=depth)
                + em.cost_for_drop()
            )

        return travel_to_tote, travel_to_line, pick_dur, lock_dur, energy

    # ------------------------------------------------------------------ feature builder

    def _build_features(
        self,
        state: SystemState,
        eligible: list[int],
        jobs: list[Job],
        feasible: list,
    ) -> dict:
        """Pack state + candidate set into the numpy-array dict the network expects."""
        gw, gh = self.cfg.world.grid.width, self.cfg.world.grid.height

        global_arr = build_global_features(state)

        # Per-robot features (only for eligible robots — defines indexing)
        robot_arr = np.stack(
            [build_robot_features(state, rid, gw, gh) for rid in eligible],
            axis=0,
        ) if eligible else np.zeros((0, ROBOT_FEAT_DIM), dtype=np.float32)
        rid_to_idx = {rid: i for i, rid in enumerate(eligible)}

        # Per-job features (only for jobs in J_n)
        job_arr = np.stack(
            [build_job_features(state, j) for j in jobs],
            axis=0,
        ) if jobs else np.zeros((0, JOB_FEAT_DIM), dtype=np.float32)
        job_key_to_idx = {j.key(): i for i, j in enumerate(jobs)}

        # Per-pair: each FeasibleTriple maps to one (r, j) pair
        # (A pair may appear at multiple slots; we use the slot=q_min one
        # for feature construction since features don't depend on q.)
        seen_pairs: dict[tuple[int, tuple], int] = {}
        pair_feats: list[np.ndarray] = []
        pair_indices: list[tuple[int, int]] = []
        triple_to_pair_idx: list[int] = []
        for tri in feasible:
            rid = int(tri.robot_id)
            jkey = tri.job.key()
            pair_key = (rid, jkey)
            if pair_key in seen_pairs:
                triple_to_pair_idx.append(seen_pairs[pair_key])
                continue
            r_idx = rid_to_idx.get(rid)
            j_idx = job_key_to_idx.get(jkey)
            if r_idx is None or j_idx is None:
                triple_to_pair_idx.append(-1)
                continue
            pf = build_pair_features(state, rid, tri.job, gw, gh)
            new_idx = len(pair_feats)
            seen_pairs[pair_key] = new_idx
            pair_feats.append(pf)
            pair_indices.append((r_idx, j_idx))
            triple_to_pair_idx.append(new_idx)

        if pair_feats:
            pair_arr = np.stack(pair_feats, axis=0)
            pair_idx_arr = np.array(pair_indices, dtype=np.int64)
            pair_mask = np.ones(len(pair_feats), dtype=bool)
        else:
            pair_arr = np.zeros((0, PAIR_FEAT_DIM), dtype=np.float32)
            pair_idx_arr = np.zeros((0, 2), dtype=np.int64)
            pair_mask = np.zeros((0,), dtype=bool)

        return {
            "global": global_arr,
            "robot": robot_arr,
            "job": job_arr,
            "pair": pair_arr,
            "pair_indices": pair_idx_arr,
            "pair_mask": pair_mask,
            # Side-channel for score-field assembly
            "_eligible": eligible,
            "_jobs": jobs,
            "_seen_pairs": seen_pairs,
            "_triple_to_pair_idx": triple_to_pair_idx,
        }

    # ------------------------------------------------------------------ public API

    def decide(self, state: SystemState) -> ControllerOutput:
        self._ensure_static_maps()

        # 1) Eligibility + candidates
        eligible = build_eligible_set(
            self.sim.robots, state,
            horizon_seconds=self.cfg.controller.tactical_horizon_H_seconds,
            battery_pre_filter_floor=self.cfg.world.robots.battery_pre_filter_floor,
            battery_min=self.cfg.world.robots.battery_min,
        )
        eligible = [r for r in eligible if not state.commitment_busy[r]]
        if not eligible:
            self.last_features = None
            return ControllerOutput([], {"num_candidates": 0, "milp_status": "no_eligible_robots"})

        jobs = build_job_set(state, self.cfg.controller.candidate_pruning)

        ttt, ttl, pdur, ldur, energy_fn = self._make_helpers()
        feasible = build_feasible_set(
            state, jobs, eligible,
            horizon_seconds=self.cfg.controller.tactical_horizon_H_seconds,
            slot_size=self.slot_size, num_slots=self.num_slots,
            battery_min_per_robot=self._battery_min_per_robot,
            travel_to_tote_fn=ttt, travel_to_line_fn=ttl,
            pickup_dur_fn=pdur, lock_dur_fn=ldur,
            energy_fn=energy_fn,
            drop_seconds=self.cfg.world.service_times.drop_seconds,
            max_slots_per_pair=self.max_slots_per_pair,
        )

        # 2) Encode features
        features = self._build_features(state, eligible, jobs, feasible)

        # 3) Forward pass; sample (or use mean if eval)
        with torch.set_grad_enabled(False):
            global_t = torch.as_tensor(features["global"]).float().unsqueeze(0).to(self.device)
            if features["robot"].shape[0] == 0 or features["job"].shape[0] == 0 or features["pair"].shape[0] == 0:
                # No feasible pair → no scores, defer to MILP without RL signal
                self.last_features = features
                self.last_action = np.zeros((0,), dtype=np.float32)
                self.last_log_prob = 0.0
                score_field = {}
            else:
                robot_t = torch.as_tensor(features["robot"]).float().unsqueeze(0).to(self.device)
                job_t = torch.as_tensor(features["job"]).float().unsqueeze(0).to(self.device)
                pair_t = torch.as_tensor(features["pair"]).float().unsqueeze(0).to(self.device)
                pair_idx_t = torch.as_tensor(features["pair_indices"]).long().unsqueeze(0).to(self.device)
                pair_mask_t = torch.as_tensor(features["pair_mask"]).bool().unsqueeze(0).to(self.device)

                means = self.ac.actor_means(global_t, robot_t, job_t, pair_t, pair_idx_t, pair_mask_t)
                if self.training:
                    samples, mean_log_prob = self.ac.sample(means, pair_mask_t)
                else:
                    samples = means
                    mean_log_prob = torch.zeros(1, device=self.device)
                samples_np = samples.squeeze(0).cpu().numpy()
                features["pair_indices_arr"] = features["pair_indices"]   # for trainer

                self.last_features = features
                self.last_action = samples_np
                self.last_log_prob = float(mean_log_prob.item())

                # 4) Convert pair scores into score_field {(rid, lid, uid): w}
                seen_pairs = features["_seen_pairs"]
                score_field = {}
                for (rid, jkey), pair_idx in seen_pairs.items():
                    lid, uid, _mode = jkey
                    score_field[(rid, lid, uid)] = float(samples_np[pair_idx])

        # 5) Solve MILP with the RL preference scores
        n_src = len(self._cell_to_src_idx)
        n_dst = self.cfg.world.num_lines
        carried_src = np.zeros((n_src, self.num_slots), np.int32)
        carried_dst = np.zeros((n_dst, self.num_slots), np.int32)
        carried_block = np.zeros((n_src, self.num_slots), np.int32)
        battery_remaining = {
            int(r.rid): max(0.0, float(r.battery) - self.cfg.world.robots.battery_min)
            for r in self.sim.robots
        }

        tote_to_src, tote_to_block = self._build_tote_maps()
        sol = self.milp.solve(
            state=state, feasible=feasible, jobs=jobs, score_field=score_field,
            carried_src=carried_src, carried_dst=carried_dst, carried_block=carried_block,
            battery_remaining=battery_remaining,
            capacities_src=self._capacities_src,
            capacities_dst=self._capacities_dst,
            capacities_block=self._capacities_block,
            tote_to_src_idx=tote_to_src, line_to_dst_idx=self._line_to_dst_idx,
            tote_to_block_indices=tote_to_block,
        )

        return ControllerOutput(
            commitments=sol.commitments,
            diagnostics={
                "num_candidates": len(feasible),
                "num_jobs": len(jobs),
                "num_eligible_robots": len(eligible),
                "milp_status": sol.status,
                "milp_solve_ms": sol.runtime_ms,
                "milp_objective": sol.objective,
                "log_prob_old": self.last_log_prob,
            },
        )
