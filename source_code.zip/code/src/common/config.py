"""Strongly-typed config dataclasses, loaded from YAML.

We parse YAML into these dataclasses (rather than raw dicts) so that all
parameter access is statically discoverable and IDEs can autocomplete.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# World / simulator
# ---------------------------------------------------------------------------

@dataclass
class GridConfig:
    width: int
    height: int
    cell_size_m: float = 1.0


@dataclass
class StorageConfig:
    max_stack_depth: int
    lock_radius: int = 1
    support_threshold: int = 1


@dataclass
class RobotsConfig:
    fleet_size: int
    nominal_speed_mps: float
    battery_capacity: float
    battery_min: float
    battery_pre_filter_floor: float
    energy_per_meter: float
    energy_per_pickup: float
    energy_per_drop: float
    energy_per_second_idle: float
    # Passive idle recharge rate (energy units per second).
    # Models on-board passive trickle charging or wireless floor charging,
    # which is standard for industrial AMR fleets running multi-hour shifts.
    # Set to 0 to disable.
    charge_per_second_idle: float = 0.0


@dataclass
class BuffersConfig:
    capacity: int
    safety_stock: int
    initial_level: int
    consumption_rate_baseline: float


@dataclass
class ServiceTimesConfig:
    pickup_base_seconds: float
    pickup_per_depth_seconds: float
    pickup_excavation_overhead: float
    drop_seconds: float
    lock_per_depth_seconds: float
    lock_excavation_overhead: float
    epsilon_0: float


@dataclass
class InterfacesConfig:
    src_capacity: int
    dst_capacity: int
    block_capacity: int


@dataclass
class WorldConfig:
    grid: GridConfig
    storage: StorageConfig
    robots: RobotsConfig
    buffers: BuffersConfig
    service_times: ServiceTimesConfig
    interfaces: InterfacesConfig
    num_lines: int


# ---------------------------------------------------------------------------
# Demand
# ---------------------------------------------------------------------------

@dataclass
class DemandConfig:
    type: str = "poisson"
    baseline_rate: float = 0.025
    filter_alpha: float = 0.05
    conservative_inflation: float = 0.20
    surge_multiplier: float = 1.0
    surge_duration_seconds: float = 0.0
    surge_start_window: tuple[float, float] = (0.0, 0.0)
    surge_lines_fraction: float = 0.0


# ---------------------------------------------------------------------------
# Controller / MILP / Reward / Policy
# ---------------------------------------------------------------------------

@dataclass
class CandidatePruningConfig:
    max_candidates_per_robot: int = 8
    max_candidates_per_line: int = 12
    max_total_candidates: int = 80
    max_jobs: int = 60


@dataclass
class ControllerConfig:
    review_period_K_seconds: float
    tactical_horizon_H_seconds: float
    slot_size_delta_seconds: float
    shield_repair_budget_slots: int
    urgency_T_crit_seconds: float
    candidate_pruning: CandidatePruningConfig = field(default_factory=CandidatePruningConfig)


@dataclass
class MILPWeights:
    alpha_M: float
    beta_M: float
    nu_M: float
    xi_M: float
    varrho: float
    P_0: float


@dataclass
class MILPSolverConfig:
    time_limit_ms: int = 150
    mip_gap: float = 0.02
    threads: int = 4
    presolve: int = 1
    output_flag: bool = False


@dataclass
class MILPConfig:
    weights: MILPWeights
    solver: MILPSolverConfig = field(default_factory=MILPSolverConfig)


@dataclass
class RewardWeights:
    alpha: float
    beta: float
    nu: float
    xi: float
    omega: float
    omega_rej: float
    delta_ot: float


@dataclass
class EncoderConfig:
    global_dim: int = 64
    robot_dim: int = 32
    job_dim: int = 32
    pair_hidden_dim: int = 64
    pair_output_dim: int = 1


@dataclass
class ActorConfig:
    init_log_sigma: float = -1.0
    learn_sigma: bool = True


@dataclass
class PPOConfig:
    discount_gamma: float = 0.995
    gae_zeta: float = 0.95
    clip_eps: float = 0.15
    entropy_coef: float = 0.001
    value_coef: float = 0.5
    learning_rate: float = 3.0e-4
    rollout_size: int = 2048
    minibatch_size: int = 256
    update_epochs: int = 8
    max_grad_norm: float = 0.5


@dataclass
class PolicyConfig:
    encoders: EncoderConfig = field(default_factory=EncoderConfig)
    actor: ActorConfig = field(default_factory=ActorConfig)
    ppo: PPOConfig = field(default_factory=PPOConfig)


@dataclass
class ShieldConfig:
    planner: str = "prioritized"
    max_wait_steps: int = 12
    reroute_search_depth: int = 30
    priority_rule: str = "urgency"


@dataclass
class LoggingConfig:
    results_dir: str = "results"
    metrics_every_n_epochs: int = 1
    save_animation: bool = False
    save_state_snapshots: bool = False
    log_level: str = "INFO"


@dataclass
class ExperimentConfig:
    name: str
    seed: int
    num_replications: int
    episode_horizon_seconds: float


# ---------------------------------------------------------------------------
# Top-level
# ---------------------------------------------------------------------------

@dataclass
class Config:
    """Top-level configuration container."""

    experiment: ExperimentConfig
    world: WorldConfig
    demand: DemandConfig
    controller: ControllerConfig
    milp: MILPConfig
    reward: RewardWeights
    policy: PolicyConfig
    shield: ShieldConfig
    logging: LoggingConfig
    ablation: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Config":
        """Load and parse a YAML config.

        Supports a simple ``defaults: [base]`` directive: each name in the
        list is resolved as a sibling YAML file (e.g. ``base`` ->
        ``base.yaml`` next to the current file or its parent), loaded first,
        then merged with the current file's content (current file wins).
        """
        merged = _load_with_defaults(Path(path))
        merged.pop("defaults", None)
        return _build_dataclass(cls, merged)


# ---------------------------------------------------------------------------
# YAML loading helpers
# ---------------------------------------------------------------------------

def _load_with_defaults(path: Path) -> dict:
    """Recursively merge ``defaults: [...]`` ancestors into the current YAML."""
    with open(path, "r") as f:
        data: dict = yaml.safe_load(f) or {}

    defaults = data.get("defaults", [])
    if not defaults:
        return data

    base_dir = path.parent
    merged: dict = {}
    for name in defaults:
        # search current dir, then parent (configs/ablations/* references base in configs/)
        for candidate in (base_dir / f"{name}.yaml", base_dir.parent / f"{name}.yaml"):
            if candidate.exists():
                merged = _deep_merge(merged, _load_with_defaults(candidate))
                break
        else:
            raise FileNotFoundError(
                f"Could not resolve defaults entry '{name}' from {path}"
            )

    merged = _deep_merge(merged, data)
    return merged


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursive dict merge; ``override`` wins on collision, except dict-into-dict."""
    out = dict(base)
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _build_dataclass(klass, data):
    """Recursively construct a dataclass tree from a nested dict."""
    import dataclasses as _dc

    if not _dc.is_dataclass(klass):
        return data

    field_kwargs: dict = {}
    by_name = {f.name: f for f in _dc.fields(klass)}
    for name, field in by_name.items():
        if name not in data:
            continue
        raw = data[name]
        ftype = field.type

        if isinstance(ftype, str):
            ftype = _resolve_type(ftype)

        if _dc.is_dataclass(ftype) and isinstance(raw, dict):
            field_kwargs[name] = _build_dataclass(ftype, raw)
        elif name == "surge_start_window" and isinstance(raw, list):
            field_kwargs[name] = tuple(raw)
        else:
            field_kwargs[name] = raw

    return klass(**field_kwargs)


def _resolve_type(name: str):
    """Resolve a forward-reference string to a dataclass defined in this module."""
    return globals().get(name, name)
