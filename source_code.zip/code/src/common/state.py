"""The semi-Markov state ``s_n`` defined in eq. (state) of Section 4.1.

This is the *complete* observation passed to:
* the policy network (which extracts feature views from it),
* the tactical MILP (which uses the resource & accessibility components),
* the metric collectors (which compute reward over the holding interval).

Construction is the responsibility of the simulator (``world/simulator.py``);
``SystemState`` itself is just a typed container.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .types import (
        AccessibilityMap,
        ReservationView,
        SKUCompatibilityMap,
    )


@dataclass
class SystemState:
    """Snapshot of the warehouse at semi-Markov decision epoch ``kappa_n``.

    The grouping mirrors the bracketed components of eq. (state):

    * Inventory:    ``B``, ``S``, ``hat_lambda``, ``hat_T_so``
    * Robots:       ``robot_pos``, ``tau_free``, ``battery``, ``commitment``
    * Reservations: ``reservations``
    * Accessibility: ``access``, ``stack_depth``, ``support``
    * Travel:       ``tau_xy_ru``, ``tau_xy_ul``
    * Congestion:   ``congestion_summary``
    """

    # ---- Time bookkeeping -----------------------------------------------
    epoch_index: int                          # n
    epoch_time: float                         # kappa_n in seconds

    # ---- Inventory (per line l in L) ------------------------------------
    line_ids: np.ndarray                      # (|L|,)
    B: np.ndarray                             # (|L|,) current buffer levels
    S: np.ndarray                             # (|L|,) safety thresholds
    hat_lambda: np.ndarray                    # (|L|,) filtered consumption rate
    hat_T_so: np.ndarray                      # (|L|,) projected time-to-stockout

    # ---- Robots (per r in R) --------------------------------------------
    robot_ids: np.ndarray                     # (|R|,)
    robot_pos: np.ndarray                     # (|R|, 2)  — current node
    tau_free: np.ndarray                      # (|R|,)    — earliest dispatch time
    battery: np.ndarray                       # (|R|,)
    commitment_busy: np.ndarray               # (|R|,) bool — True iff currently committed
    shield_locked: np.ndarray                 # (|R|,) bool — chi^r busy mask

    # ---- Reserved interfaces & blocks (carried over) --------------------
    reservations: "ReservationView"

    # ---- Accessibility (per tote u in U) --------------------------------
    access: "AccessibilityMap"                # u -> AccessClass
    stack_depth: dict[int, int] = field(default_factory=dict)   # d_{u,n}
    support: dict[int, int] = field(default_factory=dict)       # phi_{u,n}

    # ---- Travel surrogates (filled lazily / per-epoch) ------------------
    tau_xy_ru: dict[tuple[int, int], float] = field(default_factory=dict)
    tau_xy_ul: dict[tuple[int, int], float] = field(default_factory=dict)

    # ---- Congestion summary Xi_n ----------------------------------------
    congestion_summary: np.ndarray | None = None

    # ---- Static maps (held by ref; not copied per epoch) ----------------
    sku_compat: "SKUCompatibilityMap | None" = None

    # ---- Per-epoch geometry (cheap to populate) -------------------------
    tote_columns: dict[int, tuple[int, int]] = field(default_factory=dict)
    line_positions: dict[int, tuple[int, int]] = field(default_factory=dict)

    # ---------------------------------------------------------------------
    # Convenience accessors
    # ---------------------------------------------------------------------

    def num_lines(self) -> int:
        return len(self.line_ids)

    def num_robots(self) -> int:
        return len(self.robot_ids)

    def is_critical(self, line_id: int, T_crit: float) -> bool:
        """True if line `line_id` has hat_T_so <= T_crit."""
        idx = int(np.where(self.line_ids == line_id)[0][0])
        return bool(self.hat_T_so[idx] <= T_crit)
