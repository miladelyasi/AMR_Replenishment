"""Enumerations matching the symbolic vocabulary of the manuscript.

The three-way accessibility classification is central to the problem
definition (Sec. 3) and is referenced throughout the tactical MILP
(Sec. 4.2) and the simulator (Sec. 5.1).
"""

from __future__ import annotations

from enum import IntEnum


class AccessClass(IntEnum):
    """Operational accessibility class of a tote, denoted ``a_{u,n}`` in the paper.

    See the three-way distinction in Section 3.2 (Operational Dynamics).
    """

    INFEASIBLE = 0       # a_{u,n} = 0  — required excavation support unavailable
    DIRECT = 1           # a_{u,n} = 1  — directly retrievable (top of stack)
    EXCAVATION = 2       # a_{u,n} = 2  — buried but excavation-feasible


class ServiceMode(IntEnum):
    """Service mode m, derived from the tote's accessibility class.

    Encoded as ``m in {D, E}`` in the manuscript (eq. mode-set).
    """

    DIRECT = 0           # m = D
    EXCAVATION = 1       # m = E

    @classmethod
    def from_access(cls, access: AccessClass) -> "ServiceMode | None":
        """Mode is uniquely determined by the access class (eq. mode-set)."""
        if access == AccessClass.DIRECT:
            return cls.DIRECT
        if access == AccessClass.EXCAVATION:
            return cls.EXCAVATION
        return None


class EpochTrigger(IntEnum):
    """Reason a semi-Markov decision epoch was triggered.

    Used for diagnostics and to enforce the T^{crit} gating rule
    (Sec. 4.1, hybrid decision epochs).
    """

    NOMINAL_REVIEW = 0           # kappa_{n+1} = kappa_n + K
    ROBOT_NEWLY_DISPATCHABLE = 1
    LINE_BECAME_CRITICAL = 2
    RESERVATION_BOUNDARY = 3
    SHIELD_DEFERRAL_HIGH_URGENCY = 4   # only if T^so <= T^crit
