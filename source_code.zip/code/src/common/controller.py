"""Controller interface — every dispatching policy implements this contract.

The simulator is policy-agnostic: it calls ``controller.decide(state)`` at each
decision epoch and receives back a list of ``Commitment`` objects to enact.
This decouples Sec. 5.1 (simulator) from Sec. 5.2 (baselines) and Sec. 4
(proposed method).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Sequence

from .state import SystemState
from .types import Commitment, ScoreField


@dataclass
class ControllerOutput:
    """What a controller returns at each epoch.

    ``commitments`` is the tactical commitment set ``\\tilde a_n``;
    ``score_field`` is optional and only populated by RL controllers, for
    logging and rollout-buffer storage.
    """

    commitments: list[Commitment]
    score_field: ScoreField | None = None
    diagnostics: dict = field(default_factory=dict)


class Controller(ABC):
    """Abstract base for all dispatching policies."""

    name: str = "AbstractController"

    @abstractmethod
    def decide(self, state: SystemState) -> ControllerOutput:
        """Return tactical commitments for the current state."""
        raise NotImplementedError

    def reset(self) -> None:
        """Optional: reset internal state at episode start."""
        pass

    def on_shield_feedback(
        self,
        accepted: Sequence[Commitment],
        deferred: Sequence[Commitment],
        rejected: Sequence[Commitment],
    ) -> None:
        """Optional: notify controller about shield admission outcomes.

        Useful for RL controllers that include shield interventions in the
        reward (eq. reward, ``ShieldInt`` and ``Reject`` terms).
        """
        pass
