"""Core dataclasses shared between simulator, tactical layer, shield, and policy.

Conventions
-----------
* Continuous time in seconds (float). ``t = 0`` is the start of an episode.
* Grid coordinates are ``(x, y)`` integer tuples.
* IDs are integers; for readability, ``Tote.uid`` is the index into ``U``,
  ``Robot.rid`` into ``R``, ``Line.lid`` into ``L``.
* All structured data is immutable when possible (``frozen=True``).
  Mutable per-step state lives in dedicated classes (e.g. ``RobotState``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping

import numpy as np

from .enums import AccessClass, ServiceMode


# ---------------------------------------------------------------------------
# Static / semi-static identifiers
# ---------------------------------------------------------------------------

Coord = tuple[int, int]   # (x, y) on the floor grid
Cell = tuple[int, int]    # alias used for storage columns


@dataclass(frozen=True)
class Tote:
    """A single inventory tote ``u in U``.

    Attributes
    ----------
    uid     : int          — index into ``U``
    sku     : int          — SKU id; consumed via ``g_{l,u}`` compatibility map
    column  : Cell         — storage column ``(x, y)``
    depth   : int          — vertical position; 0 = top of stack
    """

    uid: int
    sku: int
    column: Cell
    depth: int


@dataclass(frozen=True)
class Job:
    """A candidate replenishment job ``j = (l, u, m)`` at a specific epoch.

    ``mode`` is determined by the current access class of the tote.
    """

    line_id: int
    tote_id: int
    mode: ServiceMode

    def key(self) -> tuple[int, int, int]:
        return (self.line_id, self.tote_id, int(self.mode))


@dataclass(frozen=True)
class Commitment:
    """A tactical commitment ``(r, j, q)`` produced by the MILP.

    ``start_slot`` is ``q in T = {0, ..., N-1}``; the absolute start time is
    ``epoch_time + q * delta``.
    """

    robot_id: int
    job: Job
    start_slot: int
    epoch_time: float       # the kappa_n at which the commitment was issued
    slot_size: float        # delta, in seconds (for re-deriving absolute times)

    @property
    def absolute_start_time(self) -> float:
        return self.epoch_time + self.start_slot * self.slot_size


@dataclass(frozen=True)
class TrajectoryStep:
    """A single time-stamped node visit on G = (V, E)."""

    time: float
    node: Coord


@dataclass
class Trajectory:
    """Time-parameterized trajectory ``rho_r : [kappa_n, kappa_n + H] -> V``.

    Mutable because the shield may extend / repair it.
    """

    robot_id: int
    steps: list[TrajectoryStep] = field(default_factory=list)

    def node_at(self, t: float) -> Coord | None:
        """Return the node occupied at time ``t`` (None if outside trajectory)."""
        if not self.steps:
            return None
        if t < self.steps[0].time:
            return None
        # piecewise-constant: hold last node until next step
        for prev, nxt in zip(self.steps, self.steps[1:]):
            if prev.time <= t < nxt.time:
                return prev.node
        return self.steps[-1].node


# ---------------------------------------------------------------------------
# Feature views
# ---------------------------------------------------------------------------
# These are NumPy/Tensor-friendly views passed into the policy network.
# They are constructed once per epoch by ``policy.encoders.build_features``.
# ---------------------------------------------------------------------------

@dataclass
class LineFeatures:
    """Per-line features, one row per ``l in L`` (eq. state).

    Columns: B_l, S_l, hat_lambda_l, hat_T^so_l.
    """

    line_ids: np.ndarray        # (|L|,)
    features: np.ndarray        # (|L|, 4)


@dataclass
class RobotFeatures:
    """Per-robot features, one row per eligible ``r in R_n`` (eq. state).

    Columns: x, y, tau_free, b, chi_busy_flag.
    """

    robot_ids: np.ndarray       # (|R_n|,)
    features: np.ndarray        # (|R_n|, 5)


@dataclass
class PairFeatures:
    """Per-pair features ``psi_{r,j,n}`` (eq. pairwise-score).

    Columns: hat_tau^xy_{r,u}, hat_tau^xy_{u,l}, expected_lateness,
             excavation_depth, congestion_exposure, mode_indicator,
             battery_slack.
    """

    pair_indices: np.ndarray    # (|C_n|, 2): rows of (robot_idx, job_idx)
    features: np.ndarray        # (|C_n|, k_pair)


@dataclass
class ScoreField:
    """The policy action ``a_n = {w_{r,j,n}}_{(r,j) in C_n}``.

    A flat vector aligned with ``PairFeatures.pair_indices``. Sampled from a
    masked Gaussian per eq. (policy-action). Carries its own log-probability
    (aggregated per eq. logprob) so PPO can compute the importance ratio.
    """

    pair_indices: np.ndarray    # (|C_n|, 2)
    means: np.ndarray           # (|C_n|,)  — mu_{rj,n}
    samples: np.ndarray         # (|C_n|,)  — w_{rj,n}
    log_prob: float             # aggregated mean log-prob (eq. logprob)
    sigma: float                # actor's current std (for diagnostics)


# ---------------------------------------------------------------------------
# Resource reservation views (from the previous tactical solve)
# ---------------------------------------------------------------------------

@dataclass
class ReservationView:
    """Already-reserved future occupancy carried into the next decision epoch.

    ``R^{src}``, ``R^{dst}``, ``R^B`` in the manuscript (Sec. 4.2). Each is
    a 2D array indexed by (interface_or_block_id, slot).
    """

    src: np.ndarray             # (|Z^src|, N)  — already-reserved slots
    dst: np.ndarray             # (|Z^dst|, N)
    block: np.ndarray           # (|B|, N)


# ---------------------------------------------------------------------------
# Bag of generic mappings used across modules
# ---------------------------------------------------------------------------

# tote.uid -> AccessClass
AccessibilityMap = Mapping[int, AccessClass]

# (line.lid, tote.uid) -> 0/1   (g_{l,u})
SKUCompatibilityMap = Mapping[tuple[int, int], int]
