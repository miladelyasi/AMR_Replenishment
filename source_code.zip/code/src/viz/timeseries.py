"""Buffer-level time-series plot — one line per production line ``l``.

Useful for visually verifying surge-response behavior: when a surge is
active for some lines, the corresponding curves should dip and recover
under a good controller, while the others should stay above safety stock.
"""

from __future__ import annotations

from pathlib import Path

from world.simulator import SimulatorResult


def plot_buffer_timeseries(
    result: SimulatorResult,
    output_path: str | Path,
    show_safety_stock: bool = True,
    show_surge_window: bool = True,
    figsize: tuple[float, float] = (10, 4),
) -> None:
    """One subplot per line, B_l(t) over the episode."""
    raise NotImplementedError
