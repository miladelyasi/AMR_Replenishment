"""Episode animation.

Renders a matplotlib animation of:

* AMR positions on the floor grid (one colored marker per robot)
* Active excavation footprints (semi-transparent overlay)
* Line-side buffers as small bar charts in the margin
* Optional surge-window indicator

Useful as a VESTEL deliverable and for paper supplementary material.
"""

from __future__ import annotations

from pathlib import Path

from world.simulator import SimulatorResult


def animate_episode(
    result: SimulatorResult,
    output_path: str | Path,
    fps: int = 10,
    figsize: tuple[float, float] = (10, 8),
    show_excavation_footprints: bool = True,
) -> None:
    """Render an MP4/GIF of the episode trace.

    Requires the simulator to have been run with
    ``cfg.logging.save_state_snapshots = True`` so that per-step robot
    positions and column states are recorded.
    """
    raise NotImplementedError
