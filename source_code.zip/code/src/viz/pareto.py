"""Energy–resilience Pareto plots for Section 5.5."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def plot_energy_resilience_pareto(
    df: pd.DataFrame,
    output_path: str | Path,
    methods: list[str],
    figsize: tuple[float, float] = (7, 5),
    show_dominated: bool = True,
) -> None:
    """Scatter ``(energy, stockout_minutes)`` per replication, with Pareto front per method.

    ``df`` should be the long-format result of ``metrics.reporters.build_paper_dataframe``.
    """
    raise NotImplementedError
