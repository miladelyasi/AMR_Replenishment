"""Heatmap plots: congestion and retrieval frequency by grid cell."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from world.simulator import SimulatorResult


def plot_congestion_heatmap(
    result: SimulatorResult,
    output_path: str | Path,
    grid_shape: tuple[int, int],
    figsize: tuple[float, float] = (8, 7),
) -> None:
    """Time-integrated edge / node occupancy as a 2D heatmap."""
    raise NotImplementedError


def plot_retrieval_frequency(
    result: SimulatorResult,
    output_path: str | Path,
    grid_shape: tuple[int, int],
    by_mode: bool = True,           # split DIRECT vs EXCAVATION
    figsize: tuple[float, float] = (8, 7),
) -> None:
    """Number of retrievals per column, optionally split by service mode."""
    raise NotImplementedError
