"""Run the focused execution checks without requiring pytest."""
import os,runpy
from pathlib import Path
root=Path(__file__).resolve().parents[1]
os.chdir(root)
namespace=runpy.run_path(str(root/'tests/test_schedule_runtime.py'))
for name in sorted(namespace):
    if name.startswith('test_'):
        namespace[name]()
        print('PASS',name,flush=True)
