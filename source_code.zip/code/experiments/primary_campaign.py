"""Finite, resumable matched-seed primary campaign; one solver thread/job."""
import concurrent.futures as cf
import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'primary_results';OUT.mkdir(exist_ok=True)
jobs=[]
def add(group,config,k,seeds,overrides=None,method='MILPOnly'):
 for seed in range(seeds):
  jobs.append(dict(id=f'{group}_k{k}_{method}_s{seed:02d}',group=group,config=config,k=str(k),seed=seed,overrides=overrides or {},method=method))
# Define screening, objective-weight and resource sensitivity cells.
for k in ['80','120','160','240','UNPRUNED']:
 add('base',f'configs/sweep/base__base__k{k}.yaml',k,30)
for name,override in [('alpha_half',{'milp.weights.alpha_M':5.}),('alpha_double',{'milp.weights.alpha_M':20.}),('beta_half',{'milp.weights.beta_M':.5}),('beta_double',{'milp.weights.beta_M':2.}),('penalty_double',{'milp.weights.P_0':20000.})]:
 add('weights_'+name,'configs/sweep/base__base__k80.yaml',80,15,override)
for cap in [2,3]:
 for k in [80,160,240]:
  add(f'interface_{cap}',f'configs/sweep/base__base__k{k}.yaml',k,15,{'world.interfaces.src_capacity':cap,'world.interfaces.dst_capacity':cap})
for name,override in [('charge_half',{'world.robots.charge_per_second_idle':.00075}),('charge_double',{'world.robots.charge_per_second_idle':.003}),('capacity_half',{'world.robots.battery_capacity':.5})]:
 for k in [80,160,240]:add(name,f'configs/sweep/base__base__k{k}.yaml',k,15,override)
for method in ['Random','Reactive','FIFO','NearestRobot','UrgencyRank','Reactive_Tight','Reactive_Loose','UrgencyRank_Tight','UrgencyRank_Loose']:
 add('baseline','configs/sweep/base__base__k80.yaml',80,15,method=method)
for factor,levels in [('fleet',['8','12','15']),('demand',['low','high']),('stackdepth',['shallow','deep']),('shield',['1','5']),('buffer',['low','high'])]:
 for level in levels:
  for k in [80,160,240]:
   # Set the low-demand cell to half the base consumption rate.
   o={'demand.baseline_rate':.0125,'world.buffers.consumption_rate_baseline':.0125} if factor=='demand' and level=='low' else {}
   add(f'{factor}_{level}',f'configs/sweep/{factor}__{level}__k{k}.yaml',k,15,o)
(OUT/'manifest.json').write_text(json.dumps(jobs,indent=2))
def one(j):
 target=OUT/(j['id']+'.json')
 if target.exists():
  d=json.loads(target.read_text())
  return j['id'],'cached',d['stockout_minutes'],d['wall_seconds']
 cmd=[sys.executable,str(ROOT/'experiments/run_episode.py'),'--config',j['config'],'--seed',str(j['seed']),'--out',str(target),'--overrides',json.dumps(j['overrides']),'--method',j['method']]
 with (OUT/(j['id']+'.log')).open('w') as f:
  r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
 if r.returncode:return j['id'],'ERROR',r.returncode,None
 d=json.loads(target.read_text());return j['id'],'done',d['stockout_minutes'],d['wall_seconds']
if __name__=='__main__':
 workers=int(sys.argv[1]) if len(sys.argv)>1 else 6
 print(f'Campaign: {len(jobs)} independent episodes; {workers} workers.',flush=True)
 with cf.ThreadPoolExecutor(max_workers=workers) as pool:
  for n,answer in enumerate(pool.map(one,jobs),1):print(n,len(jobs),answer,flush=True)
