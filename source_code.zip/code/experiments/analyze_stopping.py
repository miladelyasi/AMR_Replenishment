"""Audit and analyze the complete prespecified 90-episode stopping experiment."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import numpy as np
import pandas as pd
from analyze_results import interval, AUDITS

ORDER = ['80', '240', 'UNPRUNED']
POLICIES = ['reference', 'absolute']
NAME = {'80':'80', '240':'240', 'UNPRUNED':'Broad'}

def ci(row, scale=1.):
    return f"{row['mean']/scale:.2f} [{row['lo']/scale:.2f}, {row['hi']/scale:.2f}]"

def table(caption, label, columns, header, rows, resize=False):
    tex = [r'\begin{table}[H]\centering\small\color{blue}',
           r'\caption{\rev{'+caption+'}}', r'\label{'+label+'}']
    if resize: tex += [r'\begin{adjustbox}{max width=\linewidth}']
    tex += [r'\begin{tabular}{'+columns+'}', r'\toprule '+header+r'\\\midrule']
    tex += [row+r' \\' for row in rows]
    tex += [r'\bottomrule\end{tabular}']
    if resize: tex += [r'\end{adjustbox}']
    tex += [r'\end{table}']
    return '\n'.join(tex)+'\n'

def analyze(results, out):
    out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((results/'manifest.json').read_text())
    assert len(manifest['jobs']) == 90 and manifest['horizon_seconds'] == 28800
    rows, coverage_rows, allocations, snapshots = [], [], [], []
    gap_groups, timing_groups = defaultdict(list), defaultdict(list)
    for job in manifest['jobs']:
        policy, k, seed = job['policy'], job['k'], job['seed']
        stem = f'{policy}_k{k}_s{seed:02d}'
        row = json.loads((results/(stem+'.json')).read_text())
        assert (row['stopping_policy'], row['preset'], row['seed']) == (policy, k, seed)
        assert all(row[key] == 0 for key in AUDITS)
        assert row['realized_min_battery'] >= .1-1e-9
        assert row['delivered_total'] == row['accepted_units']+row['overflow_units'] == row['completed_audited_missions']
        assert not row['solver_status_counts'].get('INFEASIBLE', 0)
        assert all(l['balance_residual'] == 0 for l in row['line_totals'])
        common = dict(policy=policy, preset=k, seed=seed)
        row.update(common)
        row['admission_percent'] = 100*row['accepted']/max(1,row['proposed'])
        rows.append(row)
        line = pd.read_csv(results/(stem+'.lines.csv'))
        epochs = pd.read_csv(results/(stem+'.epochs.csv'))
        assert len(line) == 6*len(epochs) and epochs.time.max() == 28800
        assert line.proposed.sum() == row['proposed'] and line.accepted.sum() == row['accepted']
        critical = line.critical.astype(bool)
        available = critical & line.accessible.astype(bool)
        coverage_rows.append(dict(**common, line_epochs=len(line), critical=int(critical.sum()),
            unavailable=int((critical & ~line.accessible.astype(bool)).sum()),
            omitted=int((available & (line.screened_jobs == 0)).sum()),
            no_feasible=int((available & (line.feasible == 0)).sum()),
            critical_proposed=int(line.loc[critical, 'proposed'].sum()),
            critical_admitted=int(line.loc[critical, 'accepted'].sum()),
            full_buffer_proposed=int(line.loc[line.buffer >= 12, 'proposed'].sum()),
            all_proposed=int(line.proposed.sum()),
            with_incoming_proposed=int(line.loc[line.incoming > 0, 'proposed'].sum())))
        for l in row['line_totals']:
            part = line[line.line == l['line']]
            allocations.append(dict(**common, **l, proposed=int(part.proposed.sum()),
                admitted=int(part.accepted.sum()), critical=int(part.critical.sum())))
        gaps = pd.read_csv(results/(stem+'.gaps.csv'))
        assert len(gaps) == sum(row['solver_status_counts'].values())
        assert (gaps.solutions > 0).all() and (gaps.absolute_gap >= 0).all()
        assert np.allclose(gaps.absolute_gap, abs(gaps.objective-gaps.bound), atol=1e-5, rtol=0)
        gap_groups[(policy,k)].append(gaps)
        timing = pd.read_csv(results/(stem+'.timing.csv'))
        assert len(timing) == len(epochs)
        assert (timing[['controller_ms','review_ms']] >= 0).all().all()
        timing_groups[(policy,k)].append(timing)
        snaps = json.loads((results/(stem+'.snapshots.json')).read_text())
        assert len(snaps) == 8 and [s['target'] for s in snaps] == manifest['snapshot_times']
        assert all(s['greedy_checked_rows'] > 0 for s in snaps)
        snapshots.extend([dict(**common, **s) for s in snaps])
    df = pd.DataFrame(rows)
    df.to_csv(out/'stopping_episodes.csv', index=False)
    coverage = pd.DataFrame(coverage_rows)
    coverage.to_csv(out/'coverage_by_episode.csv', index=False)
    alloc = pd.DataFrame(allocations)
    alloc.to_csv(out/'line_allocation.csv', index=False)
    snap = pd.DataFrame(snapshots)
    snap.to_csv(out/'same_state_objectives.csv', index=False)
    metrics = ['stockout_minutes','total_travel_m','accepted_units','overflow_units','delivered_total',
               'proposed','accepted','admission_percent','review_mean_ms','review_p95_ms','review_max_ms',
               'controller_mean_ms','operational_wall_seconds','milp_mean_ms']
    means, contrasts, gapsummary, snapstats, covsummary = [], [], [], [], []
    for policy in POLICIES:
        for k in ORDER:
            part = df[(df.policy==policy)&(df.preset==k)].sort_values('seed')
            assert part.seed.tolist() == list(range(15))
            means.append(dict(policy=policy,preset=k,n=15,**{m:float(part[m].mean()) for m in metrics}))
            gaps = pd.concat(gap_groups[(policy,k)], ignore_index=True)
            timing = pd.concat(timing_groups[(policy,k)], ignore_index=True)
            gapsummary.append(dict(policy=policy,preset=k,calls=len(gaps),
                mean_relative_gap=float(gaps.relative_gap.mean()),max_relative_gap=float(gaps.relative_gap.max()),
                mean_absolute_gap=float(gaps.absolute_gap.mean()),max_absolute_gap=float(gaps.absolute_gap.max()),
                gaps_above_absolute_tolerance=int((gaps.absolute_gap > 1e-6).sum()),
                time_limits=int((gaps.status==9).sum()),mean_solver_ms=float(gaps.solver_ms.mean()),
                max_solver_ms=float(gaps.solver_ms.max()),p95_solver_ms=float(gaps.solver_ms.quantile(.95)),
                mean_review_ms=float(timing.review_ms.mean()),p95_review_ms=float(timing.review_ms.quantile(.95)),
                max_review_ms=float(timing.review_ms.max())))
            sample = snap[(snap.policy==policy)&(snap.preset==k)]
            advantage = sample.milp_advantage
            snapstats.append(dict(policy=policy,preset=k,snapshots=len(sample),
                better=int((advantage>1e-6).sum()),worse=int((advantage < -1e-6).sum()),
                tied=int((abs(advantage)<=1e-6).sum()),mean_advantage=float(advantage.mean()),
                median_advantage=float(advantage.median()),max_advantage=float(advantage.max()),min_advantage=float(advantage.min()),
                mean_milp_ms=float(sample.milp_ms.mean()),mean_greedy_ms=float(sample.greedy_ms.mean()),
                checked_rows=int(sample.greedy_checked_rows.sum())))
            cov = coverage[(coverage.policy==policy)&(coverage.preset==k)]
            totals = {m:int(cov[m].sum()) for m in cov.columns if m not in ['policy','preset','seed']}
            covsummary.append(dict(policy=policy,preset=k,**totals))
    def contrast(policy_a,k_a,policy_b,k_b,name):
        a=df[(df.policy==policy_a)&(df.preset==k_a)].sort_values('seed')
        b=df[(df.policy==policy_b)&(df.preset==k_b)].sort_values('seed')
        for metric in ['stockout_minutes','total_travel_m','overflow_units','review_mean_ms']:
            contrasts.append(dict(contrast=name,measure=metric,
                **interval(a[metric].to_numpy()-b[metric].to_numpy(),'stopping_'+name+'_'+metric)))
    for k in ORDER:contrast('absolute',k,'reference',k,'absolute_minus_reference_'+k)
    for p in POLICIES:
        contrast(p,'240',p,'80',p+'_240_minus_80')
        contrast(p,'UNPRUNED',p,'240',p+'_Broad_minus_240')
    for name, records in [('stopping_means',means),('stopping_contrasts',contrasts),('gap_summary',gapsummary),
                          ('snapshot_summary',snapstats),('coverage_summary',covsummary)]:
        pd.DataFrame(records).to_csv(out/(name+'.csv'),index=False)
    lines = [f"{NAME[r['preset']]} & {r['policy'].title()} & {r['stockout_minutes']:.3f} & {r['total_travel_m']/1000:.2f} & {r['overflow_units']:.1f} & {r['review_mean_ms']:.2f}" for r in means]
    tex = table('Full-episode stopping-policy comparison: 15 matched seeds per cell, reference objective weights throughout. Reference uses a 2\\% relative gap and 150-ms limit; Absolute uses zero relative gap, absolute tolerance $10^{-6}$, and a 5-s limit. Review time includes state construction, screening, assignment, and admission, excluding diagnostic shadow work. Appendix~\\ref{sec:app_stopping} explains the separate Reference replay means and the four primary episodes with time-limit differences.',
        'tab:stopping_episodes','llrrrr','Preset & Stopping & Stockout (min) & Travel (km) & Overflow & Review (ms)',lines,True)
    (out/'stopping_table.tex').write_text(tex)
    lines=[]
    for r in contrasts:
        if r['measure'] != 'stockout_minutes':continue
        label=r['contrast'].replace('absolute_minus_reference_','Absolute minus Reference, ').replace('UNPRUNED','Broad').replace('_240_minus_80',': 240 minus 80').replace('_Broad_minus_240',': Broad minus 240')
        label=label[0].upper()+label[1:]
        lines.append(label+' & '+ci(r))
    (out/'stopping_contrasts.tex').write_text(table('Paired stockout contrasts for the full-episode stopping experiment; pointwise 95\\% bootstrap intervals from 15 matched seeds.','tab:stopping_contrasts','lr','Comparison & Difference (min) [95\\% CI]',lines))
    lines=[]
    for r in gapsummary:
        lines.append(f"{NAME[r['preset']]} & {r['policy'].title()} & {r['calls']:,} & {100*r['mean_relative_gap']:.3f} & {r['max_absolute_gap']:.2e} & {r['time_limits']} & {r['mean_review_ms']:.2f} / {r['p95_review_ms']:.2f} / {r['max_review_ms']:.1f}")
    (out/'stopping_gaps.tex').write_text(table('Achieved stopping accuracy and pooled per-review latency. Absolute gaps use objective-cost units; relative gaps use the retained-constant objective. Latency is mean / 95th percentile / maximum in milliseconds across all reviews. Solver-call gaps exclude empty reviews; latency includes them.','tab:stopping_gaps','llrrrrl','Preset & Stopping & Calls & Mean gap (\\%) & Max. abs. gap & Limits & Review latency (ms)',lines,True))
    lines=[]
    for r in covsummary:
        rate=100*r['full_buffer_proposed']/max(1,r['all_proposed'])
        lines.append(f"{NAME[r['preset']]} & {r['policy'].title()} & {r['critical']:,} & {r['unavailable']:,} & {r['omitted']:,} & {r['critical_proposed']:,} / {r['critical_admitted']:,} & {rate:.1f}")
    (out/'stopping_coverage.tex').write_text(table(r'Pooled line-level diagnostics over 15 episodes, with criticality, unavailability, and omission defined in Appendix~\ref{sec:app_stopping}. Proposal/admission columns count missions for critical lines. Full-buffer proposals are a percentage of all proposals at the current review, not predicted arrival overflow.','tab:stopping_coverage','llrrrrr','Preset & Stopping & Critical epochs & Unavailable & Omitted & Critical prop./adm. & Full buffer (\\%)',lines,True))
    lines=[]
    for lid in range(6):
        values=[]
        for p in POLICIES:
            a=alloc[(alloc.policy==p)&(alloc.preset=='UNPRUNED')&(alloc.line==lid)]
            values.extend([f'{a.proposed.mean():.1f}',f'{a.accepted_units.mean():.1f}',f'{a.overflow_units.mean():.1f}'])
        lines.append(str(lid+1)+' & '+' & '.join(values))
    (out/'stopping_allocation.tex').write_text(table('Broad delivery allocation by line, averaged over 15 seeds. Columns give proposed missions, buffer-accepted units, and overflow units for each stopping policy; admitted missions can remain active at the horizon.','tab:stopping_allocation','rrrrrrr','Line & Ref. prop. & Ref. accepted & Ref. overflow & Abs. prop. & Abs. accepted & Abs. overflow',lines,True))
    lines=[]
    for r in snapstats:
        lines.append(f"{NAME[r['preset']]} & {r['policy'].title()} & {r['better']} / {r['tied']} / {r['worse']} & {r['mean_advantage']:.2f} & [{0 if abs(r['min_advantage'])<1e-6 else r['min_advantage']:.2f}, {r['max_advantage']:.2f}] & {r['mean_milp_ms']:.2f} / {r['mean_greedy_ms']:.2f}")
    (out/'stopping_objectives.tex').write_text(table('Same-state BatchGreedy comparison: 120 snapshots per cell. Positive advantage favors the MILP in objective-cost units; ties use tolerance $10^{-6}$. Times cover assignment construction from precomputed alternatives, excluding shadow validation, not full-controller latency.','tab:stopping_objectives','llrrrr','Preset & Stopping & Better / tied / worse & Mean advantage & Range & MILP / greedy (ms)',lines,True))
    summary=dict(episodes=90,snapshots=len(snapshots),audited_completed_missions=int(df.completed_audited_missions.sum()),
        audit_totals={key:int(df[key].sum()) for key in AUDITS},minimum_battery=float(df.realized_min_battery.min()),
        absolute_policy_all_gaps_within_tolerance=all(r['gaps_above_absolute_tolerance']==0 for r in gapsummary if r['policy']=='absolute'),
        absolute_policy_time_limits=sum(r['time_limits'] for r in gapsummary if r['policy']=='absolute'),
        material_balance_residuals=sorted({l['balance_residual'] for r in rows for l in r['line_totals']}))
    (out/'stopping_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    analyze(args.results,args.out)
