"""Section 5.5 — Energy–Resilience Trade-offs.

Sweeps the ratio (alpha, nu) — that is, weights on stockout vs. energy —
over a grid, for the proposed method and the strongest baselines. Emits
a Pareto plot.

Usage
-----
    python experiments/run_tradeoff.py --config configs/base.yaml \\
        --alpha-grid 1,5,10,20,50 --nu-grid 0.1,0.3,0.5,1.0
"""

from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("configs/base.yaml"))
    parser.add_argument("--alpha-grid", type=str, default="1,5,10,20,50")
    parser.add_argument("--nu-grid", type=str, default="0.1,0.3,0.5,1.0")
    parser.add_argument("--seeds", type=int, default=10,
                        help="Per cell of the (alpha, nu) grid")
    parser.add_argument("--out_dir", type=Path, default=Path("results/tradeoff"))
    args = parser.parse_args()
    raise NotImplementedError("Implement after run_overall.py is working.")


if __name__ == "__main__":
    main()
