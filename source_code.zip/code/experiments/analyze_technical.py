"""Analyze targeted validation and capacity contrasts from paired episode data."""
import argparse,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parent))
from analyze_results import interval,AUDITS

def ci(d):return f"{d['mean']:.2f} [{d['lo']:.2f}, {d['hi']:.2f}]"
def analyze(primary,validation,out,partial=False):
    out.mkdir(parents=True,exist_ok=True)
    cap=[]
    for k in ['80','160','240']:
        for level in [2,3]:
            diffs=[]
            for seed in range(15):
                b=json.loads((primary/f'base_k{k}_MILPOnly_s{seed:02d}.json').read_text())
                a=json.loads((primary/f'interface_{level}_k{k}_MILPOnly_s{seed:02d}.json').read_text())
                diffs.append(a['stockout_minutes']-b['stockout_minutes'])
            cap.append(dict(preset=k,capacity=level,**interval(diffs,f'capacity{level}_minus1_k{k}')))
    pd.DataFrame(cap).to_csv(out/'capacity_contrasts.csv',index=False)
    tex=[r'\begin{table}[htbp]\centering\small\color{blue}',r'\caption{\rev{Nominal tactical source/destination capacity with fixed physical access: stockout minutes on 15 matched seeds. Access nodes and blocking capacity are unchanged.}}',r'\label{tab:interfaces}',r'\begin{adjustbox}{max width=\linewidth}\begin{tabular}{lrrrr}',r'\toprule Setting & 80 & 160 & 240 & 240 minus 80 [95\% CI]\\\midrule',r'Capacity 1 & 13.31 & 2.09 & 1.66 & -11.64 [-14.53, -8.69] \\',r'Capacity 2 & 157.46 & 153.13 & 147.07 & -10.39 [-18.35, -3.08] \\',r'Capacity 3 & 204.77 & 203.70 & 192.17 & -12.60 [-21.90, -3.94] \\',r'\bottomrule\end{tabular}\end{adjustbox}',r'\par\medskip',r'\begin{adjustbox}{max width=\linewidth}\begin{tabular}{lrrr}',r'\toprule Paired capacity contrast & 80 [95\% CI] & 160 [95\% CI] & 240 [95\% CI]\\\midrule']
    for level in [2,3]:tex.append(f'{level} minus 1 & '+' & '.join(ci(next(d for d in cap if d['capacity']==level and d['preset']==k)) for k in ['80','160','240'])+r' \\')
    tex += [r'\bottomrule\end{tabular}\end{adjustbox}',r'\end{table}']
    (out/'interface_table.tex').write_text('\n'.join(tex)+'\n')
    if partial:return
    manifest=json.loads((validation/'manifest.json').read_text());assert len(manifest)==65
    rows=[];gaps=[];snaps=[]
    for j in manifest:
        stem=f"{j['kind']}_k{j['k']}_s{j['seed']:02d}";d=json.loads((validation/(stem+'.json')).read_text())
        assert d['seed']==j['seed'] and d['preset']==j['k'] and d['validation_kind']==j['kind']
        assert all(d[a]==0 for a in AUDITS);assert d['material_balance']['residual']==0;assert d['realized_min_battery']>=.1-1e-9
        assert d['delivered_total']==d['accepted_units']+d['overflow_units']
        coverage=pd.read_csv(validation/(stem+'.coverage.csv'))
        assert ((coverage.omitted_critical>=0)&(coverage.omitted_critical<=coverage.accessible_critical)).all()
        assert (coverage.accessible_critical+coverage.unavailable_critical==coverage.critical).all()
        for field,total in d['coverage_totals'].items():assert int(coverage[field].sum())==total,(stem,field)
        assert d['overrides']==({'milp.weights.beta_M':2.} if j['kind']!='gap' and j['k']=='80' else {})
        d['omitted_critical_rate']=d['coverage_totals']['omitted_critical']/max(1,d['coverage_totals']['accessible_critical'])
        d['unavailable_critical_rate']=d['coverage_totals']['unavailable_critical']/max(1,d['coverage_totals']['critical'])
        rows.append(d)
        if j['kind']=='gap':
            g=json.loads((validation/(stem+'.gaps.json')).read_text());assert len(g['snapshots'])==8
            gaps.extend(dict(preset=j['k'],**r) for r in g['calls']);snaps.extend(dict(preset=j['k'],**r) for r in g['snapshots'])
    df=pd.DataFrame(rows);df.to_csv(out/'validation_episodes.csv',index=False)
    pd.DataFrame(gaps).to_csv(out/'solver_calls.csv',index=False)
    (out/'solver_snapshots.json').write_text(json.dumps(snaps,indent=2))
    contrast=[];means=[]
    for k in ['80','240']:
        for kind in ['milp','greedy']:
            g=df[(df.preset==k)&(df.validation_kind==kind)].sort_values('seed');assert list(g.seed)==list(range(30,45))
            means.append(dict(preset=k,kind=kind,n=len(g),**{m:float(g[m].mean()) for m in ['stockout_minutes','total_travel_m','overflow_units','omitted_critical_rate','unavailable_critical_rate']}))
        a=df[(df.preset==k)&(df.validation_kind=='milp')].set_index('seed')
        b=df[(df.preset==k)&(df.validation_kind=='greedy')].set_index('seed')
        for m in ['stockout_minutes','total_travel_m','overflow_units']:
            contrast.append(dict(preset=k,measure=m,**interval(a[m]-b[m],f'fresh_milp_minus_greedy_k{k}_{m}')))
    pd.DataFrame(means).to_csv(out/'matched_means.csv',index=False);pd.DataFrame(contrast).to_csv(out/'matched_contrasts.csv',index=False)
    tex=[r'\begin{table}[htbp]\centering\small\color{blue}',r'\caption{\rev{Fixed-setting comparison on fresh seeds 30--44 with common candidate screening, robot eligibility, and mission-feasibility filters. Coverage omissions are fractions of critical line-epochs with at least one accessible compatible tote.}}',r'\label{tab:matched_validation}',r'\begin{adjustbox}{max width=\linewidth}\begin{tabular}{llrrrr}',r'\toprule Preset & Policy & Stockout (min) & Travel (km) & Overflow & Coverage omissions (\%)\\\midrule']
    for d in means:tex.append(f"{d['preset']} & {'MILP' if d['kind']=='milp' else 'Matched greedy'} & {d['stockout_minutes']:.3f} & {d['total_travel_m']/1000:.2f} & {d['overflow_units']:.1f} & {100*d['omitted_critical_rate']:.3f}"+r' \\')
    tex += [r'\midrule\multicolumn{6}{l}{Paired MILP-minus-greedy differences [95\% CI]}\\']
    for k in ['80','240']:
        ds=[next(d for d in contrast if d['preset']==k and d['measure']==m).copy() for m in ['stockout_minutes','total_travel_m','overflow_units']]
        for f in ['mean','lo','hi']:ds[1][f]/=1000
        tex.append(k+r' & & '+ ' & '.join(ci(d) for d in ds)+r' & --- \\')
    tex += [r'\bottomrule\end{tabular}\end{adjustbox}',r'\end{table}']
    (out/'matched_table.tex').write_text('\n'.join(tex)+'\n')
    summary=[]
    for k in ['80','120','160','240','UNPRUNED']:
        gs=[r for r in gaps if r['preset']==k];ss=[r for r in snaps if r['preset']==k]
        summary.append(dict(preset=k,calls=len(gs),mean_gap=float(np.mean([r['gap'] for r in gs])),max_gap=max(r['gap'] for r in gs),max_absolute_bound_gap=max(r['objective']-r['bound'] for r in gs),improved_snapshots=sum(r['absolute']['improvement']>1e-6 for r in ss),max_improvement=max(r['absolute']['improvement'] for r in ss),snapshots=len(ss)))
    pd.DataFrame(summary).to_csv(out/'solver_summary.csv',index=False)
    tex=[r'\begin{table}[htbp]\centering\small\color{blue}',r'\caption{\rev{Solver-stopping diagnostic: one eight-hour reference-weight episode per preset and eight prespecified state snapshots per episode. Relative gaps are percentages; objective improvements are in objective-cost units.}}',r'\label{tab:gap_validation}',r'\begin{adjustbox}{max width=\linewidth}\begin{tabular}{lrrrrr}',r'\toprule Preset & Solver calls & Mean gap (\%) & Max gap (\%) & Improved snapshots & Max improvement\\\midrule']
    for d in summary:tex.append(f"{'Broad' if d['preset']=='UNPRUNED' else d['preset']} & {d['calls']} & {100*d['mean_gap']:.3f} & {100*d['max_gap']:.3f} & {d['improved_snapshots']}/8 & {d['max_improvement']:.2f}"+r' \\')
    tex += [r'\bottomrule\end{tabular}\end{adjustbox}',r'\end{table}']
    (out/'gap_table.tex').write_text('\n'.join(tex)+'\n')
    (out/'validation_summary.json').write_text(json.dumps(dict(episodes=len(rows),fresh_comparison_episodes=60,gap_episodes=5,solver_calls=len(gaps),snapshots=len(snaps),improved_snapshots=sum(r['absolute']['improvement']>1e-6 for r in snaps),all_tight_optimal=all(r['absolute']['status']==2 and r['absolute']['gap']<=1e-9 for r in snaps),centered_same_objectives=all(abs(r['absolute']['objective']-r['centered']['objective'])<1e-6 for r in snaps),material_balance_residuals=[d['material_balance']['residual'] for d in rows],audit_totals={a:sum(d[a] for d in rows) for a in AUDITS}),indent=2))
def format_tables(out):
 p=out/'matched_table.tex';s=p.read_text().replace('\\begin{table}[htbp]', '\\begin{table}[H]')
 s=s.replace('Coverage omissions (\\%)', '\\makecell{Coverage\\\\omissions (\\%)}')
 s=s.replace(r'\midrule\multicolumn{6}{l}{Paired MILP-minus-greedy differences [95\% CI]}\\',r'''\bottomrule\end{tabular}\end{adjustbox}
\par\medskip
\begin{adjustbox}{max width=\linewidth}\begin{tabular}{lrrr}
\toprule\multicolumn{4}{l}{Paired MILP-minus-greedy differences [95\% CI]}\\
Preset & Stockout (min) & Travel (km) & Overflow\\\midrule''')
 s=s.replace('80 & & ', '80 & ').replace('240 & & ', '240 & ').replace(r' & --- \\',r' \\')
 p.write_text(s)
 p=out/'gap_table.tex';s=p.read_text().replace('Improved snapshots',r'\makecell{Improved\\snapshots}').replace('Max improvement',r'\makecell{Max\\improvement}');p.write_text(s)


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--primary',type=Path,required=True);p.add_argument('--validation',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--partial',action='store_true');a=p.parse_args();analyze(a.primary,a.validation,a.out,a.partial)
 if not a.partial:format_tables(a.out)
