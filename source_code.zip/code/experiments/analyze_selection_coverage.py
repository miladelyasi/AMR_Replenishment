"""Regenerate the seed-4 auxiliary selection-coverage diagnostic."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from pruner.pruner import EpochDataset, FeatureIndex, PrunerNetwork


def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
    return value.hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((args.data/'manifest.json').read_text())
    assert manifest['seed']==4 and manifest['random_seed']==0
    for name,sha in manifest['files_sha256'].items():
        assert digest(args.data/name)==sha,('Input checksum',name)
    paths=sorted(args.data.glob('seed4_*.jsonl'))
    assert paths
    original=hashlib.sha256()
    for path in paths:
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):original.update(block)
    assert original.hexdigest()==manifest['source_sha256']
    index=FeatureIndex.load(str(args.data/'feature_index.json'))
    checkpoint=torch.load(args.data/'pruner_best.pt',map_location='cpu',weights_only=True)
    network=PrunerNetwork(**{key:checkpoint['config'][key] for key in ['in_dim','hidden','depth']})
    network.load_state_dict(checkpoint['model_state']);network.eval()
    torch.set_num_threads(1)
    dataset=EpochDataset([str(p) for p in paths],index)
    assert len(dataset)==manifest['epochs']
    budgets=manifest['budgets'];methods=['learned','urgency','travel','random']
    totals={method:{k:[0,0] for k in budgets} for method in methods}
    rng=np.random.default_rng(manifest['random_seed'])
    rows=[];observed_pairs=0;observed_selected=0
    with torch.no_grad():
        for i in range(len(dataset)):
            item=dataset[i];count=int(item['n_pairs'])
            assert item['epoch_id']==i
            if count==0:continue
            file_index,offset=dataset.offsets[i]
            with Path(dataset.paths[file_index]).open() as stream:
                stream.seek(offset);record=json.loads(stream.readline())
            pairs=record['pairs'];labels=item['labels'].numpy()
            features=item['feats'].unsqueeze(0)
            scores=network(features,torch.ones((1,count),dtype=torch.bool)).numpy()[0]
            urgency=np.array([p['features'].get('T_so',1e9) for p in pairs])
            travel=np.array([p['features'].get('tau_xy_ru',1e9)+p['features'].get('tau_xy_ul',1e9) for p in pairs])
            all_scores=dict(learned=scores,urgency=-urgency,travel=-travel,random=rng.random(count))
            positive=int(labels.sum());observed_pairs+=count;observed_selected+=positive
            for method,values in all_scores.items():
                order=np.argsort(-values)
                for budget in budgets:
                    retained=order[:min(budget,count)]
                    recovered=int(labels[retained].sum())
                    totals[method][budget][0]+=recovered;totals[method][budget][1]+=positive
                    rows.append((i,method,budget,count,positive,recovered))
    assert observed_pairs==manifest['pairs'] and observed_selected==manifest['selected_pairs']
    import csv
    with (args.out/'selection_epoch_counts.csv').open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['epoch','method','budget','pairs','selected','retained_selected']);writer.writerows(rows)
    with (args.out/'selection_coverage.csv').open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['method','budget','retained_selected','selected','coverage'])
        for method in methods:
            for budget in budgets:
                recovered,positive=totals[method][budget]
                writer.writerow([method,budget,recovered,positive,recovered/max(positive,1)])
    result=dict(seed=4,epochs=len(dataset),pairs=observed_pairs,selected_pairs=observed_selected,
                values={method:{str(k):a/max(b,1) for k,(a,b) in levels.items()} for method,levels in totals.items()})
    (args.out/'selection_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
