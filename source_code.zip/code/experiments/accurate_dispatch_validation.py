"""Matched closed-loop Absolute MILP/BatchGreedy extension, seeds 30--44.

Preset 80 uses beta_M=2; preset 240 uses reference weights. Both controllers
share the simulator, alternatives and shield. BatchGreedy is replayed only to
obtain identically instrumented controller and complete-review latency.
"""
import argparse
import json
from pathlib import Path
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'experiments'))
import run_episode as runner
from baselines.milp_only import MILPOnlyController
from tactical.milp import TacticalMILP
from extension_validation import BatchResourceGreedy
from stopping_validation import TraceMILP, write_csv


class AbsoluteMILP(TraceMILP):
    # Retain the stopping parameters and achieved-gap audit, without shadow
    # decisions or line-level instrumentation inside the timed controller.
    solve = TacticalMILP.solve


def run(policy, k, seed, out, horizon=None):
    instance, timing = {}, []
    def factory(cfg, sim, max_slots_per_pair):
        ctrl = MILPOnlyController(cfg, sim, max_slots_per_pair=max_slots_per_pair)
        engine = (AbsoluteMILP(cfg.milp, ctrl.num_slots, ctrl.slot_size, policy='absolute')
                  if policy == 'absolute' else BatchResourceGreedy(cfg.milp, ctrl.num_slots, ctrl.slot_size))
        ctrl.milp = engine
        instance['engine'] = engine
        raw_decide = ctrl.decide
        def decide(state):
            start = time.perf_counter()
            result = raw_decide(state)
            elapsed = 1000 * (time.perf_counter() - start)
            timing.append(dict(time=state.epoch_time, controller_ms=elapsed))
            return result
        ctrl.decide = decide
        raw_review = sim._handle_review
        def review():
            start = time.perf_counter()
            result = raw_review()
            timing[-1]['review_ms'] = 1000 * (time.perf_counter() - start)
            return result
        sim._handle_review = review
        return ctrl
    runner.MILPOnlyController = factory
    overrides = {'milp.weights.beta_M': 2.} if str(k) == '80' else {}
    row = runner.run(f'configs/sweep/base__base__k{k}.yaml', seed, out, overrides, horizon)
    row.update(dispatch_policy=policy, preset=str(k),
        controller_mean_ms=float(np.mean([r['controller_ms'] for r in timing])),
        review_mean_ms=float(np.mean([r['review_ms'] for r in timing])),
        review_p95_ms=float(np.quantile([r['review_ms'] for r in timing], .95)),
        review_max_ms=max(r['review_ms'] for r in timing))
    out = Path(out)
    out.write_text(json.dumps(row, indent=2))
    write_csv(out.with_suffix('.timing.csv'), timing)
    if policy == 'absolute':
        write_csv(out.with_suffix('.gaps.csv'), instance['engine'].calls)
    return row


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--policy', required=True, choices=['absolute', 'batch'])
    p.add_argument('--k', required=True, choices=['80', '240'])
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--horizon', type=float)
    a = p.parse_args()
    run(a.policy, a.k, a.seed, a.out, a.horizon)
