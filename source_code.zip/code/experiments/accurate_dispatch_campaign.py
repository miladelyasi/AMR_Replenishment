"""Fixed 30 Absolute episodes plus 30 instrumented BatchGreedy replays."""
import concurrent.futures as cf
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'accurate_dispatch_results'
JOBS = [dict(policy=p, k=k, seed=s) for s in range(30, 45)
        for k in ['80', '240'] for p in ['absolute', 'batch']]

def one(job):
    stem = f"{job['policy']}_k{job['k']}_s{job['seed']:02d}"
    target = OUT / (stem + '.json')
    if target.exists() and target.with_suffix('.timing.csv').exists():
        return stem, 'cached'
    command = [sys.executable, 'experiments/accurate_dispatch_validation.py',
        '--policy', job['policy'], '--k', job['k'], '--seed', str(job['seed']), '--out', str(target)]
    with (OUT / (stem + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            env={**os.environ, 'OMP_NUM_THREADS':'1', 'OPENBLAS_NUM_THREADS':'1', 'MKL_NUM_THREADS':'1'})
    return stem, result.returncode

if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    manifest = dict(jobs=JOBS, horizon_seconds=28800,
        absolute=dict(relative_gap=0., absolute_gap=1e-6, time_limit_seconds=5.),
        weights={'80':{'beta_M':2.}, '240':'reference'},
        primary_contrasts='Absolute minus BatchGreedy at each fixed preset; paired seeds 30--44',
        outcomes=['stockout_minutes','total_travel_m','accepted_units','overflow_units','controller_mean_ms'],
        note='Matched extension on already examined seeds, not independent confirmation. BatchGreedy replays provide common timing instrumentation; compare all operational metrics with stored episodes.')
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    with cf.ThreadPoolExecutor(max_workers=int(sys.argv[1]) if len(sys.argv)>1 else 6) as pool:
        for i, result in enumerate(pool.map(one, JOBS), 1):
            print(i, len(JOBS), result, flush=True)
