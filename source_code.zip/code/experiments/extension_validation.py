"""Resource-feasible greedy dispatch and physical-port experiments.

Primary and technical-validation results are immutable. BatchGreedy uses the
same objective coefficients and linear constraints as TacticalMILP, but accepts
positive marginal gains in a deterministic order without an optimization call.
"""
import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'experiments'))
import run_episode as runner
from baselines.milp_only import MILPOnlyController
from common.enums import AccessClass
from common.types import Commitment, ReservationView
from tactical.milp import TacticalMILP, TacticalSolution
from tactical.windows import (compute_pickup_window, compute_drop_window,
                              compute_lock_window, slot_indices_overlapping)
from world.schedule_simulator import ScheduleSimulator, carried_peak_occupancy
from world.simulator import Simulator as BaseSimulator
from shield.prioritized import PrioritizedShield


class BatchResourceGreedy(TacticalMILP):
    """Greedy marginal objective reduction subject to all tactical inequalities."""
    def solve(self, state, feasible, jobs, **kw):
        start = time.perf_counter()
        weights = self.cfg.weights
        score = kw['score_field']
        candidates = []
        for i, ft in enumerate(feasible):
            cost = (weights.alpha_M * ft.risk
                    + weights.beta_M * (ft.travel_to_tote + ft.travel_to_line)
                    + weights.nu_M * ft.energy + weights.xi_M * ft.crowd
                    - weights.varrho * score.get((ft.robot_id, ft.job.line_id, ft.job.tote_id), 0.))
            gain = weights.P_0 / max(float(state.hat_T_so[ft.job.line_id]), 1e-3) - cost
            candidates.append((-gain, self._triple_key(ft), i))
        used_robots, used_jobs, used_totes = set(), set(), set()
        loads = Counter()
        selected = []
        total_gain = 0.
        for negative_gain, _, i in sorted(candidates):
            if negative_gain >= 0:
                break
            ft = feasible[i]
            rid, uid, lid = ft.robot_id, ft.job.tote_id, ft.job.line_id
            if rid in used_robots or uid in used_totes or ft.job.key() in used_jobs:
                continue
            if ft.energy > kw['battery_remaining'].get(rid, 0.) + 1e-10:
                continue
            common = dict(start_slot=ft.start_slot, slot_size=self.slot_size,
                          travel_to_tote_seconds=ft.travel_to_tote)
            windows = [
                ('src', [kw['tote_to_src_idx'][uid]], compute_pickup_window(**common, pickup_seconds=ft.pickup_seconds)),
                ('dst', [kw['line_to_dst_idx'][lid]], compute_drop_window(**common, pickup_seconds=ft.pickup_seconds,
                    travel_to_line_seconds=ft.travel_to_line, completion_time=ft.completion_time)),
                ('block', kw['tote_to_block_indices'].get(uid, []), compute_lock_window(**common, lock_seconds=ft.lock_seconds)),
            ]
            rows = [(kind, resource, slot) for kind, resources, window in windows
                    for resource in resources
                    for slot in slot_indices_overlapping(window, self.num_slots, self.slot_size)]
            if any(loads[row] + 1 > float(kw['capacities_' + row[0]][row[1]])
                   - float(kw['carried_' + row[0]][row[1], row[2]]) + 1e-10 for row in rows):
                continue
            loads.update(rows)
            used_robots.add(rid); used_jobs.add(ft.job.key()); used_totes.add(uid)
            selected.append(ft); total_gain -= negative_gain
        objective = sum(weights.P_0 / max(float(state.hat_T_so[j.line_id]), 1e-3) for j in jobs) - total_gain
        return TacticalSolution(
            [Commitment(f.robot_id, f.job, f.start_slot, state.epoch_time, self.slot_size) for f in selected],
            [j for j in jobs if j.key() in used_jobs], [j for j in jobs if j.key() not in used_jobs],
            objective, 1000 * (time.perf_counter() - start), 0., 'GREEDY',
            {'num_feasible_triples': len(feasible), 'num_jobs': len(jobs), 'num_commitments': len(selected)})


def validate_greedy_assignment(engine, solution, state, feasible, jobs, **kw):
    """Independent audit against the assembled MILP rows; no solver call."""
    model = engine._build_model()
    x, v = engine._add_decision_variables(model, feasible, jobs)
    engine._add_objective(model, x, v, feasible, jobs, kw['score_field'], state, {})
    engine._add_assignment_constraints(model, x, v, feasible, jobs)
    names = ['carried_src', 'carried_dst', 'carried_block', 'capacities_src',
             'capacities_dst', 'capacities_block', 'tote_to_src_idx', 'line_to_dst_idx', 'tote_to_block_indices']
    engine._add_capacity_constraints(model, x, feasible, *[kw[n] for n in names], {})
    engine._add_battery_constraint(model, x, feasible, kw['battery_remaining'])
    model.update()
    chosen = {(c.robot_id, c.job.key(), c.start_slot) for c in solution.commitments}
    served = {c.job.key() for c in solution.commitments}
    values = {x[i].VarName: int((ft.robot_id, ft.job.key(), ft.start_slot) in chosen) for i, ft in enumerate(feasible)}
    values.update({v[i].VarName: int(j.key() in served) for i, j in enumerate(jobs)})
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        lhs = sum(row.getCoeff(i) * values[row.getVar(i).VarName] for i in range(row.size()))
        error = lhs - constraint.RHS
        assert {'<': error <= 1e-8, '>': error >= -1e-8, '=': abs(error) <= 1e-8}[constraint.Sense], (constraint.ConstrName, lhs, constraint.RHS)
    obj = model.ObjCon + sum(var.Obj * values[var.VarName] for var in model.getVars())
    assert abs(obj - solution.objective) <= 1e-6 * max(1., abs(obj))
    nrows = model.NumConstrs
    model.dispose()
    return nrows


PORT_ROWS = ((0, 1, 2), (3, 4, 5), (7, 6, 8), (11, 10, 12), (15, 14, 16), (19, 18, 17))


class MultiPortSimulator(ScheduleSimulator):
    """Distinct boundary delivery nodes feeding each line's common buffer."""
    def __init__(self, *args, ports=1, **kw):
        self.ports_per_line = ports
        self.delivery_ports = {lid: [(0, y) for y in rows[:ports]] for lid, rows in enumerate(PORT_ROWS)}
        super().__init__(*args, **kw)

    def reset(self):
        super().reset()
        assert len(self.buffers) == 6 and self.grid.width == 20 and self.grid.height == 20
        assert all(self.line_positions[lid] == cells[0] for lid, cells in self.delivery_ports.items())
        self.port_intervals = []

    def _build_state(self):
        # Identical inherited-occupancy construction, with the actual group
        # capacity p rather than the single-node benchmark assertion.
        state = BaseSimulator._build_state(self)
        if not hasattr(self, 'active_missions'):
            return state
        for uid in self.reserved_totes:
            if uid in state.access:
                state.access[uid] = AccessClass.INFEASIBLE
        delta = self.cfg.controller.slot_size_delta_seconds
        nslots = int(round(self.cfg.controller.tactical_horizon_H_seconds / delta))
        src_intervals, dst_intervals = [], []
        for mission in self.active_missions.values():
            src_intervals.append((self._src_index[mission.path_to_pickup[-1]], mission.arrive_pickup_time, mission.pickup_done_time))
            dst_intervals.append((mission.commitment.job.line_id, mission.arrive_drop_time, mission.drop_done_time))
        src = carried_peak_occupancy(src_intervals, len(self._src_index), nslots, delta, self.t_now)
        dst = carried_peak_occupancy(dst_intervals, len(self.buffers), nslots, delta, self.t_now)
        assert src.max(initial=0) <= 1 and dst.max(initial=0) <= self.ports_per_line
        state.reservations = ReservationView(src=src, dst=dst, block=src.copy())
        self._last_decision_state = state
        return state

    def _apply_commitments_with_shield(self, commitments):
        before = set(self.active_missions)
        result = super()._apply_commitments_with_shield(commitments)
        for rid in set(self.active_missions) - before:
            mission = self.active_missions[rid]
            lid = int(mission.commitment.job.line_id)
            cell = mission.path_to_drop[-1]
            assert cell in self.delivery_ports[lid]
            self.port_intervals.append(dict(line=lid, port_y=int(cell[1]),
                start=mission.arrive_drop_time, end=mission.drop_done_time))
        return result

    def _handle_arrive_drop(self, payload):
        self.robots[payload['rid']].pos = self.active_missions[payload['rid']].path_to_drop[-1]


class MultiPortShield(PrioritizedShield):
    def __init__(self, *args, delivery_ports, **kw):
        self.delivery_ports = delivery_ports
        super().__init__(*args, **kw)

    def _plan_one(self, cm, **kw):
        # Each trial is read-only. The inherited plan() commits only the
        # selected complete mission and retains its bounded shift budget.
        alternatives = []
        for rank, cell in enumerate(self.delivery_ports[int(cm.job.line_id)]):
            mission = super()._plan_one(cm, **{**kw, 'line_cell': cell})
            if mission is not None:
                alternatives.append((mission.drop_done_time, mission.travel_distance_m, rank, mission))
        return min(alternatives, key=lambda a: a[:3])[-1] if alternatives else None


class MultiPortController(MILPOnlyController):
    def _make_travel_to_line_fn(self):
        def travel(uid, lid):
            cell = self.sim.storage.find_tote_column(uid)
            return min(self.sim.grid.travel_time(cell, port) for port in self.sim.delivery_ports[lid]) if cell is not None else float('inf')
        return travel


def audit_ports(sim):
    def sweep(intervals):
        events = sorted([(r['start'], 1) for r in intervals] + [(r['end'], -1) for r in intervals])
        active = peak = 0
        last = 0.
        parallel = 0.
        for t, change in events:
            if active >= 2:
                parallel += max(0., min(t, sim.cfg.experiment.episode_horizon_seconds) - last)
            active += change
            peak = max(peak, active)
            last = t
        assert active == 0
        return peak, parallel
    groups, nodes = defaultdict(list), defaultdict(list)
    for interval in sim.port_intervals:
        groups[interval['line']].append(interval)
        nodes[interval['port_y']].append(interval)
    per_line = {str(lid): dict(zip(['peak', 'parallel_service_seconds'], sweep(rows))) for lid, rows in groups.items()}
    per_port = {str(y): dict(missions=len(rows), peak=sweep(rows)[0]) for y, rows in nodes.items()}
    assert all(r['peak'] <= sim.ports_per_line for r in per_line.values())
    assert all(r['peak'] <= 1 for r in per_port.values())
    return dict(ports_per_line=sim.ports_per_line, coordinates=sim.delivery_ports,
                line_groups=per_line, physical_ports=per_port,
                max_group_occupancy=max((r['peak'] for r in per_line.values()), default=0),
                parallel_line_seconds=sum(r['parallel_service_seconds'] for r in per_line.values()))


def run(kind, k, seed, out, horizon=None, ports=1, validate=False):
    instance = {}
    def sim_factory(cfg, controller, seed):
        sim = MultiPortSimulator(cfg, controller, seed=seed, ports=ports) if kind == 'ports' else ScheduleSimulator(cfg, controller, seed=seed)
        instance['sim'] = sim
        return sim
    runner.Simulator = sim_factory
    if kind == 'ports':
        runner.PrioritizedShield = lambda *a, **kw: MultiPortShield(*a, **kw, delivery_ports=instance['sim'].delivery_ports)
    def controller_factory(cfg, sim, max_slots_per_pair):
        cls = MultiPortController if kind == 'ports' else MILPOnlyController
        ctrl = cls(cfg, sim, max_slots_per_pair=max_slots_per_pair)
        if kind == 'batch':
            engine = BatchResourceGreedy(cfg.milp, ctrl.num_slots, ctrl.slot_size)
            if validate:
                raw = engine.solve
                def checked(**kw):
                    solution = raw(**kw)
                    instance['checked_rows'] = instance.get('checked_rows', 0) + validate_greedy_assignment(engine, solution, **kw)
                    instance['checked_states'] = instance.get('checked_states', 0) + 1
                    return solution
                engine.solve = checked
            ctrl.milp = engine
        return ctrl
    runner.MILPOnlyController = controller_factory
    overrides = {'milp.weights.beta_M': 2.} if kind == 'batch' and str(k) == '80' else {}
    if kind == 'ports':
        overrides.update({'world.interfaces.src_capacity': 1, 'world.interfaces.dst_capacity': ports})
    method = 'UrgencyRank' if kind == 'urgency' else 'MILPOnly'
    row = runner.run(f'configs/sweep/base__base__k{k}.yaml', seed, out, overrides, horizon, method)
    row.update(extension_kind=kind, preset=str(k), checked_rows=instance.get('checked_rows', 0),
               checked_states=instance.get('checked_states', 0))
    if kind == 'ports':
        row['port_audit'] = audit_ports(instance['sim'])
        intervals = instance['sim'].port_intervals
        with Path(out).with_suffix('.ports.csv').open('w') as stream:
            writer = csv.DictWriter(stream, fieldnames=['line', 'port_y', 'start', 'end'])
            writer.writeheader(); writer.writerows(intervals)
    Path(out).write_text(json.dumps(row, indent=2))
    return row


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', choices=['batch', 'urgency', 'ports'], required=True)
    parser.add_argument('--k', default='80')
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--horizon', type=float)
    parser.add_argument('--ports', type=int, default=1)
    parser.add_argument('--validate', action='store_true')
    args = parser.parse_args()
    run(args.kind, args.k, args.seed, args.out, args.horizon, args.ports, args.validate)
