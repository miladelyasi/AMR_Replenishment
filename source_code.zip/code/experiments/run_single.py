"""Run a single baseline on N seeds, save to CSV. For piecewise execution.

Usage:
    python experiments/run_single.py --method <name> --config <yaml> --seeds 5 --horizon 2400 --out <csv>
"""
from __future__ import annotations
import argparse, csv, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from common.config import Config
from common.controller import Controller, ControllerOutput
from world.simulator import Simulator
from baselines.random_controller import RandomController
from baselines.reactive import ReactiveThresholdController
from baselines.urgency_rank import UrgencyRankController
from baselines.milp_only import MILPOnlyController
from shield.prioritized import PrioritizedShield

class _Stub(Controller):
    name = "stub"
    def decide(self, s): return ControllerOutput([], {})

def make_sim(cfg, seed):
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    sh = PrioritizedShield(cfg=cfg.shield, grid=sim.grid,
                           slot_size=cfg.controller.slot_size_delta_seconds)
    sh.cfg.shield_repair_budget_slots = cfg.controller.shield_repair_budget_slots
    sim.shield = sh
    return sim

def make_ctrl(method, cfg, sim, max_slots=1):
    D = cfg.controller.slot_size_delta_seconds
    if method == "Random": return RandomController(seed=0)
    if method == "Reactive": return ReactiveThresholdController(slot_size=D)
    if method == "UrgencyRank": return UrgencyRankController(slot_size=D)
    if method == "MILPOnly": return MILPOnlyController(cfg=cfg, sim_handle=sim, max_slots_per_pair=max_slots)
    raise ValueError(method)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--method", required=True)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--seeds", type=int, default=5)
    p.add_argument("--horizon", type=float, default=2400.0)
    p.add_argument("--max-slots", type=int, default=1)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()

    cfg = Config.from_yaml(args.config)
    cfg.experiment.episode_horizon_seconds = args.horizon

    rows = []
    print(f"=== {args.method} on {args.config.name}, horizon={args.horizon:.0f}s, seeds={args.seeds} ===", flush=True)
    for seed in range(args.seeds):
        sim = make_sim(cfg, seed)
        ctrl = make_ctrl(args.method, cfg, sim, args.max_slots)
        sim.controller = ctrl; ctrl.reset()
        t0 = time.perf_counter()
        r = sim.run()
        dt = time.perf_counter() - t0
        row = {
            "method": args.method, "seed": seed,
            "stockout_minutes": r.stockout_minutes,
            "delivered_total": r.delivered_total,
            "delivered_on_time": r.delivered_on_time,
            "on_time_ratio": r.on_time_ratio,
            "total_travel_m": r.total_travel_m,
            "total_energy": r.total_energy,
            "shield_repairs": r.shield_interventions,
            "shield_rejections": r.rejected_commitments,
            "wall_seconds": dt,
        }
        rows.append(row)
        print(f"  seed={seed:2d}: stockout={r.stockout_minutes:7.3f} min, "
              f"delivered={r.delivered_total:4d}, travel={r.total_travel_m:6.0f}m, "
              f"repairs={r.shield_interventions:4d}, wall={dt:5.1f}s", flush=True)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)
    print(f"Wrote {args.out}", flush=True)

if __name__ == "__main__":
    main()
