"""Stage-1 smoke test.

Runs an episode under the random controller and prints summary metrics.
This is the Stage-1 acceptance criterion: the test should run cleanly,
finish quickly, and produce non-pathological numbers.

Usage
-----
    python experiments/smoke_test.py --config configs/base.yaml
    python experiments/smoke_test.py --config configs/base.yaml --short
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

# Make `src` importable when running from repo root
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from common.config import Config                            # noqa: E402
from world.simulator import Simulator                       # noqa: E402
from baselines.random_controller import RandomController    # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("configs/base.yaml"))
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--short", action="store_true",
        help="Override episode horizon to 1 hour for fast smoke testing.",
    )
    args = parser.parse_args()

    cfg = Config.from_yaml(args.config)
    if args.short:
        cfg.experiment.episode_horizon_seconds = 3600.0

    print(f"Loaded config: {args.config}")
    print(f"  grid:    {cfg.world.grid.width}x{cfg.world.grid.height}")
    print(f"  robots:  {cfg.world.robots.fleet_size}")
    print(f"  lines:   {cfg.world.num_lines}")
    print(f"  horizon: {cfg.experiment.episode_horizon_seconds:.0f} s "
          f"({cfg.experiment.episode_horizon_seconds / 60:.0f} min)")
    print(f"  seed:    {args.seed}")
    print()

    controller = RandomController(seed=args.seed)
    sim = Simulator(cfg=cfg, controller=controller, seed=args.seed)

    t0 = time.perf_counter()
    result = sim.run()
    dt = time.perf_counter() - t0

    print(f"[ DONE ] Wall-clock: {dt:.2f} s")
    print()
    print("=== Aggregate metrics ===")
    print(f"  controller            = {result.controller_name}")
    print(f"  stockout_minutes      = {result.stockout_minutes:.2f}")
    print(f"  on_time_ratio         = {result.on_time_ratio:.3f}")
    print(f"  line_reliability      = {result.line_reliability:.3f}")
    print(f"  total_travel_m        = {result.total_travel_m:.1f}")
    print(f"  total_energy          = {result.total_energy:.4f}")
    print(f"  delivered_total       = {result.delivered_total}")
    print(f"  delivered_on_time     = {result.delivered_on_time}")
    print()
    print("=== Per-line stockout (s) ===")
    for lid, secs in sorted(result.per_line_stockout_seconds.items()):
        print(f"  line {lid:2d}: {secs:8.1f} s ({secs / 60:5.2f} min)")
    print()
    print(f"=== Epoch records: {len(result.epoch_records)} epochs ===")
    if result.epoch_records:
        avg_cands = sum(r.num_candidates for r in result.epoch_records) / len(result.epoch_records)
        avg_commits = sum(r.num_commitments for r in result.epoch_records) / len(result.epoch_records)
        print(f"  mean num_candidates  : {avg_cands:.1f}")
        print(f"  mean num_commitments : {avg_commits:.2f}")


if __name__ == "__main__":
    main()
