"""Sec 5.3 overall comparison: Random / Reactive / UrgencyRank / MILPOnly + Shield.

Runs a full set of seeds for each controller under a chosen scenario
(default: base config) and writes the results as a CSV that can be
imported into LaTeX.

Usage
-----
    python experiments/run_overall.py --config configs/base.yaml --seeds 5
    python experiments/run_overall.py --config configs/surge.yaml --seeds 5
    python experiments/run_overall.py --short    # quick smoke run

    # NEW: collect per-epoch JSONL from MILPOnly for pruner training
    python experiments/run_overall.py --config configs/base.yaml \
        --seeds 5 --rollout-dir rollouts/milponly_base
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from common.config import Config                              # noqa: E402
from common.controller import Controller, ControllerOutput    # noqa: E402
from world.simulator import Simulator                         # noqa: E402
from baselines.random_controller import RandomController      # noqa: E402
from baselines.reactive import ReactiveThresholdController    # noqa: E402
from baselines.urgency_rank import UrgencyRankController      # noqa: E402
from baselines.milp_only import MILPOnlyController            # noqa: E402
from shield.prioritized import PrioritizedShield              # noqa: E402
from baselines.fifo import FIFOController                    # noqa: E402
from baselines.nearest_robot import NearestRobotController   # noqa: E402


class _Stub(Controller):
    name = "stub"

    def decide(self, s):
        return ControllerOutput([], {})


def _make_sim(cfg, seed, with_shield):
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    if with_shield:
        sh = PrioritizedShield(
            cfg=cfg.shield,
            grid=sim.grid,
            slot_size=cfg.controller.slot_size_delta_seconds,
        )
        sh.cfg.shield_repair_budget_slots = cfg.controller.shield_repair_budget_slots
        sim.shield = sh
    return sim


def _run_one(cfg, seed, controller_factory, with_shield=True):
    sim = _make_sim(cfg, seed, with_shield)
    ctrl = controller_factory(cfg, sim, seed)
    sim.controller = ctrl
    ctrl.reset()
    t0 = time.perf_counter()
    if getattr(_run_one, '_mech_log_path', None) is not None:
        from world.simulator import MechanismLogger
        sim._mech_logger = MechanismLogger(_run_one._mech_log_path)
    result = sim.run()
    dt = time.perf_counter() - t0

    # NEW: flush the per-episode JSONL writer if this controller has one.
    # No-op for Random/Reactive/UrgencyRank and for MILPOnly without
    # --rollout-dir (close_rollout simply returns).
    if hasattr(ctrl, "close_rollout"):
        try:
            ctrl.close_rollout()
        except Exception as e:  # never let logging break an eval run
            print(f"[warn] close_rollout failed: {e}")

    return result, dt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("../configs/base.yaml"))
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument(
        "--short",
        action="store_true",
        help="Override episode horizon to 5 min for quick smoke runs",
    )
    parser.add_argument(
        "--no-shield",
        action="store_true",
        help="Disable the shield (Stage-2 mode)",
    )
    parser.add_argument("--out", type=Path, default=Path("../results/overall_results.csv"))
    parser.add_argument(
        "--mech-log-dir",
        type=Path,
        default=None,
        help="If given, write per-(epoch,line) JSONL telemetry to "
             "{mech-log-dir}/{method}_seed{seed}.jsonl.",
    )
    parser.add_argument(
        "--rollout-dir",
        type=Path,
        default=None,
        help="If given, MILPOnly writes one JSONL per seed to this "
             "directory for pruner training (default: disabled, "
             "behaviour byte-identical to before).",
    )
    parser.add_argument(
        "--methods",
        type=str,
        default=None,
        help="Comma-separated subset of methods to run, e.g. "
             "'MILPOnly' or 'Random,MILPOnly'. Default: all methods.",
    )

    parser.add_argument(
        "--pruner-ckpt",
        type=str,
        default=None,
        help="If set, MILPOnly+F1 uses this learned pruner.",
    )
    parser.add_argument(
        "--pruner-index",
        type=str,
        default=None,
        help="feature_index.json matching --pruner-ckpt",
    )
    parser.add_argument(
        "--pruner-k",
        type=int,
        default=80,
        help="learned-pruner candidate budget",
    )

    parser.add_argument("--f2-ckpt", type=str, default=None)
    parser.add_argument("--f2-index", type=str, default=None)
    parser.add_argument("--f2-eta", type=float, default=1.0)
    parser.add_argument("--reactive-safety-mult", type=float, default=1.0)
    parser.add_argument("--urgency-horizon", type=float, default=float("inf"))

    args = parser.parse_args()

    cfg = Config.from_yaml(args.config)
    if args.short:
        cfg.experiment.episode_horizon_seconds = 300.0

    D = cfg.controller.slot_size_delta_seconds

    if args.rollout_dir is not None:
        args.rollout_dir.mkdir(parents=True, exist_ok=True)

    def _milp_factory(cfg, sim, s=0):
        rp = (
            str(args.rollout_dir / f"milponly_seed{s}.jsonl")
            if args.rollout_dir is not None else None
        )
        return MILPOnlyController(
            cfg=cfg,
            sim_handle=sim,
            max_slots_per_pair=1,
            rollout_path=rp,
            rollout_episode_id=s,
        )

    def _milp_f1_factory(cfg, sim, s=0):
        return MILPOnlyController(
            cfg=cfg,
            sim_handle=sim,
            max_slots_per_pair=1,
            pruner_ckpt=args.pruner_ckpt,
            pruner_index=args.pruner_index,
            pruner_k=args.pruner_k,
        )

    def _milp_f2_factory(cfg, sim, s=0):
        return MILPOnlyController(
            cfg=cfg,
            sim_handle=sim,
            max_slots_per_pair=1,
            f2_ckpt=args.f2_ckpt,
            f2_index=args.f2_index,
            f2_eta=args.f2_eta,
        )

    methods = [
        ("Random",      lambda cfg, sim, s=0: RandomController(seed=s)),
        ("Reactive",    lambda cfg, sim, s=0: ReactiveThresholdController(slot_size=D)),
        ("UrgencyRank", lambda cfg, sim, s=0: UrgencyRankController(slot_size=D)),
        ("Reactive_Tight",     lambda cfg, sim, s=0: ReactiveThresholdController(slot_size=D, safety_mult=1.5)),
        ("Reactive_Loose",     lambda cfg, sim, s=0: ReactiveThresholdController(slot_size=D, safety_mult=0.7)),
        ("UrgencyRank_Tight",  lambda cfg, sim, s=0: UrgencyRankController(slot_size=D, urgency_horizon=60.0)),
        ("UrgencyRank_Loose",  lambda cfg, sim, s=0: UrgencyRankController(slot_size=D, urgency_horizon=600.0)),
        ("MILPOnly",    _milp_factory),
        ("MILPOnly+F1", _milp_f1_factory),
        ("MILPOnly+F2", _milp_f2_factory),
        ("FIFO", lambda cfg, sim, s=0: FIFOController(slot_size=D)),
        ("NearestRobot", lambda cfg, sim, s=0: NearestRobotController(slot_size=D)),
    ]

    # NEW: optional method subsetting (useful for logging-only runs)
    if args.methods:
        wanted = {m.strip() for m in args.methods.split(",")}
        methods = [(lbl, fac) for (lbl, fac) in methods if lbl in wanted]
        if not methods:
            raise SystemExit(
                f"--methods {args.methods!r} matched nothing. "
                f"Valid: Random, Reactive, UrgencyRank, MILPOnly, "
                f"MILPOnly+F1, MILPOnly+F2"
            )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    rows = []

    print(
        f"=== {args.config} (horizon={cfg.experiment.episode_horizon_seconds:.0f}s, "
        f"seeds={args.seeds}, shield={'OFF' if args.no_shield else 'ON'}"
        f"{', rollout=' + str(args.rollout_dir) if args.rollout_dir else ''}) ==="
    )
    print(
        f"{'method':>12s} | {'seed':>4s} | {'stockout (min)':>14s} | "
        f"{'delivered':>9s} | {'on-time':>7s} | {'travel (m)':>10s} | "
        f"{'repairs':>7s} | {'rejected':>8s} | {'wall':>5s}"
    )
    print("-" * 110)

    for label, factory in methods:
        for seed in range(args.seeds):
            if args.mech_log_dir is not None:
                _run_one._mech_log_path = args.mech_log_dir / f"{label}_seed{seed}.jsonl"
            else:
                _run_one._mech_log_path = None
            r, dt = _run_one(cfg, seed, factory, with_shield=not args.no_shield)
            rows.append({
                "method": label,
                "seed": seed,
                "stockout_minutes": r.stockout_minutes,
                "delivered_total": r.delivered_total,
                "delivered_on_time": r.delivered_on_time,
                "on_time_ratio": r.on_time_ratio,
                "total_travel_m": r.total_travel_m,
                "total_energy": r.total_energy,
                "shield_repairs": r.shield_interventions,
                "shield_rejections": r.rejected_commitments,
                "wall_seconds": dt,
            })
            print(
                f"{label:>12s} | {seed:4d} | {r.stockout_minutes:14.2f} | "
                f"{r.delivered_total:9d} | {r.on_time_ratio:7.3f} | "
                f"{r.total_travel_m:10.0f} | {r.shield_interventions:7d} | "
                f"{r.rejected_commitments:8d} | {dt:5.1f}s"
            )

    # Write CSV
    with open(args.out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nWrote {args.out}")


if __name__ == "__main__":
    main()