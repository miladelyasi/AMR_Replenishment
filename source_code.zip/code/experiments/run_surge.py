"""Section 5.4 — Resilience Under Demand Surges.

Same methods as ``run_overall.py``, but using the ``surge.yaml`` config.
Reports tail-risk metrics: worst-decile stockout, surge-response lag,
variability across replications.

Usage
-----
    python experiments/run_surge.py --config configs/surge.yaml --seeds 30
"""

from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("configs/surge.yaml"))
    parser.add_argument("--seeds", type=int, default=30)
    parser.add_argument("--out_dir", type=Path, default=Path("results/surge"))
    args = parser.parse_args()
    raise NotImplementedError("Implement after run_overall.py is working.")


if __name__ == "__main__":
    main()
