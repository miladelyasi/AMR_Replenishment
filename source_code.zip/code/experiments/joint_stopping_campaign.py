"""165 new episodes; reuse 45 complete Absolute reference-weight records."""
import concurrent.futures as cf
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'joint_stopping_results'
JOBS = [dict(k=k, beta=beta, seed=s)
        for beta, presets, seeds in [(1.,['80','120','160','240','UNPRUNED'],range(30)),
                                     (2.,['80','160','240','UNPRUNED'],range(15))]
        for k in presets for s in seeds]


def one(job):
    stem = f"absolute_b{job['beta']:g}_k{job['k']}_s{job['seed']:02d}"
    target = OUT / (stem+'.json')
    if job['beta'] == 1. and job['k'] in ['80','240','UNPRUNED'] and job['seed'] < 15:
        original = ROOT / 'stopping_results' / f"absolute_k{job['k']}_s{job['seed']:02d}.json"
        assert original.exists() and original.with_suffix('.gaps.csv').exists()
        return stem, 'reused'
    if target.exists() and target.with_suffix('.gaps.csv').exists():
        return stem, 'cached'
    command = [sys.executable, 'experiments/joint_stopping_validation.py', '--k',job['k'],
               '--beta', str(job['beta']), '--seed',str(job['seed']), '--out',str(target)]
    with (OUT/(stem+'.log')).open('w') as log:
        r = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                           env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
    if r.returncode:
        raise RuntimeError((stem,r.returncode))
    return stem, r.returncode


if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    source = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
              for d in ['src','configs','experiments'] for p in sorted((ROOT/d).rglob('*'))
              if p.is_file() and p.suffix in ['.py','.yaml']}
    manifest = dict(jobs=JOBS, new_executions=165, reused_executions=45, horizon_seconds=28800,
                    stopping=dict(relative_gap=0.,absolute_gap=1e-6,time_limit_seconds=5.),
                    weights='All reference coefficients except beta_M=2 in the fixed joint test.',
                    source_sha256=source,
                    contrasts='Within-beta preset contrasts and within-preset beta=2 minus beta=1; matched seeds.')
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
    with cf.ThreadPoolExecutor(max_workers=int(sys.argv[1]) if len(sys.argv)>1 else 6) as pool:
        for i,result in enumerate(pool.map(one,JOBS),1):
            print(i,len(JOBS),result,flush=True)
