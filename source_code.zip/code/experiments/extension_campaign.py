"""Held-out dispatch comparison and physically usable delivery-port experiment."""
import concurrent.futures as cf
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'extension_results'
OUT.mkdir(exist_ok=True)
jobs = [dict(kind='batch', k=k, seed=seed, ports=1) for seed in range(30, 45) for k in ['80', '240']]
jobs += [dict(kind='urgency', k='80', seed=seed, ports=1) for seed in range(30, 45)]
phase = sys.argv[2] if len(sys.argv) > 2 else 'comparators'
if phase == 'ports':
    jobs = [dict(kind='ports', k=k, seed=seed, ports=p)
            for seed in range(15) for k in ['80', '240'] for p in [2, 3]]

def one(job):
    stem = f"{job['kind']}_k{job['k']}_p{job['ports']}_s{job['seed']:02d}"
    target = OUT / (stem + '.json')
    if target.exists():
        return stem, 'cached'
    cmd = [sys.executable, 'experiments/extension_validation.py', '--kind', job['kind'],
           '--k', job['k'], '--seed', str(job['seed']), '--ports', str(job['ports']), '--out', str(target)]
    with (OUT / (stem + '.log')).open('w') as log:
        result = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            env={**os.environ, 'OMP_NUM_THREADS':'1', 'OPENBLAS_NUM_THREADS':'1', 'MKL_NUM_THREADS':'1'})
    return stem, result.returncode

if __name__ == '__main__':
    (OUT / ('manifest_' + phase + '.json')).write_text(json.dumps(jobs, indent=2))
    with cf.ThreadPoolExecutor(max_workers=int(sys.argv[1]) if len(sys.argv)>1 else 4) as pool:
        for i, result in enumerate(pool.map(one, jobs), 1):
            print(i, len(jobs), result, flush=True)
