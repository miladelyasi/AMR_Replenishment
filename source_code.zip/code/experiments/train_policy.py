"""Train the proposed neuro-symbolic policy with SMDP PPO.

Closed-loop training: the policy proposes preference scores, the embedded
MILP projects them onto feasible commitments, and the shield realizes them
collision-free. Rewards are computed by the simulator using the eq. (reward)
weights from the config. Buffer is collected over multiple short episodes,
then PPO updates fire.

Usage (sandbox smoke):
    python experiments/train_policy.py --updates 4 --episode-seconds 300 --output policies/smoke.pt

Usage (full training):
    python experiments/train_policy.py --updates 200 --episode-seconds 1800 \
        --output policies/proposed.pt --log-csv results/training_log.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import numpy as np                                            # noqa: E402
import torch                                                  # noqa: E402

from common.config import Config                              # noqa: E402
from common.controller import Controller, ControllerOutput    # noqa: E402
from world.simulator import Simulator                         # noqa: E402
from shield.prioritized import PrioritizedShield              # noqa: E402

from policy import (                                          # noqa: E402
    ActorCritic, RLController, RolloutBuffer, Transition,
    GLOBAL_FEAT_DIM, ROBOT_FEAT_DIM, JOB_FEAT_DIM, PAIR_FEAT_DIM,
    ppo_update,
)


class _Stub(Controller):
    name = "stub"
    def decide(self, s):
        return ControllerOutput([], {})


def _make_sim(cfg, seed, with_shield=True):
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    if with_shield:
        sh = PrioritizedShield(
            cfg=cfg.shield, grid=sim.grid,
            slot_size=cfg.controller.slot_size_delta_seconds,
        )
        sh.cfg.shield_repair_budget_slots = cfg.controller.shield_repair_budget_slots
        sim.shield = sh
    return sim


def _collect_episode(
    cfg: Config,
    actor_critic: ActorCritic,
    buffer: RolloutBuffer,
    seed: int,
    device: torch.device,
    horizon_seconds: float,
    max_slots_per_pair: int = 1,
) -> dict:
    """Run one episode under the RL controller, push transitions into the buffer."""
    cfg.experiment.episode_horizon_seconds = horizon_seconds
    sim = _make_sim(cfg, seed)
    ctrl = RLController(
        cfg=cfg, actor_critic=actor_critic, sim_handle=sim,
        device=str(device), training=True,
        max_slots_per_pair=max_slots_per_pair,
    )
    sim.controller = ctrl; ctrl.reset()

    # We collect transitions by hooking into _handle_review.
    # Approach: run sim.run() and afterwards, reconstruct transitions
    # from the EpochRecord rewards + the controller's last_features cache.
    #
    # Simpler: override decide() to push the transition AFTER the next decide
    # is called (so we know holding_time and reward). This matches the
    # SMDP interpretation: at epoch n, we record state s_n, action a_n;
    # at epoch n+1, we have the reward r_n and next state s_{n+1}.
    pending_transition: dict | None = None

    orig_decide = ctrl.decide
    def hooked_decide(state):
        nonlocal pending_transition
        out = orig_decide(state)
        # If we have a pending transition, complete it now using s' = state
        if pending_transition is not None and ctrl.last_features is not None:
            # Reward is the LAST EpochRecord's reward (just-computed by _handle_review)
            recs = sim._epoch_records
            if recs:
                last_r = recs[-1].reward
                last_holding = recs[-1].holding_time
                pending_transition["reward"] = last_r
                pending_transition["holding_time"] = last_holding
                pending_transition["next_state"] = _features_to_storable(ctrl.last_features)
                pending_transition["done"] = False
                buffer.add(Transition(**pending_transition))
                pending_transition = None
        # Stash the new transition (without reward yet)
        if ctrl.last_features is not None and ctrl.last_action is not None:
            pending_transition = {
                "state": _features_to_storable(ctrl.last_features),
                "action": ctrl.last_action.copy(),
                "log_prob_old": float(ctrl.last_log_prob),
                "reward": 0.0,
                "holding_time": 0.0,
                "next_state": {},   # filled at next decide
                "done": False,
            }
        return out
    ctrl.decide = hooked_decide

    result = sim.run()

    # Close the final transition (done=True). Reward = the reward recorded
    # for the LAST epoch (already captured in EpochRecord).
    if pending_transition is not None:
        recs = sim._epoch_records
        if recs:
            pending_transition["reward"] = recs[-1].reward
            pending_transition["holding_time"] = recs[-1].holding_time
            pending_transition["next_state"] = pending_transition["state"]   # dummy
            pending_transition["done"] = True
            buffer.add(Transition(**pending_transition))

    # Episode summary
    return {
        "stockout_minutes": result.stockout_minutes,
        "delivered_total": result.delivered_total,
        "total_travel_m": result.total_travel_m,
        "total_reward": float(sum(r.reward for r in sim._epoch_records)),
    }


def _features_to_storable(features: dict) -> dict:
    """Drop the side-channel keys (lists/dicts) that the trainer doesn't need."""
    keep = {"global", "robot", "job", "pair", "pair_indices", "pair_mask"}
    return {k: np.asarray(v) for k, v in features.items() if k in keep}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("configs/base.yaml"))
    parser.add_argument("--surge-config", type=Path, default=None,
                        help="Optional second config used for some episodes (mixed training).")
    parser.add_argument("--mix-surge-ratio", type=float, default=0.0,
                        help="Probability that an episode uses --surge-config instead of --config.")
    parser.add_argument("--updates", type=int, default=20,
                        help="Number of PPO updates")
    parser.add_argument("--episodes-per-update", type=int, default=2)
    parser.add_argument("--episode-seconds", type=float, default=300.0)
    parser.add_argument("--max-slots-per-pair", type=int, default=1)
    parser.add_argument("--output", type=Path, default=Path("policies/proposed.pt"))
    parser.add_argument("--log-csv", type=Path, default=Path("results/training_log.csv"))
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    cfg = Config.from_yaml(args.config)
    cfg_surge = Config.from_yaml(args.surge_config) if args.surge_config else None
    device = torch.device(args.device)

    # Build the actor-critic
    ac = ActorCritic(
        global_in_dim=GLOBAL_FEAT_DIM,
        robot_in_dim=ROBOT_FEAT_DIM,
        job_in_dim=JOB_FEAT_DIM,
        pair_in_dim=PAIR_FEAT_DIM,
        cfg=cfg.policy,
    ).to(device)
    optimizer = torch.optim.Adam(ac.parameters(), lr=cfg.policy.ppo.learning_rate)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log_csv.parent.mkdir(parents=True, exist_ok=True)

    log_rows = []
    print(f"=== Training {args.updates} updates × {args.episodes_per_update} episodes "
          f"× {args.episode_seconds}s each ===")
    print(f"{'update':>6s} | {'episodes':>8s} | {'mean_reward':>11s} | "
          f"{'mean_stockout':>13s} | {'mean_delivered':>13s} | "
          f"{'actor_loss':>10s} | {'critic_loss':>11s} | {'wall':>6s}")

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    for update_idx in range(args.updates):
        buffer = RolloutBuffer()
        ep_rewards = []
        ep_stockouts = []
        ep_delivered = []

        t0 = time.perf_counter()
        n_surge = 0
        for ep_idx in range(args.episodes_per_update):
            seed = args.seed + update_idx * 100 + ep_idx
            # Probabilistically pick surge config (if provided)
            if cfg_surge is not None and np.random.random() < args.mix_surge_ratio:
                ep_cfg = cfg_surge
                n_surge += 1
            else:
                ep_cfg = cfg
            summary = _collect_episode(
                ep_cfg, ac, buffer, seed, device,
                horizon_seconds=args.episode_seconds,
                max_slots_per_pair=args.max_slots_per_pair,
            )
            ep_rewards.append(summary["total_reward"])
            ep_stockouts.append(summary["stockout_minutes"])
            ep_delivered.append(summary["delivered_total"])

        # PPO update
        diag = ppo_update(
            ac, optimizer, buffer,
            cfg=cfg.policy.ppo,
            K_review=cfg.controller.review_period_K_seconds,
            n_updates=cfg.policy.ppo.update_epochs,
            device=device,
        )
        wall = time.perf_counter() - t0

        log_rows.append({
            "update": update_idx,
            "episodes": args.episodes_per_update,
            "n_surge_episodes": n_surge,
            "mean_reward": float(np.mean(ep_rewards)),
            "mean_stockout_minutes": float(np.mean(ep_stockouts)),
            "mean_delivered": float(np.mean(ep_delivered)),
            "actor_loss": diag["actor_loss"],
            "critic_loss": diag["critic_loss"],
            "entropy": diag["entropy"],
            "n_transitions": diag["n_transitions"],
            "wall_seconds": wall,
        })
        print(f"{update_idx:>6d} | {args.episodes_per_update:>8d} | "
              f"{np.mean(ep_rewards):>11.2f} | "
              f"{np.mean(ep_stockouts):>13.3f} | "
              f"{np.mean(ep_delivered):>13.1f} | "
              f"{diag['actor_loss']:>10.4f} | {diag['critic_loss']:>11.4f} | "
              f"{wall:>6.1f}s")

        # Periodically save
        if (update_idx + 1) % 5 == 0 or update_idx == args.updates - 1:
            torch.save({
                "model_state_dict": ac.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "config_path": str(args.config),
                "update_idx": update_idx,
            }, args.output)

    # Save final log
    with open(args.log_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=log_rows[0].keys())
        writer.writeheader()
        writer.writerows(log_rows)
    print(f"\n[ DONE ] Saved policy to {args.output} and log to {args.log_csv}")


if __name__ == "__main__":
    main()
