"""Evaluate a trained policy across multiple seeds and write a CSV.

Parallel structure to ``run_overall.py``: loads a saved checkpoint, runs N
seeds under the chosen config, and dumps results to a CSV. Used to compare
the proposed policy against the Stage-4 baselines.

Usage:
    python experiments/eval_policy.py --policy policies/proposed.pt \
        --config configs/surge.yaml --seeds 5 --output results/eval_surge.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import torch                                                  # noqa: E402

from common.config import Config                              # noqa: E402
from common.controller import Controller, ControllerOutput    # noqa: E402
from world.simulator import Simulator                         # noqa: E402
from shield.prioritized import PrioritizedShield              # noqa: E402

from policy import (                                          # noqa: E402
    ActorCritic, RLController,
    GLOBAL_FEAT_DIM, ROBOT_FEAT_DIM, JOB_FEAT_DIM, PAIR_FEAT_DIM,
)


class _Stub(Controller):
    name = "stub"
    def decide(self, s):
        return ControllerOutput([], {})


def _make_sim(cfg, seed):
    sim = Simulator(cfg=cfg, controller=_Stub(), seed=seed)
    sim.reset()
    sh = PrioritizedShield(
        cfg=cfg.shield, grid=sim.grid,
        slot_size=cfg.controller.slot_size_delta_seconds,
    )
    sh.cfg.shield_repair_budget_slots = cfg.controller.shield_repair_budget_slots
    sim.shield = sh
    return sim


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy", type=Path, required=True,
                        help="Path to the saved .pt checkpoint")
    parser.add_argument("--config", type=Path, default=Path("configs/base.yaml"))
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--episode-seconds", type=float, default=2400.0)
    parser.add_argument("--max-slots-per-pair", type=int, default=4)
    parser.add_argument("--output", type=Path, default=Path("results/eval_results.csv"))
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--training-mode", action="store_true",
                        help="Sample noisy actions instead of using means (for debugging)")
    args = parser.parse_args()

    cfg = Config.from_yaml(args.config)
    cfg.experiment.episode_horizon_seconds = args.episode_seconds
    device = torch.device(args.device)

    # Build the actor-critic and load weights
    ac = ActorCritic(
        global_in_dim=GLOBAL_FEAT_DIM,
        robot_in_dim=ROBOT_FEAT_DIM,
        job_in_dim=JOB_FEAT_DIM,
        pair_in_dim=PAIR_FEAT_DIM,
        cfg=cfg.policy,
    ).to(device)
    checkpoint = torch.load(args.policy, map_location=device, weights_only=False)
    ac.load_state_dict(checkpoint["model_state_dict"])
    ac.eval()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    rows = []

    print(f"=== Evaluating {args.policy} on {args.config} "
          f"(horizon={args.episode_seconds:.0f}s, seeds={args.seeds}) ===")
    print(f"{'seed':>4s} | {'stockout':>9s} | {'delivered':>9s} | {'on-time':>7s} | "
          f"{'travel':>8s} | {'repairs':>7s} | {'rejected':>8s} | {'wall':>5s}")
    print("-" * 90)

    for seed in range(args.seeds):
        sim = _make_sim(cfg, seed)
        ctrl = RLController(
            cfg=cfg, actor_critic=ac, sim_handle=sim,
            device=str(device),
            training=args.training_mode,    # default: deterministic eval (mu)
            max_slots_per_pair=args.max_slots_per_pair,
        )
        sim.controller = ctrl; ctrl.reset()
        t0 = time.perf_counter()
        r = sim.run()
        wall = time.perf_counter() - t0

        rows.append({
            "method": "NeuroSymbolic",
            "seed": seed,
            "stockout_minutes": r.stockout_minutes,
            "delivered_total": r.delivered_total,
            "delivered_on_time": r.delivered_on_time,
            "on_time_ratio": r.on_time_ratio,
            "total_travel_m": r.total_travel_m,
            "total_energy": r.total_energy,
            "shield_repairs": r.shield_interventions,
            "shield_rejections": r.rejected_commitments,
            "wall_seconds": wall,
        })
        print(f"{seed:4d} | {r.stockout_minutes:9.2f} | {r.delivered_total:9d} | "
              f"{r.on_time_ratio:7.3f} | {r.total_travel_m:8.0f} | "
              f"{r.shield_interventions:7d} | {r.rejected_commitments:8d} | {wall:5.1f}s")

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nWrote {args.output}")


if __name__ == "__main__":
    main()
