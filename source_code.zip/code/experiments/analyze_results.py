"""Regenerate experiment summaries, paired intervals, LaTeX tables and figures.

Usage: python experiments/analyze_results.py --results primary_results --out analysis
Incomplete input is rejected unless --partial is explicitly supplied. The latter
only creates a progress summary and must not be used for manuscript estimates.
"""
import argparse,hashlib,json,math
from collections import Counter
from pathlib import Path
import numpy as np
import pandas as pd

BOOT=50000
MEASURES=['stockout_minutes','delivered_total','total_travel_m','total_energy',
          'shield_repairs','shield_rejections','mean_idle_rate','pooled_idle_rate',
          'critical_line_fraction','mean_candidate_pairs','max_candidate_pairs',
          'proposed','accepted','accepted_units','overflow_units','energy_deferrals',
          'milp_mean_ms','milp_p95_ms','milp_max_ms','wall_seconds']
AUDITS=['reservation_node_insert_conflicts','reservation_edge_insert_conflicts',
        'planned_drop_time_mismatches','missions_past_planned_completion_at_review']

def interval(x,key,seed=None):
    x=np.asarray(x,dtype=float)
    if seed is None:
        seed=int.from_bytes(hashlib.sha256(key.encode()).digest()[:8],'little')
    rng=np.random.default_rng(seed)
    means=x[rng.integers(0,len(x),(BOOT,len(x)))].mean(axis=1)
    lo,hi=np.quantile(means,[.025,.975])
    return dict(mean=float(x.mean()),lo=float(lo),hi=float(hi),n=len(x),sd=float(x.std(ddof=1)))

def tex_escape(s):return str(s).replace('_',r'\_')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--partial',action='store_true');args=ap.parse_args()
    args.out.mkdir(exist_ok=True,parents=True)
    jobs=[]
    for name in ['manifest.json','supplement_manifest.json','extra_baselines_manifest.json']:
        if args.partial and not (args.results/name).exists():continue
        jobs+=json.loads((args.results/name).read_text())
    expected=Counter((j['group'],j['k'],j['method']) for j in jobs)
    missing=[];rows=[]
    for j in jobs:
        p=args.results/(j['id']+'.json')
        if not p.exists():missing.append(j['id']);continue
        d=json.loads(p.read_text())
        if j['group']!='baseline':
            assert d.get('implementation_version')=='schedule-peak-occupancy',f"Wrong implementation version: {j['id']}"
        assert d['seed']==j['seed'] and d['method']==j['method'],j['id']
        for measure in ['stockout_minutes','total_travel_m','total_energy','wall_seconds','mean_idle_rate','pooled_idle_rate']:
            assert math.isfinite(d[measure]) and d[measure]>=0,(j['id'],measure)
        assert d['stockout_minutes']<=6*480+1e-9,(j['id'],'stockout exceeds six-line eight-hour horizon')
        assert d['delivered_total']==d['accepted_units']+d['overflow_units'],j['id']
        assert d['completed_audited_missions']==d['delivered_total'],(j['id'],'every completed mission must have a planned-time audit')
        assert 0<=d['accepted']<=d['proposed'],j['id']
        assert 0<=d['mean_idle_rate']<=1 and 0<=d['pooled_idle_rate']<=1,j['id']
        assert d['realized_min_battery']>=.1-1e-9,j['id']
        assert all(d[a]==0 for a in AUDITS),(j['id'],{a:d[a] for a in AUDITS})
        if d.get('candidate_metrics_applicable',True):
            assert 0<=d['uncovered_robot_epochs']<=d['eligible_robot_epochs'],j['id']
            assert d.get('solver_status_counts',{}).get('INFEASIBLE',0)==0,(j['id'],'inherited reservations must admit the zero-dispatch solution')
        d.update(group=j['group'],k=j['k'],episode_id=j['id'])
        d['pooled_admitted_idle_rate']=1-d.get('accepted_eligible_total',d['accepted'])/max(1,d['eligible_robot_epochs'])
        csv=args.results/(j['id']+'.epochs.csv')
        if not args.partial:
            assert csv.exists(),(j['id'],'missing per-epoch data')
        if csv.exists():
            ep=pd.read_csv(csv)
            assert int(ep.eligible.sum())==d['eligible_robot_epochs'],j['id']
            assert int(ep.proposed.sum())==d['proposed'] and int(ep.accepted.sum())==d['accepted'],j['id']
            ep=ep[ep.eligible>0]
            assert len(ep)==d['eligible_epochs'],j['id']
            accepted=ep.accepted_eligible if 'accepted_eligible' in ep.columns else ep.accepted
            proposed=ep.proposed_eligible if 'proposed_eligible' in ep.columns else ep.proposed
            assert ((0<=accepted)&(accepted<=proposed)&(proposed<=ep.eligible)).all(),(j['id'],'eligible counts')
            assert int(accepted.sum())==d.get('accepted_eligible_total',d['accepted']),(j['id'],'admitted eligible totals')
            assert abs(float((1-proposed/ep.eligible).mean())-d['mean_idle_rate'])<1e-12,(j['id'],'epoch-average idle rate')
            assert abs(float(1-proposed.sum()/ep.eligible.sum())-d['pooled_idle_rate'])<1e-12,(j['id'],'pooled idle rate')
            d['mean_admitted_idle_rate']=float(((ep.eligible-accepted)/ep.eligible).mean())
        d['config']=Path(d['config']).as_posix()
        rows.append(d)
    (args.out/'progress.json').write_text(json.dumps(dict(expected=len(jobs),complete=len(rows),missing=missing),indent=2))
    if missing and not args.partial:raise SystemExit(f'Incomplete campaign: {len(rows)}/{len(jobs)}. See progress.json.')
    df=pd.DataFrame(rows).sort_values(['group','k','method','seed'])
    df.to_csv(args.out/'episode_summary.csv',index=False)
    if missing or args.partial:return
    summaries=[]
    for key,g in df.groupby(['group','k','method'],sort=True):
        assert len(g)==expected[key],(key,len(g))
        for measure in MEASURES+['pooled_admitted_idle_rate']:
            if g[measure].isna().all():continue
            summaries.append(dict(group=key[0],k=key[1],method=key[2],measure=measure,**interval(g[measure],str(key)+measure)))
    pd.DataFrame(summaries).to_csv(args.out/'group_summary.csv',index=False)
    base=df[df.group=='base']
    pairs=[]
    def contrast(a,b,name,metric):
        joined=a[['seed',metric]].merge(b[['seed',metric]],on='seed',suffixes=('_a','_b'),validate='one_to_one')
        x=joined[metric+'_a']-joined[metric+'_b']
        ans=dict(contrast=name,measure=metric,**interval(x,name+metric));pairs.append(ans);return ans
    for a,b in [('120','80'),('160','80'),('160','120'),('240','160'),('UNPRUNED','240'),('240','80')]:
        for m in ['stockout_minutes','delivered_total','total_travel_m','shield_rejections']:
            contrast(base[base.k==a],base[base.k==b],f'base_{a}_minus_{b}',m)
    for name,g in df.groupby('group'):
        if name.startswith('weights_'):
            for m in ['stockout_minutes','total_travel_m']:
                contrast(g,base[(base.k=='80')&(base.seed<15)],name+'_minus_base80',m)
    for group in [g for g in df.group.unique() if g not in ['base','baseline','travel_relaxed'] and not g.startswith('weights_')]:
        g=df[df.group==group]
        contrast(g[g.k=='240'],g[g.k=='80'],group+'_240_minus_80','stockout_minutes')
    for k in ['80','240']:
        g=df[(df.group=='travel_relaxed')&(df.k==k)]
        contrast(base[(base.k==k)&(base.seed<15)],g,'shield_minus_relaxed_'+k,'stockout_minutes')
        contrast(base[(base.k==k)&(base.seed<15)],g,'shield_minus_relaxed_'+k,'delivered_total')
    for group in ['charge_half','charge_double','capacity_half']:
        contrast(df[(df.group==group)&(df.k=='240')],base[(base.k=='240')&(base.seed<15)],group+'_minus_base240','stockout_minutes')
    for method in ['Random','Reactive','FIFO','NearestRobot','UrgencyRank']:
        g=df[(df.group=='baseline')&(df.method==method)]
        for metric in ['stockout_minutes','total_travel_m']:
            contrast(g,base[base.k=='80'],'baseline_'+method+'_minus_base80',metric)
    for k in ['80','120','160','240','UNPRUNED']:
        for metric in ['stockout_minutes','total_travel_m']:
            contrast(df[(df.group=='baseline')&(df.method=='Reactive_Tight')],base[(base.k==k)&(base.seed<15)],'reactive_tight_minus_'+k,metric)
    for group in sorted(g for g in df.group.unique() if g.startswith('weights_')):
        for metric in ['stockout_minutes','total_travel_m']:
            contrast(df[(df.group=='baseline')&(df.method=='Reactive_Tight')],df[df.group==group],'reactive_tight_minus_'+group,metric)
    best_weight=df[df.group.str.startswith('weights_')].groupby('group').stockout_minutes.mean().idxmin()
    for method in ['Reactive','Reactive_Loose','UrgencyRank','UrgencyRank_Tight','UrgencyRank_Loose']:
        for metric in ['stockout_minutes','total_travel_m']:
            contrast(df[(df.group=='baseline')&(df.method==method)&(df.seed<15)],df[df.group==best_weight],'heuristic_'+method+'_minus_'+best_weight,metric)
    pd.DataFrame(pairs).to_csv(args.out/'paired_contrasts.csv',index=False)
    md=[r for r in pairs if r['contrast']=='base_UNPRUNED_minus_240' and r['measure']=='stockout_minutes'][0]
    shielded=df[df.group!='travel_relaxed']
    audit=dict(episodes=len(df),shielded_episodes=len(shielded),travel_relaxed_episodes=int((df.group=='travel_relaxed').sum()),
               shielded_completed=int(shielded.completed_audited_missions.sum()),
               admitted=int(df.accepted.sum()),completed=int(df.completed_audited_missions.sum()),
               minimum_battery=float(df.realized_min_battery.min()),
               audit_totals={a:int(df[a].sum()) for a in AUDITS},
               broad_minus_240=md,normal_approx_mde80=(1.95996398454+.84162123357)*md['sd']/math.sqrt(md['n']),
               bootstrap_replicates=BOOT)
    (args.out/'audit_summary.json').write_text(json.dumps(audit,indent=2))
    make_tables(df,pairs,args.out)
    make_figures(df,args.out)

def make_tables(df,pairs,out):
    def mean(g,m):return float(g[m].mean())
    def ci(g,m,key,digits=2):
        # Use the same group key as group_summary.csv and the figures.
        key=str((g.group.iloc[0],g.k.iloc[0],g.method.iloc[0]))
        q=interval(g[m],key+m);return f"{q['mean']:.{digits}f} [{q['lo']:.{digits}f}, {q['hi']:.{digits}f}]"
    def table(name,caption,label,cols,head,rows,note=''):
        text=r'\begin{table}[htbp]\centering\small\color{blue}'+'\n'+r'\caption{\rev{'+caption+'}}\n'+r'\label{'+label+'}\n'+r'\begin{adjustbox}{max width=\linewidth}\begin{tabular}{'+cols+'}\n'+r'\toprule'+'\n'+head+r'\\\midrule'+'\n'+'\n'.join(rows)+'\n'+r'\bottomrule\end{tabular}\end{adjustbox}'+'\n'
        if note:text+=r'\par\smallskip\begin{minipage}{0.98\linewidth}\footnotesize '+note+r'\end{minipage}'+'\n'
        text+=r'\end{table}'+'\n';(out/(name+'.tex')).write_text(text)
    base=df[df.group=='base'];ks=['80','120','160','240','UNPRUNED'];kn=lambda k:'Broad' if k=='UNPRUNED' else k
    rows=[]
    for k in ks:
        g=base[base.k==k]
        rows.append(f"{kn(k)} & {ci(g,'stockout_minutes','base'+k)} & {mean(g,'delivered_total'):.0f} & {mean(g,'total_travel_m')/1000:.1f} & {mean(g,'shield_rejections'):.0f} \\\\")
    table('main_table',r'Screening-preset comparison: schedule-based implementation, eight-hour episodes, 30 matched seeds. Stockout includes a marginal 95\% bootstrap interval.','tab:cliff','lrrrr','Preset & Stockout (min) & Completed & Travel (km) & Deferrals',rows,
          r'The 15-seed shield comparison in Table~\ref{tab:safety} uses seeds 0--14 from these 30 episodes; its sample means can differ.')
    rows=[]
    for a,b in [('120','80'),('160','80'),('160','120'),('240','160'),('UNPRUNED','240'),('240','80')]:
        q=next(q for q in pairs if q['contrast']==f'base_{a}_minus_{b}' and q['measure']=='stockout_minutes')
        rows.append(f"{kn(a)} minus {kn(b)} & {q['mean']:.2f} & [{q['lo']:.2f}, {q['hi']:.2f}] & "+('yes' if q['lo']>0 or q['hi']<0 else 'no')+r'\\')
    table('main_contrasts','Paired stockout contrasts (minutes), 30 matched seeds. Negative differences favor the first preset.','tab:cliffci','lrrl',r'Contrast & Mean difference & 95\% interval & Excludes zero?',rows)
    labels={'weights_alpha_half':r'$\alpha^M=5$','weights_alpha_double':r'$\alpha^M=20$','weights_beta_half':r'$\beta^M=0.5$','weights_beta_double':r'$\beta^M=2$','weights_nu_half':r'$\nu^M=0.25$','weights_nu_double':r'$\nu^M=1$','weights_penalty_double':r'$P_0=20000$'}
    rows=[];g0=base[(base.k=='80')&(base.seed<15)]
    rows.append('Reference & '+ci(g0,'stockout_minutes','ref15')+f" & {mean(g0,'total_travel_m')/1000:.1f} & --- \\\\")
    for name,label in labels.items():
        g=df[df.group==name];q=next(q for q in pairs if q['contrast']==name+'_minus_base80' and q['measure']=='stockout_minutes')
        rows.append(label+' & '+ci(g,'stockout_minutes',name)+f" & {mean(g,'total_travel_m')/1000:.1f} & {q['mean']:.2f} [{q['lo']:.2f}, {q['hi']:.2f}] \\\\")
    table('weight_table','Objective sensitivity at preset 80, 15 matched seeds. Each row changes only the displayed coefficient.','tab:weights','lrrr','Setting & Stockout (min) & Travel (km) & Paired stockout change',rows)
    def scenariotable(groups,name,label,caption):
        rows=[]
        for group,display in groups:
            vals=[]
            for k in ['80','160','240']:
                g=df[(df.group==group)&(df.k==k)&(df.seed<15)];vals.append(f"{mean(g,'stockout_minutes'):.2f}")
            if group=='base':
                a=base[(base.k=='240')&(base.seed<15)].sort_values('seed');b=base[(base.k=='80')&(base.seed<15)].sort_values('seed');q=interval(a.stockout_minutes.to_numpy()-b.stockout_minutes.to_numpy(),'base15_240_80')
            else:q=next(q for q in pairs if q['contrast']==group+'_240_minus_80')
            rows.append(display+' & '+' & '.join(vals)+f" & {q['mean']:.2f} [{q['lo']:.2f}, {q['hi']:.2f}] \\\\")
        table(name,caption,label,'lrrrr',r'Setting & 80 & 160 & 240 & 240 minus 80 [95\% CI]',rows)
    scenariotable([('base','Capacity 1'),('interface_2','Capacity 2'),('interface_3','Capacity 3')],'interface_table','tab:interfaces','Aggregate source/destination capacity sensitivity: mean stockout minutes, 15 matched seeds. Physical access nodes and blocking capacity are unchanged.')
    scenariotable([('base','Reference'),('charge_half',r'Recharge $0.5\gamma$'),('charge_double',r'Recharge $2\gamma$'),('capacity_half',r'Capacity $b^{\max}=0.5$')],'battery_table','tab:battery','Battery sensitivity: mean stockout minutes, 15 matched seeds. The absolute battery floor remains 0.1.')
    ofat=[('base','Base'),('fleet_8','Fleet 8'),('fleet_12','Fleet 12'),('fleet_15','Fleet 15'),('demand_low',r'Demand $0.5\lambda$'),('demand_high',r'Demand $1.5\lambda$'),('stackdepth_shallow','Shallow stacks'),('stackdepth_deep','Deep stacks'),('shield_1','Repair budget 1'),('shield_5','Repair budget 5'),('buffer_low','Small buffers'),('buffer_high','Large buffers')]
    scenariotable(ofat,'robust_table','tab:robust','OFAT results: mean stockout minutes and paired contrast, 15 matched seeds. Each factor changes independently; high demand holds fleet and buffers at base values.')
    rows=[]
    for method in ['Random','Reactive','FIFO','NearestRobot','UrgencyRank']:
        g=df[(df.group=='baseline')&(df.method==method)]
        rows.append(tex_escape(method)+' & '+ci(g,'stockout_minutes',method)+f" & {mean(g,'delivered_total'):.0f} & {mean(g,'total_travel_m')/1000:.1f} \\\\")
    g=base[base.k=='80']
    rows.append('MILPOnly (80) & '+ci(g,'stockout_minutes','base80')+f" & {mean(g,'delivered_total'):.0f} & {mean(g,'total_travel_m')/1000:.1f} \\\\")
    table('baseline_table','Main baseline comparison under the common schedule execution layer, 30 matched seeds.','tab:baselines','lrrr','Policy & Stockout (min) & Completed & Travel (km)',rows)
    rows=[]
    for method in ['Reactive','Reactive_Tight','Reactive_Loose','UrgencyRank','UrgencyRank_Tight','UrgencyRank_Loose']:
        g=df[(df.group=='baseline')&(df.method==method)&(df.seed<15)];rows.append(tex_escape(method)+f" & {mean(g,'stockout_minutes'):.2f} & {mean(g,'total_travel_m')/1000:.1f} & {mean(g,'accepted_units'):.0f} & {mean(g,'overflow_units'):.1f} \\\\")
    for k in ['80','120','160','240','UNPRUNED']:
        g=base[(base.k==k)&(base.seed<15)];rows.append('MILPOnly ('+kn(k)+f") & {mean(g,'stockout_minutes'):.2f} & {mean(g,'total_travel_m')/1000:.1f} & {mean(g,'accepted_units'):.0f} & {mean(g,'overflow_units'):.1f} \\\\")
    weight=df[df.group.str.startswith('weights_')]
    bestweight=weight.groupby('group').stockout_minutes.mean().idxmin();g=weight[weight.group==bestweight]
    rows.append('MILPOnly (80, '+labels[bestweight]+f") & {mean(g,'stockout_minutes'):.2f} & {mean(g,'total_travel_m')/1000:.1f} & {mean(g,'accepted_units'):.0f} & {mean(g,'overflow_units'):.1f} \\\\")
    table('tuned_table','Tuned threshold and urgency baselines, 15 matched seeds; matching MILP rows use the same first 15 main-study seeds.','tab:tuned','lrrrr','Policy & Stockout (min) & Travel (km) & Accepted units & Overflow',rows,
          'The final row is the weight setting with the lowest observed mean stockout in the local sweep. Its selection and comparison use the same seeds and are exploratory, not independent confirmation.')
    rows=[]
    for k in ['80','240']:
        for group,display in [('base','Shielded'),('travel_relaxed','Travel-relaxed')]:
            g=df[(df.group==group)&(df.k==k)&(df.seed<15)];rows.append(f"{k} & {display} & {mean(g,'stockout_minutes'):.2f} & {mean(g,'delivered_total'):.0f} & {mean(g,'total_travel_m')/1000:.1f} \\\\")
    table('safety_table','Travel-conflict ablation, 15 matched seeds (0--14 of the main study). The relaxation keeps service occupancy, event timing, and energy accounting.','tab:safety','llrrr','Preset & Execution & Stockout (min) & Completed & Travel (km)',rows)
    rows=[]
    for k in ks:
        g=base[base.k==k];den=g.eligible_robot_epochs.sum();uncovered=g.uncovered_robot_epochs.sum()/den
        rows.append(kn(k)+f" & {100*mean(g,'mean_idle_rate'):.1f} & {100*mean(g,'pooled_admitted_idle_rate'):.1f} & {100*uncovered:.2f} & {100*mean(g,'critical_line_fraction'):.1f} \\\\")
    table('idle_table','Dispatch mechanism measures, 30 matched seeds. All rates are percentages.','tab:idle','lrrrr','Preset & No proposal & No admission & No candidate & Critical buffers',rows,
          'No proposal is the mean across epochs with eligible idle robots; no admission is the episode-level pooled fraction of eligible robot-epochs without an admitted mission. No candidate uses pooled robot-epoch coverage. These measures exclude busy robots and are not fleet utilization.')
    rows=[]
    for group,k,n in [('base','80',30),('base','240',30),('fleet_15','80',15),('fleet_15','160',15),('fleet_15','240',15)]:
        g=df[(df.group==group)&(df.k==k)]
        rows.append(('Base' if group=='base' else 'Fleet 15')+f" / {k} & {n} & {int(g.completed_audited_missions.sum())} & {int(g.reservation_node_insert_conflicts.sum()+g.reservation_edge_insert_conflicts.sum())} & {int(g.planned_drop_time_mismatches.sum())} & {int(g.missions_past_planned_completion_at_review.sum())} \\\\")
    table('audit_table','Execution-invariant audit in the base and highest-fleet conditions. Counts aggregate across seeds.','tab:safety_audit','lrrrrr','Setting & $n$ & Completed & Conflicts & Timing errors & Overdue',rows,
          'Overdue counts active missions past their reserved completion at a review epoch. It is an execution-stall check under deterministic timing, not an observation of physical fleet deadlocks.')

def make_figures(df,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'blue','xtick.color':'blue','ytick.color':'blue','text.color':'blue','axes.edgecolor':'blue','savefig.bbox':'tight'})
    ks=['80','120','160','240','UNPRUNED'];base=df[df.group=='base'];x=np.arange(5)
    fig,ax=plt.subplots(1,2,figsize=(7,2.7),layout='constrained')
    for i,m in enumerate(['stockout_minutes','total_travel_m']):
        v=[interval(base[base.k==k][m],str(('base',k,'MILPOnly'))+m) for k in ks];scale=1000 if i else 1
        means=np.array([q['mean'] for q in v])/scale;lo=np.array([q['lo'] for q in v])/scale;hi=np.array([q['hi'] for q in v])/scale
        ax[i].errorbar(x,means,yerr=[means-lo,hi-means],fmt='o-',color='blue',capsize=3,lw=1.3)
        ax[i].set_xticks(x,['80','120','160','240','Broad']);ax[i].set_xlabel('Screening preset');ax[i].set_ylabel('Stockout (min)' if i==0 else 'Travel (km)');ax[i].grid(axis='y',alpha=.15)
    fig.savefig(out/'fig_cliff.pdf');fig.savefig(out/'fig_cliff.png',dpi=300);plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.7,2.6),layout='constrained')
    for m,label,fmt in [('mean_idle_rate','Eligible robots: no proposal','o-'),('pooled_admitted_idle_rate','Eligible robots: no admission','s--'),('critical_line_fraction','Critical line buffers','^:')]:
        ax.plot(x,[100*base[base.k==k][m].mean() for k in ks],fmt,color='blue',label=label)
    ax.set_xticks(x,['80','120','160','240','Broad']);ax.set_xlabel('Screening preset');ax.set_ylabel('Percentage');ax.legend(frameon=False,fontsize=8);ax.grid(axis='y',alpha=.15)
    fig.savefig(out/'p3_mech_diagnostic.pdf');fig.savefig(out/'p3_mech_diagnostic.png',dpi=300);plt.close(fig)

if __name__=='__main__':main()
