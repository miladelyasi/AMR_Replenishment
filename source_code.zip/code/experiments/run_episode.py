"""Matched-seed evaluation and invariant audit of the schedule-based simulator."""
import argparse
import csv
import json
import statistics
import numpy as np
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from common.config import Config
from common.controller import Controller, ControllerOutput
from world.schedule_simulator import ScheduleSimulator as Simulator
from world.eligibility import build_eligible_set
from baselines.milp_only import MILPOnlyController
from shield.prioritized import PrioritizedShield


class Stub(Controller):
    def decide(self, state):
        return ControllerOutput([], {})


def run(config, seed, output, overrides=None, horizon=None, method="MILPOnly"):
    from baselines.reactive import ReactiveThresholdController
    from baselines.fifo import FIFOController
    from baselines.nearest_robot import NearestRobotController
    from baselines.urgency_rank import UrgencyRankController
    from baselines.random_controller import RandomController
    cfg = Config.from_yaml(config)
    for key, value in (overrides or {}).items():
        obj = cfg
        parts = key.split('.')
        for part in parts[:-1]:
            obj = getattr(obj, part)
        setattr(obj, parts[-1], value)
    if horizon is not None:
        cfg.experiment.episode_horizon_seconds = horizon
    sim = Simulator(cfg, Stub(), seed=seed)
    sim.reset()
    if method == 'MILPOnly_TravelRelaxed':
        from shield.travel_relaxed import TravelRelaxedShield
        sh = TravelRelaxedShield(cfg.shield, sim.grid, cfg.controller.slot_size_delta_seconds)
    else:
        sh = PrioritizedShield(cfg.shield, sim.grid, cfg.controller.slot_size_delta_seconds)
    sh.cfg.shield_repair_budget_slots = cfg.controller.shield_repair_budget_slots
    sim.shield = sh
    cfg.milp.solver.threads=1
    constructors={"MILPOnly":lambda:MILPOnlyController(cfg,sim,max_slots_per_pair=1),
        "Reactive":lambda:ReactiveThresholdController(slot_size=5.),
        "Reactive_Tight":lambda:ReactiveThresholdController(slot_size=5.,safety_mult=1.5),
        "Reactive_Loose":lambda:ReactiveThresholdController(slot_size=5.,safety_mult=.7),
        "FIFO":lambda:FIFOController(slot_size=5.),
        "NearestRobot":lambda:NearestRobotController(slot_size=5.),
        "UrgencyRank":lambda:UrgencyRankController(slot_size=5.),
        "UrgencyRank_Tight":lambda:UrgencyRankController(slot_size=5.,urgency_horizon=60.),
        "UrgencyRank_Loose":lambda:UrgencyRankController(slot_size=5.,urgency_horizon=600.),
        "Random":lambda:RandomController(seed=seed)}
    ctrl=constructors['MILPOnly' if method == 'MILPOnly_TravelRelaxed' else method]()
    sim.controller = ctrl
    epochs = []
    stats = dict(reservation_node_insert_conflicts=0, reservation_edge_insert_conflicts=0,
                 planned_drop_time_mismatches=0, planned_drop_time_abs_error_sum=0.,
                 planned_drop_time_max_abs_error=0., completed_audited_missions=0,
                 missions_past_planned_completion_at_review=0)
    planned = {}
    raw_node = sh.table.reserve_node
    raw_edge = sh.table.reserve_edge
    def reserve_node(*args, **kwargs):
        answer = raw_node(*args, **kwargs)
        if not answer:
            stats['reservation_node_insert_conflicts'] += 1
        return answer
    def reserve_edge(*args, **kwargs):
        answer = raw_edge(*args, **kwargs)
        if not answer:
            stats['reservation_edge_insert_conflicts'] += 1
        return answer
    sh.table.reserve_node = reserve_node
    sh.table.reserve_edge = reserve_edge
    raw_plan = sh.plan
    def plan(*args, **kwargs):
        out = raw_plan(*args, **kwargs)
        for mission in out.accepted:
            planned[id(mission.commitment)] = mission.drop_done_time
        return out
    sh.plan = plan
    raw_drop = sim._handle_drop_done
    def drop(payload):
        target = planned.pop(id(payload['commitment']), None)
        if target is not None:
            delta = abs(sim.t_now - target)
            stats['completed_audited_missions'] += 1
            stats['planned_drop_time_abs_error_sum'] += delta
            stats['planned_drop_time_max_abs_error'] = max(stats['planned_drop_time_max_abs_error'], delta)
            if delta > 1e-6:
                stats['planned_drop_time_mismatches'] += 1
        return raw_drop(payload)
    sim._handle_drop_done = drop
    raw_solve = ctrl.milp.solve if hasattr(ctrl,"milp") else None
    candidate_info = {}
    solver_statuses = Counter()
    def solve(*args, **kwargs):
        feasible = kwargs['feasible']
        candidate_info['covered_robots'] = len({f.robot_id for f in feasible})
        candidate_info['pairs'] = len({(f.robot_id, f.job.key()) for f in feasible})
        result = raw_solve(*args, **kwargs)
        solver_statuses[result.status] += 1
        return result
    if hasattr(ctrl,"milp"):ctrl.milp.solve = solve
    raw_decide = ctrl.decide
    last_eligible = set()
    def decide(state):
        eligible = build_eligible_set(sim.robots, state,
            horizon_seconds=cfg.controller.tactical_horizon_H_seconds,
            battery_pre_filter_floor=cfg.world.robots.battery_pre_filter_floor,
            battery_min=cfg.world.robots.battery_min)
        eligible = [r for r in eligible if not state.commitment_busy[r]]
        last_eligible.clear()
        last_eligible.update(eligible)
        candidate_info.clear()
        out = raw_decide(state)
        n = len(eligible)
        assigned = len({c.robot_id for c in out.commitments})
        assigned_eligible = len({c.robot_id for c in out.commitments} & last_eligible)
        epochs.append(dict(epoch=state.epoch_index, time=state.epoch_time,
            eligible=n, proposed=assigned, proposed_eligible=assigned_eligible,
            candidates=out.diagnostics.get('num_candidates', 0),
            pairs=candidate_info.get('pairs', 0), covered_robots=candidate_info.get('covered_robots', 0),
            no_assignment_rate=(n-assigned_eligible)/n if n else None,
            min_battery=min(r.battery for r in sim.robots),
            critical_lines=int(sum(state.B <= state.S))))
        stats['missions_past_planned_completion_at_review'] += sum(
            r.current_commitment is not None and r.tau_free < sim.t_now-1e-6 for r in sim.robots)
        return out
    ctrl.decide = decide
    raw_apply = sim._apply_commitments_with_shield
    def apply(commitments):
        before = set(sim.active_missions)
        result = raw_apply(commitments)
        epochs[-1]['accepted'] = result[0]
        epochs[-1]['accepted_eligible'] = len((set(sim.active_missions)-before) & last_eligible)
        epochs[-1]['deferred'] = result[1]
        return result
    sim._apply_commitments_with_shield = apply
    start = time.perf_counter()
    result = sim.run()
    eligible_epochs = [e for e in epochs if e['eligible']]
    row = dict(seed=seed, method=method, config=str(config), overrides=overrides or {},
        stockout_minutes=result.stockout_minutes, delivered_total=result.delivered_total,
        total_travel_m=result.total_travel_m, total_energy=result.total_energy,
        shield_repairs=result.shield_interventions, shield_rejections=result.rejected_commitments,
        wall_seconds=time.perf_counter()-start,
        eligible_epochs=len(eligible_epochs), eligible_robot_epochs=sum(e['eligible'] for e in epochs),
        mean_idle_rate=statistics.mean(e['no_assignment_rate'] for e in eligible_epochs) if eligible_epochs else 0,
        pooled_idle_rate=sum(e['eligible']-e['proposed_eligible'] for e in epochs)/max(1,sum(e['eligible'] for e in epochs)),
        mean_candidate_pairs=statistics.mean(e['pairs'] for e in epochs),
        max_candidate_pairs=max(e['pairs'] for e in epochs),
        uncovered_robot_epochs=sum(e['eligible']-e['covered_robots'] for e in epochs),
        proposed=sum(e['proposed'] for e in epochs), accepted=sum(e['accepted'] for e in epochs),
        accepted_eligible_total=sum(e['accepted_eligible'] for e in epochs),
        critical_line_fraction=sum(e['critical_lines'] for e in epochs)/(len(epochs)*cfg.world.num_lines),
        milp_mean_ms=statistics.mean(e.milp_solve_ms for e in result.epoch_records),
        milp_max_ms=max(e.milp_solve_ms for e in result.epoch_records),
        milp_p95_ms=float(np.quantile([e.milp_solve_ms for e in result.epoch_records],.95)),
        min_battery=min(e['min_battery'] for e in epochs), realized_min_battery=sim.min_battery_observed, energy_deferrals=sim.energy_deferrals, accepted_units=sim.buffer_accepted_units, overflow_units=sim.buffer_overflow_units, **stats)
    row['candidate_metrics_applicable'] = hasattr(ctrl, 'milp')
    row['solver_status_counts'] = dict(solver_statuses)
    row['implementation_version'] = 'schedule-peak-occupancy'
    if not row['candidate_metrics_applicable']:
        for key in ['mean_candidate_pairs','max_candidate_pairs','uncovered_robot_epochs']:
            row[key] = None
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.with_suffix('.epochs.csv').write_text('')
    with output.with_suffix('.epochs.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(epochs[0]))
        writer.writeheader()
        writer.writerows(epochs)
    output.write_text(json.dumps(row, indent=2))
    print(json.dumps(row), flush=True)
    return row


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--config', required=True)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--out', required=True)
    p.add_argument('--overrides', default='{}')
    p.add_argument('--horizon', type=float)
    p.add_argument('--method',default='MILPOnly')
    a = p.parse_args()
    run(a.config, a.seed, a.out, json.loads(a.overrides), a.horizon, a.method)
