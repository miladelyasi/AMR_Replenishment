"""Validate and summarize the complete Absolute screening/weight extension."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd

sys.path.insert(0,str(Path(__file__).resolve().parent))
from analyze_results import interval, AUDITS
PRESETS=['80','120','160','240','UNPRUNED']
CONTRASTS=[('120','80'),('160','80'),('160','120'),('240','160'),('UNPRUNED','240'),('240','80')]
LABEL=lambda k:'Broad' if str(k)=='UNPRUNED' else str(k)


def write_screening_summary(absolute, reference, out):
 metrics=['stockout_minutes','delivered_total','accepted_units','overflow_units',
          'total_travel_m','shield_rejections']
 summary=[]; tex=[]
 for policy,frame in [('Absolute',absolute),('Reference',reference)]:
  if policy=='Reference':tex.append(r'\midrule')
  for k in PRESETS:
   part=frame[frame.preset==k].sort_values('seed')
   assert part.seed.tolist()==list(range(30))
   assert (part.delivered_total==part.accepted_units+part.overflow_units).all()
   key=str(('base',k,'MILPOnly'))+'stockout_minutes' if policy=='Reference' else f'joint:b1.0:k{k}:stockout'
   ci=interval(part.stockout_minutes,key)
   row=dict(preset=k,stopping=policy,n=30,**{m:float(part[m].mean()) for m in metrics},
            stockout_lo=ci['lo'],stockout_hi=ci['hi'])
   summary.append(row)
   tex.append(f"{LABEL(k)} & {policy} & {row['stockout_minutes']:.2f} [{ci['lo']:.2f}, {ci['hi']:.2f}] & "
              f"{row['delivered_total']:.0f} & {row['accepted_units']:.1f} & {row['overflow_units']:.1f} & "
              f"{row['total_travel_m']/1000:.1f} & {row['shield_rejections']:.0f} "+r'\\')
 pd.DataFrame(summary).to_csv(out/'screening_summary.csv',index=False)
 table=r'''\begin{table}[H]\centering\footnotesize\color{blue}
\caption{\rev{Complete screening comparison: reference objective weights, eight-hour episodes, 30 matched seeds per preset and stopping policy. Stockout includes a marginal 95\% bootstrap interval. Absolute uses zero relative tolerance, absolute tolerance $10^{-6}$, and a 5-s limit; Reference uses 2\% relative tolerance and a 150-ms limit. Accepted and overflow units use the same 30 seeds as the other measures.}}
\label{tab:cliff}
\setlength{\tabcolsep}{3pt}
\begin{adjustbox}{max width=\linewidth}\begin{tabular}{llrrrrrr}
\toprule Preset & Stopping & \makecell{Stockout (min)\\{}[95\% CI]} & Completed & Accepted & Overflow & \makecell{Travel\\(km)} & Deferrals\\\midrule
'''+ '\n'.join(tex)+r'''
\bottomrule\end{tabular}\end{adjustbox}
\par\smallskip\begin{minipage}{0.98\linewidth}\footnotesize The 15-seed shield comparison in Table~\ref{tab:safety} uses seeds 0--14 from the Reference rows. Absolute reuses 45 episodes from Appendix~\ref{sec:app_stopping} and adds 105 episodes; reused records are not counted twice. Completed missions equal accepted plus overflow units in each episode; displayed means are rounded.\end{minipage}
\end{table}
'''
 (out/'screening_table.tex').write_text(table)


def main():
 p=argparse.ArgumentParser()
 p.add_argument('--results',type=Path,required=True)
 p.add_argument('--stopping',type=Path,required=True)
 p.add_argument('--reference',type=Path,required=True)
 p.add_argument('--out',type=Path,required=True)
 a=p.parse_args(); a.out.mkdir(parents=True,exist_ok=True)
 manifest=json.loads((a.results/'manifest.json').read_text())
 assert manifest['new_executions']==165 and manifest['reused_executions']==45
 rows=[]; gaps=[]; audit=Counter(); n_new=0
 for job in manifest['jobs']:
  k,beta,seed=job['k'],job['beta'],job['seed']
  reuse=beta==1 and k in ['80','240','UNPRUNED'] and seed<15
  path=(a.stopping/f'absolute_k{k}_s{seed:02d}.json' if reuse else
        a.results/f'absolute_b{beta:g}_k{k}_s{seed:02d}.json')
  d=json.loads(path.read_text()); assert d['seed']==seed
  assert d['config']==f'configs/sweep/base__base__k{k}.yaml'
  assert d['overrides'].get('milp.weights.beta_M',1.)==beta
  assert d['delivered_total']==d['accepted_units']+d['overflow_units']==d['completed_audited_missions']
  assert all(d[n]==0 for n in AUDITS)
  assert d['realized_min_battery']>=.1-1e-9
  assert d['solver_status_counts'].get('INFEASIBLE',0)==0
  assert 'OPTIMAL' in d['solver_status_counts'] and not d['solver_status_counts'].get('TIME_LIMIT',0)
  epochs=pd.read_csv(path.with_suffix('.epochs.csv'))
  assert len(epochs)==5761 and epochs.time.max()==28800
  assert int(epochs.proposed.sum())==d['proposed']
  assert int(epochs.accepted.sum())==d['accepted']
  g=pd.read_csv(path.with_suffix('.gaps.csv'))
  assert len(g)>0 and (g.status==2).all()
  assert len(g)==d['solver_status_counts']['OPTIMAL']
  assert g.absolute_gap.max()<=1e-6+1e-12
  gaps.append(dict(preset=k,beta=beta,seed=seed,calls=len(g),
                   maximum_absolute_gap=g.absolute_gap.max(),maximum_solver_ms=g.solver_ms.max(),
                   new_execution=not reuse))
  if not reuse:
   n_new+=1
   audit.update({n:d[n] for n in AUDITS})
  d.update(preset=k,beta=beta,source=str(path),reused=reuse)
  rows.append(d)
 assert n_new==165 and len(rows)==210
 fields=['preset','beta','seed','stockout_minutes','delivered_total','total_travel_m',
         'accepted_units','overflow_units','shield_rejections','total_energy','wall_seconds',
         'controller_mean_ms','review_mean_ms','realized_min_battery','completed_audited_missions','reused','source']
 df=pd.DataFrame(rows)[fields]
 df.to_csv(a.out/'episodes.csv',index=False)
 pd.DataFrame(gaps).to_csv(a.out/'gap_audit.csv',index=False)
 means=[]
 for (k,beta),part in df.groupby(['preset','beta']):
  r=dict(preset=k,beta=beta,n=len(part))
  for metric in fields[3:16]:
   if metric not in ['reused','source']:r[metric]=float(part[metric].mean())
  r.update(stockout_ci=interval(part.stockout_minutes,f'joint:b{beta}:k{k}:stockout'))
  means.append(r)
 reference=[]
 for k in PRESETS:
  for seed in range(30):
   d=json.loads((a.reference/f'base_k{k}_MILPOnly_s{seed:02d}.json').read_text())
   reference.append(dict(preset=k,seed=seed,**{m:d[m] for m in ['stockout_minutes','delivered_total','accepted_units','overflow_units','total_travel_m','shield_rejections']}))
 ref=pd.DataFrame(reference)
 write_screening_summary(df[df.beta==1],ref,a.out)
 contrasts=[]
 for policy,frame in [('Absolute',df[df.beta==1]),('Reference',ref)]:
  for x,y in CONTRASTS:
   left=frame[frame.preset==x].set_index('seed').stockout_minutes
   right=frame[frame.preset==y].set_index('seed').stockout_minutes
   assert left.index.equals(right.index)
   key=f'base_{x}_minus_{y}stockout_minutes' if policy=='Reference' else f'joint:{policy}:{x}-{y}'
   contrasts.append(dict(policy=policy,left=x,right=y,**interval(left-right,key)))
 weight=[]
 for k in ['80','160','240','UNPRUNED']:
  one=df[(df.preset==k)&(df.beta==1)&(df.seed<15)].set_index('seed')
  two=df[(df.preset==k)&(df.beta==2)].set_index('seed')
  assert one.index.equals(two.index)
  for metric in ['stockout_minutes','total_travel_m','accepted_units','overflow_units']:
   weight.append(dict(preset=k,metric=metric,left_beta=2,right_beta=1,
                      **interval(two[metric]-one[metric],f'joint:weight:{k}:{metric}')))
 for x,y in [('160','80'),('240','80'),('UNPRUNED','240')]:
  left=df[(df.preset==x)&(df.beta==2)].set_index('seed')
  right=df[(df.preset==y)&(df.beta==2)].set_index('seed')
  for metric in ['stockout_minutes','total_travel_m','accepted_units','overflow_units']:
   weight.append(dict(preset=f'{x}-{y}',metric=metric,left_beta=2,right_beta=2,
                      **interval(left[metric]-right[metric],f'joint:beta2:{x}-{y}:{metric}')))
 pd.DataFrame(contrasts).to_csv(a.out/'screening_contrasts.csv',index=False)
 pd.DataFrame(weight).to_csv(a.out/'weight_contrasts.csv',index=False)
 pd.DataFrame([{k:v for k,v in r.items() if k!='stockout_ci'} for r in means]).to_csv(a.out/'means.csv',index=False)
 new=df[~df.reused]
 summary=dict(new_executions=165,reused_executions=45,total_executions=1700,
              new_audited_completions=int(new.completed_audited_missions.sum()),audit_counters=dict(audit),
              minimum_battery=float(new.realized_min_battery.min()),
              maximum_absolute_gap=float(max(r['maximum_absolute_gap'] for r in gaps)),
              absolute_solve_calls=int(sum(r['calls'] for r in gaps)),time_limits=0,
              means=means,screening_contrasts=contrasts,weight_contrasts=weight)
 (a.out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 # The figure presents the complete screening comparison under both policies.
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(10.8,3.5))
 x=np.arange(5)
 for policy,frame,style in [('Absolute',df[df.beta==1],'o-'),('Reference',ref,'s--')]:
  mid=[]; low=[]; high=[]; travel=[]
  for k in PRESETS:
   part=frame[frame.preset==k]
   key=str(('base',k,'MILPOnly'))+'stockout_minutes' if policy=='Reference' else f'joint:b1.0:k{k}:stockout'
   ci=interval(part.stockout_minutes,key)
   mid.append(ci['mean']);low.append(ci['mean']-ci['lo']);high.append(ci['hi']-ci['mean'])
   travel.append(part.total_travel_m.mean()/1000)
  axes[0].errorbar(x,mid,yerr=[low,high],fmt=style,capsize=3,label=policy)
  axes[1].plot(x,travel,style,label=policy)
 for ax in axes:
  ax.set_xticks(x,[LABEL(k) for k in PRESETS]);ax.set_xlabel('Screening preset');ax.grid(alpha=.22);ax.legend()
 axes[0].set_ylabel('Stockout (min)');axes[1].set_ylabel('Travel (km)')
 fig.tight_layout();fig.savefig(a.out/'fig_cliff.png',dpi=220);plt.close(fig)
 print(json.dumps({k:summary[k] for k in ['new_executions','reused_executions','new_audited_completions','maximum_absolute_gap','time_limits']},indent=2))

if __name__=='__main__':main()
