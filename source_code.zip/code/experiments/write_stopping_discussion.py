"""Generate numerical stopping-study paragraphs from audited analysis records."""
import argparse
import json
from pathlib import Path
import pandas as pd

def write(analysis, out):
    out.mkdir(parents=True, exist_ok=True)
    means=pd.read_csv(analysis/'stopping_means.csv',dtype={'preset':str})
    contrasts=pd.read_csv(analysis/'stopping_contrasts.csv')
    gaps=pd.read_csv(analysis/'gap_summary.csv',dtype={'preset':str})
    cover=pd.read_csv(analysis/'coverage_summary.csv',dtype={'preset':str})
    snapshots=pd.read_csv(analysis/'snapshot_summary.csv',dtype={'preset':str})
    audit=json.loads((analysis/'stopping_summary.json').read_text())
    def m(policy,k,key):return float(means[(means.policy==policy)&(means.preset==k)].iloc[0][key])
    def c(name):
        row=contrasts[(contrasts.contrast==name)&(contrasts.measure=='stockout_minutes')].iloc[0]
        return f"${row['mean']:.2f}\\,[{row['lo']:.2f},{row['hi']:.2f}]$"
    def save(name,text): (out/name).write_text('\\begingroup\\color{blue}\n'+text.strip()+'\n\\endgroup\n')
    main=rf'''Tables~\ref{{tab:stopping_episodes}} and~\ref{{tab:stopping_contrasts}} show that stopping materially changes the operational contrasts. Broad's mean stockout falls from {m('reference','UNPRUNED','stockout_minutes'):.2f} to {m('absolute','UNPRUNED','stockout_minutes'):.2f} minutes; Absolute minus Reference is {c('absolute_minus_reference_UNPRUNED')} minutes. The 240-minus-80 difference changes from {c('reference_240_minus_80')} to {c('absolute_240_minus_80')}, while Broad minus 240 changes from {c('reference_Broad_minus_240')} to {c('absolute_Broad_minus_240')}. Preset 240 retains the lowest mean among these three configurations, but the magnitude of Broad's deterioration is sensitive to stopping. It cannot be attributed to candidate breadth independently of solution accuracy and the stated time allowance.

Every Absolute solve attains the prescribed absolute tolerance, with no time-limit termination (Table~\ref{{tab:stopping_gaps}}). Its mean full-review latency ranges from {m('absolute','80','review_mean_ms'):.2f} to {m('absolute','UNPRUNED','review_mean_ms'):.2f}~ms in this campaign. Lower or similar average latency despite tighter stopping reflects the resulting state sequences and concurrent execution, not a general complexity result. These measurements do not impose a hard real-time deadline.

The absolute policy lowers stockout and travel but increases overflow at every preset. For Broad, mean accepted units rise from {m('reference','UNPRUNED','accepted_units'):.1f} to {m('absolute','UNPRUNED','accepted_units'):.1f}, while overflow rises from {m('reference','UNPRUNED','overflow_units'):.1f} to {m('absolute','UNPRUNED','overflow_units'):.1f}. Appendix~\ref{{sec:app_stopping}} connects these outcomes to line coverage, admitted allocation, and same-state objective quality. More accurate tactical optimization does not remove the per-job incentive to propose deliveries without accounting for arrival-time headroom. The remaining sensitivity studies use the reference stopping rule; this experiment does not validate their effect sizes under Absolute. Section~\ref{{sec:accurate_dispatch}} separately extends the fixed-policy comparison with BatchGreedy to Absolute stopping.'''
    save('stopping_results.tex',main)
    ag=gaps[gaps.policy=='absolute']
    audittext=rf'''Across the {int(ag.calls.sum()):,} nonempty Absolute solves, the largest achieved absolute gap is ${ag.max_absolute_gap.max():.2e}$ cost units, below $10^{{-6}}$; no solve reaches its 5-s limit. The largest reported relative gap is below $2\times10^{{-16}}$. The largest optimizer runtime is {ag.max_solver_ms.max():.2f}~ms, whereas the largest full review is {ag.max_review_ms.max():.2f}~ms. Reference solves also avoid time-limit termination here but can stop with much larger absolute gaps. The four operational audit counters remain zero over {audit['audited_completed_missions']:,} completed missions, every line-level material-balance residual is zero, and the battery floor holds within $10^{{-9}}$.

The instrumented reference replays match the primary stockout outcomes in 41 of 45 episodes. The four differing primary episodes each had one time-limit termination; none occurs in these reference replays. Their means are therefore reported separately. This distinction also prevents the 15-seed diagnostic estimates from being confused with the 30-seed main means.'''
    # Write powers in conventional LaTeX instead of programming notation.
    value=f'{ag.max_absolute_gap.max():.2e}'
    mantissa,exponent=value.split('e')
    audittext=audittext.replace(value,mantissa+r'\times10^{'+str(int(exponent))+'}')
    save('stopping_audit.tex',audittext)
    cr=cover[(cover.policy=='reference')&(cover.preset=='UNPRUNED')].iloc[0]
    ca=cover[(cover.policy=='absolute')&(cover.preset=='UNPRUNED')].iloc[0]
    coverage=rf'''Broad under Reference has {int(cr.critical):,} critical line-epochs, including {int(cr.omitted)} screening omissions and no observation without accessible compatible stock. Thus widespread omission of urgent lines is not observed, although these counts do not isolate the downstream effect of an individual omission. There are {int(cr.no_feasible):,} critical line-epochs without a retained feasible robot alternative; eligibility and mission filtering are distinct from retaining a line's job. Under Absolute, critical line-epochs fall to {int(ca.critical):,}, with no screening omissions. The two policies generate different states, so their coverage counts are descriptive rather than an ablation of screening alone.

Broad's mean admission fraction rises from {m('reference','UNPRUNED','admission_percent'):.1f}\% to {m('absolute','UNPRUNED','admission_percent'):.1f}\%. Table~\ref{{tab:stopping_allocation}} shows that accepted and overflow units rise at every line. Proposals to currently full buffers increase from {100*cr.full_buffer_proposed/cr.all_proposed:.1f}\% to {100*ca.full_buffer_proposed/ca.all_proposed:.1f}\% of all proposals. These observations describe the joint change in selection, admission, and redundant supply; they do not identify an independent causal contribution of routing, battery availability, or buffer-headroom omission.'''
    save('stopping_allocation_results.tex',coverage)
    sr=snapshots[snapshots.policy=='reference'];sa=snapshots[snapshots.policy=='absolute']
    objective=rf'''Under Reference, the MILP returns a worse tactical objective than the feasible BatchGreedy assignment in {int(sr.worse.sum())} of {int(sr.snapshots.sum())} sampled states. The relative certificate therefore does not establish even greedy-level objective quality in every state. Under Absolute, the MILP improves the objective in {int(sa.better.sum())} of {int(sa.snapshots.sum())} states, ties within $10^{{-6}}$ in the remaining {int(sa.tied.sum())}, and is never worse. Median advantage is zero in every cell. Mean improvements under Absolute range from {sa.mean_advantage.min():.2f} to {sa.mean_advantage.max():.2f} cost units; their practical value is not determined by this arbitrary objective scale.

Mean assignment-construction time in the Absolute snapshots is {sa.mean_milp_ms.min():.2f}--{sa.mean_milp_ms.max():.2f}~ms for the MILP and {sa.mean_greedy_ms.min():.2f}--{sa.mean_greedy_ms.max():.2f}~ms for BatchGreedy. These same-state results distinguish the optimizer's tactical improvement from its computational cost. They compare decisions at identical states, whereas Section~\ref{{sec:accurate_dispatch}} separately evaluates Absolute MILP and BatchGreedy in complete episodes at the two fixed comparator settings.'''
    save('stopping_objective_results.tex',objective)
    response=rf'''We find that Broad's mean stockout changes from {m('reference','UNPRUNED','stockout_minutes'):.2f} to {m('absolute','UNPRUNED','stockout_minutes'):.2f} minutes; the paired change is {c('absolute_minus_reference_UNPRUNED')}. Broad minus 240 falls from {c('reference_Broad_minus_240')} to {c('absolute_Broad_minus_240')}. Preset 240 retains the lowest mean, but the magnitude is not robust to stopping. Every Absolute solve meets $10^{{-6}}$, with no time-limit termination. We therefore qualify the screening conclusion by both objective settings and solver stopping. The two policies also differ in their allowed time budget.'''
    (out/'summary_stopping.tex').write_text(response+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--analysis',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();write(args.analysis,args.out)
