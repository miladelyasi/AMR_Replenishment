"""Prespecified full-episode stopping-policy and line-allocation diagnostic.

Reference: MIPGap=.02, TimeLimit=.15 s. Absolute: MIPGap=0,
MIPGapAbs=1e-6 objective units, TimeLimit=5 s. Both retain ObjCon.
Seeds 0--14, presets 80/240/UNPRUNED, reference weights, eight-hour episodes.
BatchGreedy shadow decisions at eight fixed times never enter the simulator.
"""
import argparse
from collections import Counter
import csv
import json
from pathlib import Path
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'experiments'))
import run_episode as runner
from baselines.milp_only import MILPOnlyController
from tactical.milp import TacticalMILP
from tactical.feasibility import build_job_set
from extension_validation import BatchResourceGreedy, validate_greedy_assignment

SNAPSHOT_TIMES = (0, 300, 1800, 3600, 7200, 14400, 21600, 27900)

def centered_objective(engine, solution, state, feasible, score_field):
    chosen = {(c.robot_id, c.job.key(), c.start_slot) for c in solution.commitments}
    weights = engine.cfg.weights
    return sum(weights.alpha_M * f.risk + weights.beta_M * (f.travel_to_tote + f.travel_to_line)
               + weights.nu_M * f.energy + weights.xi_M * f.crowd
               - weights.varrho * score_field.get((f.robot_id, f.job.line_id, f.job.tote_id), 0.)
               - weights.P_0 / max(float(state.hat_T_so[f.job.line_id]), 1e-3)
               for f in feasible if (f.robot_id, f.job.key(), f.start_slot) in chosen)

class TraceMILP(TacticalMILP):
    def __init__(self, *args, policy, **kw):
        super().__init__(*args, **kw)
        self.policy = policy
        self.calls, self.snapshots = [], []
        self.targets = iter(SNAPSHOT_TIMES)
        self.next_target = next(self.targets)
        self.diagnostic_seconds = 0.
        self.last_candidates = Counter()
        self.greedy = BatchResourceGreedy(self.cfg, self.num_slots, self.slot_size)

    def _build_model(self):
        model = super()._build_model()
        if self.policy == 'absolute':
            model.Params.MIPGap = 0.
            model.Params.MIPGapAbs = 1e-6
            model.Params.TimeLimit = 5.
        return model

    def _extract_solution(self, model, x, v, feasible, jobs, epoch_time, runtime_ms):
        solution = super()._extract_solution(model, x, v, feasible, jobs, epoch_time, runtime_ms)
        row = dict(time=epoch_time, jobs=len(jobs), triples=len(feasible), status=model.Status,
                   solutions=model.SolCount, runtime_ms=runtime_ms, solver_ms=1000 * model.Runtime,
                   constant=model.ObjCon, objective=None, bound=None, absolute_gap=None, relative_gap=None)
        if model.SolCount:
            row.update(objective=model.ObjVal, bound=model.ObjBound,
                       absolute_gap=abs(model.ObjVal-model.ObjBound), relative_gap=model.MIPGap)
        self.calls.append(row)
        return solution

    def solve(self, **kw):
        state = kw['state']
        t0 = time.perf_counter()
        self.last_candidates = Counter(f.job.line_id for f in kw['feasible'])
        self.diagnostic_seconds += time.perf_counter()-t0
        start = time.perf_counter()
        solution = super().solve(**kw)
        solve_ms = 1000 * (time.perf_counter()-start)
        if state.epoch_time >= self.next_target and kw['feasible']:
            start = time.perf_counter()
            greedy = self.greedy.solve(**kw)
            greedy_ms = 1000 * (time.perf_counter()-start)
            checked_rows = validate_greedy_assignment(self.greedy, greedy, **kw)
            milp_cost = centered_objective(self, solution, state, kw['feasible'], kw['score_field'])
            greedy_cost = centered_objective(self, greedy, state, kw['feasible'], kw['score_field'])
            keys = lambda s: {(c.robot_id, c.job.key(), c.start_slot) for c in s.commitments}
            self.snapshots.append(dict(target=self.next_target, time=state.epoch_time,
                milp_centered=milp_cost, greedy_centered=greedy_cost,
                milp_advantage=greedy_cost-milp_cost, milp_ms=solve_ms, greedy_ms=greedy_ms,
                changed_assignments=len(keys(solution)^keys(greedy)),
                milp_commitments=len(solution.commitments), greedy_commitments=len(greedy.commitments),
                greedy_checked_rows=checked_rows))
            self.next_target = next(self.targets, float('inf'))
            self.diagnostic_seconds += time.perf_counter()-start
        return solution

def write_csv(path, rows):
    if not rows:
        return
    with path.open('w') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def run(policy, k, seed, out, horizon=None):
    rows, timing, instance = [], [], {}
    def factory(cfg, sim, max_slots_per_pair):
        ctrl = MILPOnlyController(cfg, sim, max_slots_per_pair=max_slots_per_pair)
        engine = TraceMILP(cfg.milp, ctrl.num_slots, ctrl.slot_size, policy=policy)
        ctrl.milp = engine
        instance.update(sim=sim, engine=engine)
        initial = [int(b.level) for b in sim.buffers]
        served, accepted, overflow, completed = Counter(), Counter(), Counter(), Counter()
        instance.update(initial=initial, served=served, accepted=accepted, overflow=overflow, completed=completed)
        raw_consume = sim._handle_consumption
        def consume(lid):
            if sim.buffers[lid].level > 0:
                served[lid] += 1
            return raw_consume(lid)
        sim._handle_consumption = consume
        raw_drop = sim._handle_drop_done
        def drop(payload):
            lid = payload['commitment'].job.line_id
            a, o = sim.buffer_accepted_units, sim.buffer_overflow_units
            result = raw_drop(payload)
            accepted[lid] += sim.buffer_accepted_units-a
            overflow[lid] += sim.buffer_overflow_units-o
            completed[lid] += 1
            return result
        sim._handle_drop_done = drop
        raw_decide = ctrl.decide
        current = []
        def decide(state):
            start = time.perf_counter()
            accessible = {lid for (lid, uid), good in state.sku_compat.items()
                          if good and int(state.access.get(uid, 0)) in [1, 2]}
            screened = Counter(j.line_id for j in build_job_set(state, cfg.controller.candidate_pruning))
            incoming = Counter(m.commitment.job.line_id for m in sim.active_missions.values())
            current.clear()
            for lid in state.line_ids:
                current.append(dict(time=state.epoch_time, line=int(lid), buffer=float(state.B[lid]),
                    critical=int(state.hat_T_so[lid] <= cfg.controller.urgency_T_crit_seconds),
                    accessible=int(lid in accessible), screened_jobs=screened[lid], incoming=incoming[lid]))
            engine.last_candidates.clear()
            engine.diagnostic_seconds += time.perf_counter()-start
            before_diagnostic = engine.diagnostic_seconds
            start = time.perf_counter()
            output = raw_decide(state)
            controller_ms = 1000 * (time.perf_counter()-start-(engine.diagnostic_seconds-before_diagnostic))
            start = time.perf_counter()
            proposed = Counter(c.job.line_id for c in output.commitments)
            for r in current:
                r.update(feasible=engine.last_candidates[r['line']], proposed=proposed[r['line']], accepted=0)
            rows.extend(current)
            timing.append(dict(time=state.epoch_time, controller_ms=controller_ms))
            engine.diagnostic_seconds += time.perf_counter()-start
            return output
        ctrl.decide = decide
        raw_apply = sim._apply_commitments_with_shield
        def apply(commitments):
            start = time.perf_counter()
            before = set(sim.active_missions)
            engine.diagnostic_seconds += time.perf_counter()-start
            result = raw_apply(commitments)
            start = time.perf_counter()
            counts = Counter(sim.active_missions[r].commitment.job.line_id for r in set(sim.active_missions)-before)
            for row in current:
                row['accepted'] = counts[row['line']]
            engine.diagnostic_seconds += time.perf_counter()-start
            return result
        sim._apply_commitments_with_shield = apply
        raw_review = sim._handle_review
        def review():
            diagnostic_start = engine.diagnostic_seconds
            start = time.perf_counter()
            result = raw_review()
            elapsed = time.perf_counter()-start-(engine.diagnostic_seconds-diagnostic_start)
            timing[-1]['review_ms'] = 1000 * elapsed
            return result
        sim._handle_review = review
        return ctrl
    runner.MILPOnlyController = factory
    row = runner.run(f'configs/sweep/base__base__k{k}.yaml', seed, out, horizon=horizon)
    sim, engine = instance['sim'], instance['engine']
    line_totals = []
    for lid, buffer in enumerate(sim.buffers):
        total = dict(line=lid, initial=instance['initial'][lid], final=int(buffer.level),
            served_consumption=instance['served'][lid], accepted_units=instance['accepted'][lid],
            overflow_units=instance['overflow'][lid], completed=instance['completed'][lid])
        total['balance_residual'] = total['initial']+total['accepted_units']-total['served_consumption']-total['final']
        assert total['balance_residual'] == 0
        line_totals.append(total)
    row.update(stopping_policy=policy, preset=str(k), line_totals=line_totals,
        diagnostic_seconds=engine.diagnostic_seconds, operational_wall_seconds=row['wall_seconds']-engine.diagnostic_seconds,
        review_mean_ms=float(np.mean([t['review_ms'] for t in timing])),
        review_p95_ms=float(np.quantile([t['review_ms'] for t in timing], .95)),
        review_max_ms=max(t['review_ms'] for t in timing),
        controller_mean_ms=float(np.mean([t['controller_ms'] for t in timing])))
    assert sum(t['accepted_units'] for t in line_totals) == row['accepted_units']
    assert sum(t['overflow_units'] for t in line_totals) == row['overflow_units']
    out = Path(out)
    out.write_text(json.dumps(row, indent=2))
    write_csv(out.with_suffix('.gaps.csv'), engine.calls)
    write_csv(out.with_suffix('.lines.csv'), rows)
    write_csv(out.with_suffix('.timing.csv'), timing)
    out.with_suffix('.snapshots.json').write_text(json.dumps(engine.snapshots, indent=2))
    return row

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--policy', choices=['reference', 'absolute'], required=True)
    parser.add_argument('--k', required=True)
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--horizon', type=float)
    args = parser.parse_args()
    run(args.policy, args.k, args.seed, args.out, args.horizon)
