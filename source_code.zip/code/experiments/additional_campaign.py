"""Additional objective-energy and travel-conflict-ablation experiments."""
import concurrent.futures as cf
import json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'primary_results';OUT.mkdir(exist_ok=True)
jobs=[]
for name,method,overrides,ks in [
    ('weights_nu_half','MILPOnly',{'milp.weights.nu_M':.25},[80]),
    ('weights_nu_double','MILPOnly',{'milp.weights.nu_M':1.},[80]),
    ('travel_relaxed','MILPOnly_TravelRelaxed',{},[80,240])]:
    for k in ks:
        for seed in range(15):
            jobs.append(dict(id=f'{name}_k{k}_{method}_s{seed:02d}',group=name,method=method,k=str(k),seed=seed,overrides=overrides,config=f'configs/sweep/base__base__k{k}.yaml'))
(OUT/'supplement_manifest.json').write_text(json.dumps(jobs,indent=2))
def one(j):
    target=OUT/(j['id']+'.json')
    if target.exists():return j['id'],'cached'
    cmd=[sys.executable,str(ROOT/'experiments/run_episode.py'),'--config',j['config'],'--seed',str(j['seed']),'--out',str(target),'--overrides',json.dumps(j['overrides']),'--method',j['method']]
    with (OUT/(j['id']+'.log')).open('w') as f:
        result=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
    return j['id'],'done' if result.returncode==0 else 'ERROR'
if __name__=='__main__':
    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        for n,r in enumerate(pool.map(one,jobs),1):print(n,len(jobs),r,flush=True)
