"""Execute the predeclared 65-episode technical-validation design."""
import concurrent.futures as cf,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'technical_results';OUT.mkdir(exist_ok=True)
jobs=[dict(kind='gap',k=k,seed=0) for k in ['80','120','160','240','UNPRUNED']]
jobs += [dict(kind=kind,k=k,seed=seed) for seed in range(30,45) for k in ['80','240'] for kind in ['milp','greedy']]
(OUT/'manifest.json').write_text(json.dumps(jobs,indent=2))
def one(j):
    stem=f"{j['kind']}_k{j['k']}_s{j['seed']:02d}";target=OUT/(stem+'.json')
    if target.exists():return stem,'cached'
    cmd=[sys.executable,'experiments/technical_validation.py','--kind',j['kind'],'--k',j['k'],'--seed',str(j['seed']),'--out',str(target)]
    with (OUT/(stem+'.log')).open('w') as f:
        r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
    return stem,r.returncode
if __name__=='__main__':
    with cf.ThreadPoolExecutor(max_workers=int(sys.argv[1]) if len(sys.argv)>1 else 4) as pool:
        for n,r in enumerate(pool.map(one,jobs),1):print(n,len(jobs),r,flush=True)
