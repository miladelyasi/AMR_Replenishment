"""Preserve 30 replications for the five main baseline policies.

Seeds 0--14 are in primary_campaign.py; this driver adds seeds 15--29.
The four tuned variants remain 15-seed comparisons.
"""
import concurrent.futures as cf
import json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'primary_results';OUT.mkdir(exist_ok=True)
jobs=[]
for method in ['Random','Reactive','FIFO','NearestRobot','UrgencyRank']:
    for seed in range(15,30):
        jobs.append(dict(id=f'baseline_k80_{method}_s{seed:02d}',group='baseline',method=method,k='80',seed=seed,overrides={},config='configs/sweep/base__base__k80.yaml'))
(OUT/'extra_baselines_manifest.json').write_text(json.dumps(jobs,indent=2))
def one(j):
    target=OUT/(j['id']+'.json')
    if target.exists():return j['id'],'cached'
    with (OUT/(j['id']+'.log')).open('w') as f:
        r=subprocess.run([sys.executable,str(ROOT/'experiments/run_episode.py'),'--config',j['config'],'--seed',str(j['seed']),'--out',str(target),'--method',j['method']],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
    return j['id'],'done' if r.returncode==0 else 'ERROR'
if __name__=='__main__':
    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        for n,r in enumerate(pool.map(one,jobs),1):print(n,len(jobs),r,flush=True)
