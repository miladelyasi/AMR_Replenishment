"""Complete Absolute screening and fixed beta=2 cross-preset evaluation.

Uses the unchanged operational model and identical gap/timing hooks. Reference
weights are evaluated on seeds 0--29, beta=2 on seeds 0--14. No retuning occurs.
"""
import argparse
import json
from pathlib import Path
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'experiments'))
import run_episode as runner
from baselines.milp_only import MILPOnlyController
from accurate_dispatch_validation import AbsoluteMILP
from stopping_validation import write_csv


def run(k, beta, seed, out, horizon=None):
    instance, timing = {}, []
    def factory(cfg, sim, max_slots_per_pair):
        ctrl = MILPOnlyController(cfg, sim, max_slots_per_pair=max_slots_per_pair)
        engine = AbsoluteMILP(cfg.milp, ctrl.num_slots, ctrl.slot_size, policy='absolute')
        ctrl.milp = engine
        instance['engine'] = engine
        raw_decide = ctrl.decide
        def decide(state):
            start = time.perf_counter()
            result = raw_decide(state)
            timing.append(dict(time=state.epoch_time,
                               controller_ms=1000 * (time.perf_counter()-start)))
            return result
        ctrl.decide = decide
        raw_review = sim._handle_review
        def review():
            start = time.perf_counter()
            result = raw_review()
            timing[-1]['review_ms'] = 1000 * (time.perf_counter()-start)
            return result
        sim._handle_review = review
        return ctrl
    runner.MILPOnlyController = factory
    overrides = {'milp.weights.beta_M': float(beta)}
    row = runner.run(f'configs/sweep/base__base__k{k}.yaml', seed, out, overrides, horizon)
    row.update(study='joint_stopping', stopping_policy='absolute', preset=str(k), beta_M=beta,
               controller_mean_ms=float(np.mean([r['controller_ms'] for r in timing])),
               review_mean_ms=float(np.mean([r['review_ms'] for r in timing])),
               review_p95_ms=float(np.quantile([r['review_ms'] for r in timing], .95)),
               review_max_ms=max(r['review_ms'] for r in timing))
    out = Path(out)
    out.write_text(json.dumps(row, indent=2))
    write_csv(out.with_suffix('.timing.csv'), timing)
    write_csv(out.with_suffix('.gaps.csv'), instance['engine'].calls)
    return row


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--k', required=True, choices=['80','120','160','240','UNPRUNED'])
    p.add_argument('--beta', type=float, required=True, choices=[1.,2.])
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--horizon', type=float)
    a = p.parse_args()
    run(a.k, a.beta, a.seed, a.out, a.horizon)
