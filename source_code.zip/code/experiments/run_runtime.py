"""Section 5.7 — Computational Performance.

Measures end-to-end latency per decision epoch, broken out into:

* MILP build time
* MILP solve time (and frequency of hitting the wall-clock limit)
* Shield planning time
* Total controller latency

Reports both nominal and stressed (under demand surge) latencies.

Usage
-----
    python experiments/run_runtime.py --seeds 5 --warmup_seconds 600
"""

from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("configs/base.yaml"))
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--warmup_seconds", type=float, default=600.0,
                        help="Skip metrics from the first ``warmup_seconds`` of each episode.")
    parser.add_argument("--out_dir", type=Path, default=Path("results/runtime"))
    args = parser.parse_args()
    raise NotImplementedError("Implement after run_overall.py is working.")


if __name__ == "__main__":
    main()
