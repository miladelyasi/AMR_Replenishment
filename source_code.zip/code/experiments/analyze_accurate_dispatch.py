"""Audit and reproduce the focused closed-loop Absolute/BatchGreedy comparison."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from analyze_results import interval, AUDITS
from analyze_stopping import ci, table

METRICS = ['stockout_minutes', 'total_travel_m', 'accepted_units', 'overflow_units', 'controller_mean_ms']
OPERATIONAL = ['stockout_minutes', 'delivered_total', 'total_travel_m', 'total_energy',
    'shield_repairs', 'shield_rejections', 'eligible_epochs', 'eligible_robot_epochs',
    'mean_idle_rate', 'pooled_idle_rate', 'mean_candidate_pairs', 'max_candidate_pairs',
    'uncovered_robot_epochs', 'proposed', 'accepted', 'accepted_eligible_total',
    'critical_line_fraction', 'min_battery', 'realized_min_battery', 'energy_deferrals',
    'accepted_units', 'overflow_units', 'completed_audited_missions'] + AUDITS

def analyze(results, extension, technical, out):
    out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((results/'manifest.json').read_text())
    expected = {(p,k,s) for p in ['absolute','batch'] for k in ['80','240'] for s in range(30,45)}
    assert {(j['policy'],j['k'],j['seed']) for j in manifest['jobs']} == expected
    assert len(manifest['jobs']) == 60 and manifest['horizon_seconds'] == 28800
    rows, audits, replays = [], [], []
    gap_frames = {}
    for job in manifest['jobs']:
        p,k,s = job['policy'], job['k'], job['seed']
        stem = f'{p}_k{k}_s{s:02d}'
        row = json.loads((results/(stem+'.json')).read_text())
        assert (row['dispatch_policy'], row['preset'], row['seed']) == (p,k,s)
        assert row['overrides'] == ({'milp.weights.beta_M':2.} if k == '80' else {})
        assert all(row[m] == 0 for m in AUDITS)
        assert row['realized_min_battery'] >= .1-1e-9
        assert row['delivered_total'] == row['accepted_units']+row['overflow_units'] == row['completed_audited_missions']
        epochs = pd.read_csv(results/(stem+'.epochs.csv'))
        times = pd.read_csv(results/(stem+'.timing.csv'))
        assert epochs.time.max() == 28800 and len(epochs) == len(times)
        assert np.allclose(epochs.time, times.time)
        assert (times[['controller_ms','review_ms']] >= 0).all().all()
        assert epochs.proposed.sum() == row['proposed'] and epochs.accepted.sum() == row['accepted']
        assert np.isclose(row['controller_mean_ms'], times.controller_ms.mean())
        audit = dict(policy=p,preset=k,seed=s,review_mean_ms=float(times.review_ms.mean()),
            review_p95_ms=float(times.review_ms.quantile(.95)),review_max_ms=float(times.review_ms.max()))
        if p == 'absolute':
            gaps = pd.read_csv(results/(stem+'.gaps.csv'))
            assert len(gaps) == sum(row['solver_status_counts'].values())
            assert (gaps.solutions > 0).all()
            assert (gaps.absolute_gap >= 0).all() and (gaps.absolute_gap <= 1e-6).all()
            assert not (gaps.status == 9).any()
            assert np.allclose(gaps.absolute_gap, abs(gaps.objective-gaps.bound), atol=1e-7, rtol=0)
            gap_frames[(k,s)] = gaps
            audit.update(calls=len(gaps), max_gap=float(gaps.absolute_gap.max()), time_limits=int((gaps.status == 9).sum()))
        else:
            old = json.loads((extension/f'batch_k{k}_p1_s{s:02d}.json').read_text())
            mismatches = [m for m in OPERATIONAL if row[m] != old[m]]
            assert not mismatches, (stem, mismatches)
            # Timing is new; every operational per-epoch field is unchanged.
            old_epochs = pd.read_csv(extension/f'batch_k{k}_p1_s{s:02d}.epochs.csv')
            pd.testing.assert_frame_equal(epochs, old_epochs, check_exact=True)
            replays.append(dict(preset=k,seed=s,metrics=len(OPERATIONAL),exact_match=True,epochs=len(epochs)))
        rows.append(row); audits.append(audit)
    df = pd.DataFrame(rows)
    df.to_csv(out/'accurate_dispatch_episodes.csv',index=False)
    pd.DataFrame(audits).to_csv(out/'review_audit_by_episode.csv',index=False)
    pd.DataFrame(replays).to_csv(out/'batch_replay_equivalence.csv',index=False)
    means, contrasts, reference_contrasts, gap_summary = [], [], [], []
    for k in ['80','240']:
        for p in ['absolute','batch']:
            g = df[(df.preset==k)&(df.dispatch_policy==p)].sort_values('seed')
            assert g.seed.tolist() == list(range(30,45))
            means.append(dict(policy=p,preset=k,n=15,**{m:float(g[m].mean()) for m in METRICS+['review_mean_ms','review_p95_ms','review_max_ms','milp_mean_ms']}))
        a = df[(df.preset==k)&(df.dispatch_policy=='absolute')].sort_values('seed')
        b = df[(df.preset==k)&(df.dispatch_policy=='batch')].sort_values('seed')
        for m in METRICS+['review_mean_ms']:
            contrasts.append(dict(preset=k,measure=m,**interval(a[m].to_numpy()-b[m].to_numpy(),f'accurate_dispatch_absolute_minus_batch_{k}_{m}')))
        # Reuse the stored Reference records only as a separate operational contrast.
        ref = [json.loads((technical/f'milp_k{k}_s{s:02d}.json').read_text()) for s in range(30,45)]
        assert [r['seed'] for r in ref] == list(range(30,45))
        for m in METRICS[:4]:
            reference_contrasts.append(dict(preset=k,measure=m,**interval(a[m].to_numpy()-np.array([r[m] for r in ref]),f'accurate_dispatch_absolute_minus_reference_{k}_{m}')))
        gaps = pd.concat([gap_frames[(k,s)] for s in range(30,45)])
        gap_summary.append(dict(preset=k,calls=len(gaps),max_gap=float(gaps.absolute_gap.max()),time_limits=int((gaps.status==9).sum()),max_solver_ms=float(gaps.solver_ms.max())))
    for name,data in [('accurate_dispatch_means',means),('accurate_dispatch_contrasts',contrasts),('reference_contrasts',reference_contrasts),('gap_summary',gap_summary)]:
        pd.DataFrame(data).to_csv(out/(name+'.csv'),index=False)
    summary = dict(episodes=60,new_absolute_episodes=30,instrumented_batch_replays=30,
        all_batch_replays_exact=True,replay_metrics=len(OPERATIONAL),
        completed_missions=int(df.completed_audited_missions.sum()),
        audit_totals={m:int(df[m].sum()) for m in AUDITS},
        min_battery=float(df.realized_min_battery.min()),
        absolute_calls=sum(r['calls'] for r in gap_summary),max_absolute_gap=max(r['max_gap'] for r in gap_summary),
        absolute_time_limits=sum(r['time_limits'] for r in gap_summary),
        max_review_ms=float(df.review_max_ms.max()), scope='Matched extension on already examined seeds 30--44; not independent confirmation')
    (out/'accurate_dispatch_summary.json').write_text(json.dumps(summary,indent=2))
    lines=[]
    for r in means:
        lines.append(f"{r['preset']} & {'Absolute' if r['policy']=='absolute' else 'BatchGreedy'} & {r['stockout_minutes']:.3f} & {r['total_travel_m']/1000:.2f} & {r['accepted_units']:.1f} & {r['overflow_units']:.1f} & {r['controller_mean_ms']:.2f}")
    tex=table(r'Matched closed-loop extension on seeds 30--44: preset 80 uses $\beta^M=2$ and preset 240 uses reference weights. Absolute retains the objective constant and uses zero relative tolerance, $10^{-6}$ absolute tolerance, and a 5-s limit. Controller time covers screening, feasibility construction, and assignment; complete review latency is reported in Appendix~\ref{sec:app_accurate_dispatch}.',
        'tab:accurate_dispatch','llrrrrr',r'Preset & Policy & Stockout & Travel & Accepted & Overflow & Controller\\ & & (min) & (km) & (units) & (units) & (ms)',lines,True)
    scales=[1,1000,1,1,1]
    labels=['Stockout (min)','Travel (km)','Accepted units','Overflow units','Controller time (ms)']
    contrast_lines=[]
    for m,scale,label in zip(METRICS,scales,labels):
        vals=[next(r for r in contrasts if r['preset']==k and r['measure']==m) for k in ['80','240']]
        formatted=[]
        for r in vals:
            if m == 'stockout_minutes' and r['preset'] == '240':
                formatted.append(f"{r['mean']:.3f} [{r['lo']:.3f}, {r['hi']:.3f}]")
            else:
                formatted.append(ci(r,scale))
        contrast_lines.append(label+' & '+' & '.join(formatted))
    second=table(r'Paired Absolute-minus-BatchGreedy differences in the matched extension (15 seeds, pointwise 95\% bootstrap intervals). These already examined seeds do not provide independent confirmation.',
        'tab:accurate_dispatch_contrasts','lrr',r'Measure & Preset 80 [95\% CI] & Preset 240 [95\% CI]',contrast_lines,True)
    (out/'accurate_dispatch_table.tex').write_text(tex.replace('[H]','[htbp]'))
    (out/'accurate_dispatch_contrasts.tex').write_text(second.replace('[H]','[htbp]'))
    lines=[f"{r['preset']} & {'Absolute' if r['policy']=='absolute' else 'BatchGreedy'} & {r['review_mean_ms']:.2f} & {r['review_p95_ms']:.2f} & {r['review_max_ms']:.2f}" for r in means]
    # Display maximum across calls, not the mean of episode maxima.
    for i,r in enumerate(means):
        g=df[(df.preset==r['preset'])&(df.dispatch_policy==r['policy'])]
        lines[i]=lines[i].rsplit(' & ',1)[0]+f" & {g.review_max_ms.max():.2f}"
    (out/'accurate_dispatch_latency.tex').write_text(table(r'Complete review latency in the matched extension. Mean and 95th percentile are averaged across the 15 episodes; maximum is over all reviews in the cell. State construction, controller work, trajectory admission, and event bookkeeping are included.',
        'tab:accurate_dispatch_latency','llrrr',r'Preset & Policy & Mean (ms) & Mean 95th (ms) & Maximum (ms)',lines,True))
    print(json.dumps(summary,indent=2))

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    for name in ['results','extension','technical','out']:p.add_argument('--'+name,required=True,type=Path)
    a=p.parse_args();analyze(a.results,a.extension,a.technical,a.out)
