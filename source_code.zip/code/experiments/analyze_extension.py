"""Analyze the 105-episode physical-port and dispatch-comparator study."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyze_results import interval, AUDITS


def ci(row, scale=1.):
    return f"{row['mean']/scale:.2f} [{row['lo']/scale:.2f}, {row['hi']/scale:.2f}]"


def analyze(primary, technical, extension, out, dispatch_only=False):
    out.mkdir(exist_ok=True, parents=True)
    name = 'manifest_comparators.json' if (extension/'manifest_comparators.json').exists() else 'manifest.json'
    jobs = json.loads((extension/name).read_text())
    if not dispatch_only:
        jobs += json.loads((extension/'manifest_ports.json').read_text())
    assert Counter(j['kind'] for j in jobs) == ({'batch':30, 'urgency':15} if dispatch_only else {'batch':30, 'urgency':15, 'ports':60})
    rows = []
    for job in jobs:
        stem = f"{job['kind']}_k{job['k']}_p{job['ports']}_s{job['seed']:02d}"
        d = json.loads((extension/(stem+'.json')).read_text())
        assert d['seed'] == job['seed'] and d['preset'] == job['k'] and d['extension_kind'] == job['kind']
        assert all(d[key] == 0 for key in AUDITS)
        assert d['realized_min_battery'] >= .1-1e-9
        assert d['delivered_total'] == d['accepted_units'] + d['overflow_units'] == d['completed_audited_missions']
        assert d.get('solver_status_counts', {}).get('INFEASIBLE', 0) == 0
        epochs = pd.read_csv(extension/(stem+'.epochs.csv'))
        assert epochs.proposed.sum() == d['proposed'] and epochs.accepted.sum() == d['accepted']
        d.update(ports=job['ports'], kind=job['kind'], episode_id=stem)
        d['admission_rate'] = d['accepted']/max(1,d['proposed'])
        if job['kind'] == 'ports':
            audit = d['port_audit']
            assert audit['ports_per_line'] == job['ports']
            assert d['overrides']=={'world.interfaces.src_capacity':1,'world.interfaces.dst_capacity':job['ports']}
            assert all(v['peak']<=1 for v in audit['physical_ports'].values())
            assert all(v['peak']<=job['ports'] for v in audit['line_groups'].values())
            assert audit['max_group_occupancy']==job['ports'] and audit['parallel_line_seconds']>0
            ports = pd.read_csv(extension/(stem+'.ports.csv'))
            assert len(ports) == d['accepted']
            assert np.allclose(ports.end-ports.start, 10/1.2, rtol=0, atol=1e-8)
            # Independent interval audit from raw accepted mission records.
            for (_, y), records in ports.groupby(['line','port_y']):
                ordered=records.sort_values('start')
                assert np.all(ordered.start.to_numpy()[1:] >= ordered.end.to_numpy()[:-1]-1e-9)
            for lid, records in ports.groupby('line'):
                active=peak=0
                for _, change in sorted([(v,1) for v in records.start]+[(v,-1) for v in records.end]):
                    active+=change;peak=max(peak,active)
                assert active==0 and peak==audit['line_groups'][str(lid)]['peak']<=job['ports']
                assert set(records.port_y)<={cell[1] for cell in audit['coordinates'][str(lid)]}
            d['parallel_line_seconds']=audit['parallel_line_seconds']
        rows.append(d)
    pd.DataFrame(rows).to_csv(out/'extension_episodes.csv',index=False)
    stats=['stockout_minutes','total_travel_m','overflow_units','accepted_units','admission_rate']
    means,contrasts=[],[]
    fresh={}
    for k in ['80','240']:
        fresh[('milp',k)]=[json.loads((technical/f'milp_k{k}_s{s:02d}.json').read_text()) for s in range(30,45)]
        fresh[('batch',k)]=sorted([r for r in rows if r['kind']=='batch' and r['preset']==k],key=lambda r:r['seed'])
    fresh[('urgency','80')]=sorted([r for r in rows if r['kind']=='urgency'],key=lambda r:r['seed'])
    for (kind,k),g in fresh.items():
        assert [r['seed'] for r in g]==list(range(30,45))
        means.append(dict(kind=kind,preset=k,n=15,**{m:float(np.mean([r[m] if m!='admission_rate' else r['accepted']/max(1,r['proposed']) for r in g])) for m in stats}))
    for k in ['80','240']:
        for other in ['batch','urgency']:
            a=fresh[('milp',k)];b=fresh[(other,k if other=='batch' else '80')]
            for measure in stats[:3]:
                contrasts.append(dict(preset=k,other=other,measure=measure,
                    **interval([x[measure]-y[measure] for x,y in zip(a,b)],f'extension_milp_minus_{other}_k{k}_{measure}')))
    pd.DataFrame(means).to_csv(out/'dispatch_means.csv',index=False)
    pd.DataFrame(contrasts).to_csv(out/'dispatch_contrasts.csv',index=False)
    tex=[r'\begin{table}[H]\centering\small\color{blue}',
         r'\caption{\rev{Fixed-policy evaluation on fresh seeds 30--44. BatchGreedy shares the MILP alternatives, objective coefficients, and tactical inequalities. UrgencyRank retains its complete heuristic configuration. MILP 80 uses $\beta^M=2$; MILP 240 uses reference weights. Both MILP settings use the reference 2\% stopping tolerance.}}',
         r'\label{tab:batch_validation}',r'\begin{tabular}{llrrr}',
         r'\toprule Preset & Policy & Stockout (min) & Travel (km) & Overflow\\\midrule']
    for kind,k in [('milp','80'),('batch','80'),('milp','240'),('batch','240'),('urgency','80')]:
        d=next(r for r in means if r['kind']==kind and r['preset']==k)
        name={'milp':'MILP','batch':'BatchGreedy','urgency':'UrgencyRank'}[kind]
        tex.append(f"{'---' if kind=='urgency' else k} & {name} & {d['stockout_minutes']:.3f} & {d['total_travel_m']/1000:.2f} & {d['overflow_units']:.1f}"+r' \\')
    tex += [r'\bottomrule\end{tabular}',r'\par\medskip',r'\begin{adjustbox}{max width=\linewidth}\begin{tabular}{llrrr}',
            r'\toprule\multicolumn{5}{l}{Paired MILP-minus-comparator differences [95\% CI]}\\',
            r'Preset & Comparator & Stockout (min) & Travel (km) & Overflow\\\midrule']
    for k in ['80','240']:
        for other in ['batch','urgency']:
            values=[next(r for r in contrasts if r['preset']==k and r['other']==other and r['measure']==m) for m in stats[:3]]
            tex.append(k+' & '+('BatchGreedy' if other=='batch' else 'UrgencyRank')+' & '+' & '.join(ci(r,1000 if i==1 else 1) for i,r in enumerate(values))+r' \\')
    tex += [r'\bottomrule\end{tabular}\end{adjustbox}',r'\end{table}']
    (out/'batch_table.tex').write_text('\n'.join(tex)+'\n')
    if dispatch_only:
        return
    port_data, port_means, port_contrasts = {},[],[]
    for p in [1,2,3]:
        for k in ['80','240']:
            g=([json.loads((primary/f'base_k{k}_MILPOnly_s{s:02d}.json').read_text()) for s in range(15)] if p==1 else sorted([r for r in rows if r['kind']=='ports' and r['ports']==p and r['preset']==k],key=lambda r:r['seed']))
            assert [r['seed'] for r in g]==list(range(15))
            port_data[(p,k)]=g
            port_means.append(dict(ports=p,preset=k,n=15,**{m:float(np.mean([r[m] if m!='admission_rate' else r['accepted']/max(1,r['proposed']) for r in g])) for m in stats},parallel_line_seconds=0. if p==1 else float(np.mean([r['parallel_line_seconds'] for r in g]))))
        diffs=[a['stockout_minutes']-b['stockout_minutes'] for a,b in zip(port_data[(p,'240')],port_data[(p,'80')])]
        key='base15_240_80' if p==1 else f'physicalports{p}_240_minus_80'
        port_contrasts.append(dict(contrast='240_minus_80',ports=p,preset='both',**interval(diffs,key)))
    for p in [2,3]:
        for k in ['80','240']:
            diffs=[a['stockout_minutes']-b['stockout_minutes'] for a,b in zip(port_data[(p,k)],port_data[(1,k)])]
            port_contrasts.append(dict(contrast='ports_minus_1',ports=p,preset=k,**interval(diffs,f'physicalports{p}_minus1_k{k}')))
    for k in ['80','240']:
        diffs=[a['stockout_minutes']-b['stockout_minutes'] for a,b in zip(port_data[(3,k)],port_data[(2,k)])]
        port_contrasts.append(dict(contrast='3_minus_2',ports=3,preset=k,**interval(diffs,f'physicalports3_minus2_k{k}')))
    pd.DataFrame(port_means).to_csv(out/'port_means.csv',index=False)
    pd.DataFrame(port_contrasts).to_csv(out/'port_contrasts.csv',index=False)
    tex=[r'\begin{table}[H]\centering\small\color{blue}',
         r'\caption{\rev{Usable physical delivery ports: 15 matched seeds per cell, with reference objective weights at both presets. Each line has a common buffer and one, two, or three distinct access nodes; source and blocking capacity remain one. One-port rows reuse the corresponding primary-design seeds.}}',
         r'\label{tab:physical_ports}',r'\begin{tabular}{llrrrr}',
         r'\toprule Ports/line & Preset & Stockout (min) & Travel (km) & Overflow & Admitted (\%)\\\midrule']
    for d in port_means:
        tex.append(f"{d['ports']} & {d['preset']} & {d['stockout_minutes']:.3f} & {d['total_travel_m']/1000:.2f} & {d['overflow_units']:.1f} & {100*d['admission_rate']:.1f}"+r' \\')
    tex += [r'\bottomrule\end{tabular}',r'\par\medskip',r'\begin{tabular}{lr}',r'\toprule Paired stockout contrast & Difference (min) [95\% CI]\\\midrule']
    for r in port_contrasts:
        name=(f"240 minus 80, {r['ports']} port(s)/line" if r['contrast']=='240_minus_80' else f"{r['ports']} minus {'2' if r['contrast']=='3_minus_2' else '1'} port(s)/line, preset {r['preset']}")
        tex.append(name+' & '+ci(r)+r' \\')
    tex += [r'\bottomrule\end{tabular}',r'\end{table}']
    (out/'ports_table.tex').write_text('\n'.join(tex)+'\n')
    summary=dict(episodes=len(rows),batch_episodes=30,urgency_episodes=15,ports_episodes=60,
        reused_fresh_milp_episodes=30,reused_primary_one_port_episodes=30,
        audited_completed_missions=sum(r['completed_audited_missions'] for r in rows),
        audit_totals={key:sum(r[key] for r in rows) for key in AUDITS},
        minimum_battery=min(r['realized_min_battery'] for r in rows),
        all_physical_port_cells_use_full_parallel_capacity=True)
    (out/'extension_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for arg in ['primary','technical','extension','out']:p.add_argument('--'+arg,type=Path,required=True)
    p.add_argument('--dispatch-only', action='store_true')
    a=p.parse_args();analyze(a.primary,a.technical,a.extension,a.out,a.dispatch_only)
