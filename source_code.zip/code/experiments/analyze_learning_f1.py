"""Regenerate learning diagnostics under the service-event simulation model.

Offline coverage values can be read from the seed-4 selection evaluation;
closed-loop values and paired
intervals are regenerated from the original seed-level output files.
"""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analyze_results import interval

BOOTSTRAP_SEEDS = {'learning_f1_minus_base_80': 7652215894447551885, 'learning_f1_MILPOnly80': 4875590044964813255, 'learning_f1_MILPOnly + F180': 14439515415102259915, 'learning_f1_minus_base_120': 8840439379271272373, 'learning_f1_MILPOnly120': 9932186263833273083, 'learning_f1_MILPOnly + F1120': 6434201447743646674, 'learning_f1_minus_base_160': 9394391864998037889, 'learning_f1_MILPOnly160': 9155144844100197227, 'learning_f1_MILPOnly + F1160': 3625957960391899422, 'learning_f1_minus_base_240': 10068693241657591018, 'learning_f1_MILPOnly240': 17491587531008744102, 'learning_f1_MILPOnly + F1240': 12871866331531270357, 'learning_f1_minus_base_UNPRUNED': 14952672938879179057, 'learning_f1_MILPOnlyUNPRUNED': 5776366500053853164, 'learning_f1_MILPOnly + F1UNPRUNED': 3053997393228953438}

def main():
    p=argparse.ArgumentParser();p.add_argument('--learning-results',type=Path,required=True);p.add_argument('--coverage',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=True,parents=True)
    coverage=pd.DataFrame({'k':[40,80,120,160],'Learned':[.735,.818,.883,.920],
        'Urgency':[.263,.463,.609,.713],'Travel':[.663,.723,.751,.778],'Random':[.073,.154,.239,.323]})
    if a.coverage is not None:
        values=pd.read_csv(a.coverage).pivot(index='budget',columns='method',values='coverage')
        coverage=pd.DataFrame({'k':values.index,'Learned':values.learned.round(3),'Urgency':values.urgency.round(3),'Travel':values.travel.round(3),'Random':values.random.round(3)})
    coverage.to_csv(a.out/'learning_f1_reported_coverage.csv',index=False)
    ks=['80','120','160','240','UNPRUNED'];summary=[];contrasts=[]
    for k in ks:
        b=pd.read_csv(a.learning_results/f'sweep/base__base__k{k}__MILPOnly.csv')
        f=pd.read_csv(a.learning_results/f'sweep_f1/base__base__k{k}__MILPOnly+F1.csv')
        j=f[['seed','stockout_minutes']].merge(b[['seed','stockout_minutes']],on='seed',suffixes=('_f1','_base'),validate='one_to_one')
        assert len(j)==30
        contrasts.append(dict(preset=k,**interval(j.stockout_minutes_f1-j.stockout_minutes_base,'learning_f1_minus_base_'+k, seed=BOOTSTRAP_SEEDS['learning_f1_minus_base_'+k])))
        for name,df in [('MILPOnly',b),('MILPOnly + F1',f)]:
            summary.append(dict(preset=k,method=name,**interval(df.stockout_minutes,'learning_f1_'+name+k, seed=BOOTSTRAP_SEEDS['learning_f1_'+name+k])))
    pd.DataFrame(summary).to_csv(a.out/'learning_f1_summary.csv',index=False)
    pd.DataFrame(contrasts).to_csv(a.out/'learning_f1_paired_contrasts.csv',index=False)
    fig,ax=plt.subplots(1,2,figsize=(8,3.1),layout='constrained')
    for name,style,marker in [('Learned','-','o'),('Urgency','--','s'),('Travel',':','^')]:
        ax[0].plot(coverage.k,coverage[name],label=name,color='blue',ls=style,marker=marker,ms=4)
    ax[0].set(xlabel='Retained pair budget in offline diagnostic',ylabel='Reported selection coverage',ylim=(0,1),title='Auxiliary offline diagnostic')
    ax[0].legend(fontsize=8)
    for name,offset,style,marker in [('MILPOnly',-.06,'-','o'),('MILPOnly + F1',.06,'--','s')]:
        rows=[r for r in summary if r['method']==name];m=np.array([r['mean'] for r in rows]);lo=np.array([r['lo'] for r in rows]);hi=np.array([r['hi'] for r in rows])
        ax[1].errorbar(np.arange(5)+offset,m,yerr=[m-lo,hi-m],label=name,color='blue',ls=style,marker=marker,ms=4,capsize=3)
    ax[1].set(xticks=range(5),xticklabels=['80','120','160','240','Broad'],xlabel='Controller screening preset',ylabel='Stockout (min)',title='Service-event comparison')
    ax[1].legend(fontsize=8)
    for axis in ax:
        axis.spines[['top','right']].set_visible(False);axis.tick_params(colors='blue')
        for label in [axis.xaxis.label,axis.yaxis.label,axis.title]:label.set_color('blue')
        for t in axis.get_legend().get_texts():t.set_color('blue')
    fig.savefig(a.out/'fig_selection_invariance.pdf');fig.savefig(a.out/'fig_selection_invariance.png',dpi=300)
    (a.out/'learning_f1_provenance.json').write_text(json.dumps(dict(status='Service-event simulation model; separate from the schedule-based benchmark',offline_source='Computed from recorded seed-4 features and checkpoint' if a.coverage is not None else 'Reported three-decimal coverage values',closed_loop_source='Service-event 30-seed CSVs',bootstrap_resamples=50000),indent=2))
    print(json.dumps(contrasts,indent=2))

if __name__=='__main__':main()
