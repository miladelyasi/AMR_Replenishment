"""Run the prespecified 90-episode stopping-policy experiment (immutable output)."""
import concurrent.futures as cf
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'stopping_results'
JOBS = [dict(policy=policy, k=k, seed=seed) for seed in range(15)
        for k in ['80', '240', 'UNPRUNED'] for policy in ['reference', 'absolute']]

def one(job):
    stem = f"{job['policy']}_k{job['k']}_s{job['seed']:02d}"
    target = OUT / (stem+'.json')
    if target.exists() and target.with_suffix('.snapshots.json').exists():
        return stem, 'cached'
    command = [sys.executable, 'experiments/stopping_validation.py', '--policy', job['policy'],
        '--k', job['k'], '--seed', str(job['seed']), '--out', str(target)]
    with (OUT/(stem+'.log')).open('w') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            env={**os.environ, 'OMP_NUM_THREADS':'1', 'OPENBLAS_NUM_THREADS':'1', 'MKL_NUM_THREADS':'1'})
    return stem, result.returncode

if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    (OUT/'manifest.json').write_text(json.dumps(dict(jobs=JOBS, horizon_seconds=28800,
        reference=dict(relative_gap=.02, time_limit_seconds=.15),
        absolute=dict(relative_gap=0., absolute_gap=1e-6, time_limit_seconds=5.),
        snapshot_times=[0,300,1800,3600,7200,14400,21600,27900],
        weights='reference for every preset; no tuning',
        primary_contrasts='absolute minus reference within preset; 240 minus 80 and Broad minus 240 within policy'), indent=2))
    with cf.ThreadPoolExecutor(max_workers=int(sys.argv[1]) if len(sys.argv)>1 else 6) as pool:
        for i, result in enumerate(pool.map(one, JOBS), 1):
            print(i, len(JOBS), result, flush=True)
