"""Analyze the terminal-value diagnostic under the service-event simulation model."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    p=argparse.ArgumentParser();p.add_argument('--learning-results',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args();args.out.mkdir(exist_ok=True,parents=True)
    a=pd.read_csv(args.learning_results/'f2_h80_eta10_s15.csv')
    b=pd.read_csv(args.learning_results/'ofat/base__base__k80__MILPOnly.csv')
    j=a[['seed','stockout_minutes']].merge(b[['seed','stockout_minutes']],on='seed',suffixes=('_f2','_base'),validate='one_to_one').sort_values('seed')
    assert len(j)==15
    d=(j.stockout_minutes_f2-j.stockout_minutes_base).to_numpy();rng=np.random.default_rng(20260927)
    means=d[rng.integers(0,15,(50000,15))].mean(axis=1);lo,hi=np.quantile(means,[.025,.975])
    data=dict(n=15,base_mean=float(j.stockout_minutes_base.mean()),f2_mean=float(j.stockout_minutes_f2.mean()),paired_difference=float(d.mean()),ci=[float(lo),float(hi)],bootstrap_resamples=50000,status='Service-event simulation model; separate from the schedule-based benchmark')
    (args.out/'learning_f2.json').write_text(json.dumps(data,indent=2));j.to_csv(args.out/'learning_f2_paired.csv',index=False)
    fig,ax=plt.subplots(1,2,figsize=(7,2.8),layout='constrained')
    for _,r in j.iterrows():ax[0].plot([0,1],[r.stockout_minutes_base,r.stockout_minutes_f2],color='blue',alpha=.35,lw=.8,marker='o',ms=2)
    ax[0].set_xticks([0,1],['MILPOnly','Terminal value']);ax[0].set_ylabel('Stockout (min)');ax[0].set_title('Service-event paired episodes')
    ax[1].errorbar([0],[d.mean()],yerr=[[d.mean()-lo],[hi-d.mean()]],fmt='o',color='blue',capsize=5);ax[1].axhline(0,color='gray',ls='--',lw=.8);ax[1].set_xticks([0],['Terminal value minus MILPOnly']);ax[1].set_ylabel('Paired difference (min)');ax[1].set_title('95% paired bootstrap interval')
    for a in ax:
        a.spines[['top','right']].set_visible(False)
        a.tick_params(colors='blue');a.xaxis.label.set_color('blue');a.yaxis.label.set_color('blue');a.title.set_color('blue')
    fig.savefig(args.out/'fig_f2_confirmation.pdf');fig.savefig(args.out/'fig_f2_confirmation.png',dpi=300)
    print(json.dumps(data))

if __name__=='__main__':main()
