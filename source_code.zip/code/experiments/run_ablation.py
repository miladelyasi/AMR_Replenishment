"""Section 5.6 — Ablation Study.

Runs all four ablations (no_rl, no_excavation_lock, no_milp,
no_shield_penalty) plus the full proposed method, on the base config.
Emits a single ablation table.

Usage
-----
    python experiments/run_ablation.py --seeds 20
"""

from __future__ import annotations

import argparse
from pathlib import Path

ABLATION_CONFIGS = {
    "Full":              "configs/base.yaml",
    "No RL":             "configs/ablations/no_rl.yaml",
    "No excavation lock":"configs/ablations/no_excavation_lock.yaml",
    "No MILP":           "configs/ablations/no_milp.yaml",
    "No shield penalty": "configs/ablations/no_shield_penalty.yaml",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--out_dir", type=Path, default=Path("results/ablation"))
    args = parser.parse_args()
    raise NotImplementedError("Implement after run_overall.py is working.")


if __name__ == "__main__":
    main()
