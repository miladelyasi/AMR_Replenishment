"""Fixed-settings validation: matched dispatch, coverage, and solver stopping.

Primary campaign records are never overwritten. Seeds 30--44 are held out from
all weight screening. Gap replay uses eight prespecified times in seed 0.
"""
import argparse,csv,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'experiments'))
import run_episode as runner
from baselines.milp_only import MILPOnlyController
from tactical.milp import TacticalMILP,TacticalSolution
from tactical.feasibility import build_job_set
from common.config import CandidatePruningConfig
from common.types import Commitment

class MatchedGreedy(TacticalMILP):
    def solve(self, state, feasible, jobs, **kwargs):
        start=time.perf_counter(); selected=[];robots=set();totes=set()
        for lid in sorted(state.line_ids,key=lambda lid:(float(state.hat_T_so[lid]),int(lid))):
            pool=[f for f in feasible if f.job.line_id==lid and f.robot_id not in robots and f.job.tote_id not in totes]
            if not pool:continue
            f=min(pool,key=lambda f:(f.travel_to_tote, int(f.job.mode),state.stack_depth[f.job.tote_id],f.job.tote_id,f.robot_id))
            selected.append(f);robots.add(f.robot_id);totes.add(f.job.tote_id)
        keys={f.job.key() for f in selected}
        return TacticalSolution([Commitment(f.robot_id,f.job,f.start_slot,state.epoch_time,self.slot_size) for f in selected],
            [j for j in jobs if j.key() in keys],[j for j in jobs if j.key() not in keys],0.,1000*(time.perf_counter()-start),0.,'GREEDY')

class GapMILP(TacticalMILP):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.gaps=[];self.snapshots=[]
        self.times=iter([0,300,1800,3600,7200,14400,21600,27900]);self.next_time=next(self.times)
    def _extract_solution(self,model,x,v,feasible,jobs,epoch_time,runtime_ms):
        sol=super()._extract_solution(model,x,v,feasible,jobs,epoch_time,runtime_ms)
        if not model.SolCount:return sol
        row=dict(time=epoch_time,jobs=len(jobs),triples=len(feasible),constant=model.ObjCon,objective=model.ObjVal,bound=model.ObjBound,gap=model.MIPGap,status=model.Status)
        self.gaps.append(row)
        if epoch_time>=self.next_time:
            base_values={a.VarName:a.X for a in model.getVars()}
            base_set={i for i in x if x[i].X>.5}
            snap=dict(row)
            for name,remove_constant in [('absolute',False),('centered',True)]:
                m=model.copy()
                for a in m.getVars():a.Start=base_values[a.VarName]
                if remove_constant:m.ObjCon=0
                m.Params.MIPGap=.02 if remove_constant else 0.
                m.Params.MIPGapAbs=1e-6
                m.Params.TimeLimit=.15 if remove_constant else 5.
                m.optimize()
                if m.SolCount:
                    obj=m.ObjVal+(row['constant'] if remove_constant else 0.)
                    chosen={i for i in x if m.getVarByName(x[i].VarName).X>.5}
                    snap[name]=dict(objective=obj,improvement=row['objective']-obj,gap=m.MIPGap,status=m.Status,runtime=m.Runtime,
                        changed_assignments=len(chosen.symmetric_difference(base_set)),commitments=len(chosen),bound=m.ObjBound+(row['constant'] if remove_constant else 0.))
                else:snap[name]=dict(status=m.Status)
                m.dispose()
            self.snapshots.append(snap);self.next_time=next(self.times,float('inf'))
        return sol

def run(kind,k,seed,out,horizon=None):
    coverage=[];audit={};instance={}
    def factory(cfg,sim,max_slots_per_pair):
        ctrl=MILPOnlyController(cfg,sim,max_slots_per_pair=max_slots_per_pair)
        if kind in ['greedy','gap']:
            cls=MatchedGreedy if kind=='greedy' else GapMILP
            ctrl.milp=cls(cfg=cfg.milp,num_slots=ctrl.num_slots,slot_size=ctrl.slot_size)
        instance['ctrl']=ctrl
        initial=sum(b.level for b in sim.buffers);success=[0]
        raw_consume=sim._handle_consumption
        def consume(lid):
            if sim.buffers[lid].level>0:success[0]+=1
            return raw_consume(lid)
        sim._handle_consumption=consume
        raw_decide=ctrl.decide
        def decide(state):
            critical={int(lid) for lid in state.line_ids if state.hat_T_so[lid]<=cfg.controller.urgency_T_crit_seconds}
            access={int(lid) for (lid,uid),g in state.sku_compat.items() if g and int(state.access.get(uid,0)) in [1,2]}
            jobs=build_job_set(state,cfg.controller.candidate_pruning)
            screened={j.line_id for j in jobs}
            output=raw_decide(state)
            coverage.append(dict(time=state.epoch_time,critical=len(critical),accessible_critical=len(critical&access),
                omitted_critical=len((critical&access)-screened),unavailable_critical=len(critical-access),screened_lines=len(screened)))
            audit.update(initial=initial,served_consumption=success[0])
            return output
        ctrl.decide=decide;instance['sim']=sim;instance['success']=success;instance['initial']=initial
        return ctrl
    runner.MILPOnlyController=factory
    overrides={'milp.weights.beta_M':2.} if kind!='gap' and str(k)=='80' else {}
    row=runner.run(f'configs/sweep/base__base__k{k}.yaml',seed,out,overrides,horizon)
    sim=instance['sim']
    audit.update(initial=instance['initial'],served_consumption=instance['success'][0],accepted=sim.buffer_accepted_units,final=sum(b.level for b in sim.buffers))
    audit['residual']=audit['initial']+audit['accepted']-audit['served_consumption']-audit['final'];assert audit['residual']==0
    row.update(validation_kind=kind,preset=str(k),material_balance=audit,coverage_totals={key:sum(r[key] for r in coverage) for key in coverage[0] if key!='time'})
    out=Path(out);out.write_text(json.dumps(row,indent=2))
    with out.with_suffix('.coverage.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=coverage[0]);w.writeheader();w.writerows(coverage)
    if kind=='gap':
        m=instance['ctrl'].milp
        out.with_suffix('.gaps.json').write_text(json.dumps(dict(calls=m.gaps,snapshots=m.snapshots),indent=2))
    return row

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--kind',choices=['milp','greedy','gap'],required=True);p.add_argument('--k',required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--out',required=True);p.add_argument('--horizon',type=float)
    a=p.parse_args();run(a.kind,a.k,a.seed,a.out,a.horizon)
