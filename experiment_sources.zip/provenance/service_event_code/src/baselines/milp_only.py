"""Optimization-only MILP policy (Section 5.2 of the manuscript).

Solves the same time-indexed tactical MILP as the proposed method, but
with all RL preference scores set to zero. This isolates the value of
the strategic learning layer.

NOTE: this version adds OPTIONAL per-epoch JSONL logging for pruner /
F2 training data. When ``rollout_path`` is None (the default), behaviour
is byte-identical to the original file.
"""

from __future__ import annotations

from typing import Optional

import numpy as np

from common.config import Config
from common.controller import Controller, ControllerOutput
from common.state import SystemState
from common.types import Job
from tactical.feasibility import build_feasible_set, build_job_set
from tactical.milp import TacticalMILP, TacticalSolution
from tactical.windows import lock_duration, pickup_duration
from world.eligibility import build_eligible_set
from baselines._milp_logger import MILPRolloutLogger


class MILPOnlyController(Controller):
    """A purely optimization-based controller — no learning component."""

    name = "MILPOnly"

    def __init__(
        self,
        cfg: Config,
        sim_handle,
        max_slots_per_pair: int | None = None,
        rollout_path: Optional[str] = None,
        rollout_episode_id: int = 0,
        pruner_ckpt: Optional[str] = None,
        pruner_index: Optional[str] = None,
        pruner_k: int = 80,
        f2_ckpt: Optional[str] = None,
        f2_index: Optional[str] = None,
        f2_eta: float = 1.0,
    ):
        """``sim_handle`` is a Simulator instance.

        We need a back-reference to the simulator (or its sub-systems) so
        we can compute travel surrogates, look up tote-to-column mappings,
        and read storage capacities. The simulator lifetime exceeds the
        controller's, so this is safe.

        Parameters
        ----------
        max_slots_per_pair
            Cap on the number of start slots considered per ``(r, j)``
            pair. Set to ``1`` for restricted-license Gurobi or for
            very fast online use. ``None`` means "explore all feasible
            slots" (typical for paper-scale licensed runs).
        rollout_path
            If given, append one JSONL line per ``decide()`` call to this
            path. The data is used to train the F1 candidate-pruner and
            the F2 terminal-value critic. Pass ``None`` (default) for
            production / paper-table runs to match the existing behaviour
            byte-for-byte.
        rollout_episode_id
            Episode id stamped into each logged record (usually the seed).
        pruner_ckpt
            Optional path to a trained candidate-pruner checkpoint.
            If ``None``, no learned pruning is applied.
        pruner_index
            Optional path to the feature-index JSON used by the trained
            candidate pruner.
        pruner_k
            Number of candidates retained by the learned candidate pruner.
        f2_ckpt
            Optional path to a trained F2 terminal-value checkpoint.
            If ``None``, no terminal-value scores are added.
        f2_index
            Optional path to the feature-index JSON used by the trained
            F2 terminal-value model.
        f2_eta
            Scaling coefficient for the F2 terminal-value contribution.
        """
        self.cfg = cfg
        self.sim = sim_handle
        self.max_slots_per_pair = max_slots_per_pair

        self._rollout_path = rollout_path
        self._rollout_logger: MILPRolloutLogger | None = (
            MILPRolloutLogger(rollout_path, episode_id=rollout_episode_id)
            if rollout_path else None
        )

        self._pruner_rt = None
        if pruner_ckpt:
            from baselines._milp_logger import CandidatePrunerRuntime

            self._pruner_rt = CandidatePrunerRuntime(
                pruner_ckpt,
                pruner_index,
                k=pruner_k,
                T_crit=cfg.controller.urgency_T_crit_seconds,
            )

        self._tv_rt = None
        if f2_ckpt:
            from pruner.f2_critic import TerminalValueRuntime

            self._tv_rt = TerminalValueRuntime(
                f2_ckpt,
                f2_index,
                eta=f2_eta,
            )

        # Build the MILP solver
        H = cfg.controller.tactical_horizon_H_seconds
        D = cfg.controller.slot_size_delta_seconds
        self.num_slots = int(round(H / D))
        self.slot_size = D
        self.milp = TacticalMILP(cfg=cfg.milp, num_slots=self.num_slots, slot_size=D)

        # Pre-built static maps (filled after first decide call when sim is ready)
        self._tote_to_src_idx: dict[int, int] | None = None
        self._cell_to_src_idx: dict[tuple[int, int], int] | None = None
        self._line_to_dst_idx: dict[int, int] | None = None
        self._capacities_src: np.ndarray | None = None
        self._capacities_dst: np.ndarray | None = None
        self._capacities_block: np.ndarray | None = None
        self._battery_min_per_robot: dict[int, float] | None = None

        # Telemetry
        self._last_solution: TacticalSolution | None = None

    # ------------------------------------------------------------------ helpers

    def _ensure_static_maps(self) -> None:
        if self._cell_to_src_idx is not None:
            return
        cells = sorted(self.sim.storage.columns.keys())
        self._cell_to_src_idx = {c: i for i, c in enumerate(cells)}
        self._line_to_dst_idx = {l: l for l in range(self.cfg.world.num_lines)}
        n_src = len(cells)
        n_dst = self.cfg.world.num_lines
        n_blk = len(cells)
        self._capacities_src = np.full(
            n_src,
            self.cfg.world.interfaces.src_capacity,
            dtype=np.int32,
        )
        self._capacities_dst = np.full(
            n_dst,
            self.cfg.world.interfaces.dst_capacity,
            dtype=np.int32,
        )
        self._capacities_block = np.full(
            n_blk,
            self.cfg.world.interfaces.block_capacity,
            dtype=np.int32,
        )
        self._battery_min_per_robot = {
            int(r.rid): self.cfg.world.robots.battery_min for r in self.sim.robots
        }

    def _build_tote_maps(self):
        self._ensure_static_maps()
        cell_idx = self._cell_to_src_idx
        tote_to_src: dict[int, int] = {}
        tote_to_block: dict[int, list[int]] = {}
        for uid, cell in self.sim.storage._tote_column.items():
            idx = cell_idx[cell]
            tote_to_src[uid] = idx
            tote_to_block[uid] = [idx]
        return tote_to_src, tote_to_block

    def _make_travel_to_tote_fn(self):
        sim = self.sim

        def f(rid: int, uid: int) -> float:
            cell = sim.storage.find_tote_column(uid)
            if cell is None:
                return float("inf")
            robot_pos = tuple(sim.robots[rid].pos)
            return sim.grid.travel_time(robot_pos, cell)

        return f

    def _make_travel_to_line_fn(self):
        sim = self.sim

        def f(uid: int, lid: int) -> float:
            cell = sim.storage.find_tote_column(uid)
            if cell is None:
                return float("inf")
            line_pos = sim.line_positions[lid]
            return sim.grid.travel_time(cell, line_pos)

        return f

    def _make_pickup_fn(self):
        st = self.cfg.world.service_times

        def f(depth, support, mode):
            return pickup_duration(
                depth,
                support,
                mode,
                base=st.pickup_base_seconds,
                per_depth=st.pickup_per_depth_seconds,
                excavation_overhead=st.pickup_excavation_overhead,
                epsilon_0=st.epsilon_0,
            )

        return f

    def _make_lock_fn(self):
        st = self.cfg.world.service_times

        def f(depth, support, mode):
            return lock_duration(
                depth,
                support,
                mode,
                per_depth=st.lock_per_depth_seconds,
                excavation_overhead=st.lock_excavation_overhead,
                epsilon_0=st.epsilon_0,
            )

        return f

    def _make_energy_fn(self):
        sim = self.sim
        em = sim.energy_model

        def f(rid, job, tau_rt, tau_tl, depth, mode):
            from common.enums import ServiceMode

            mode_excav = mode == ServiceMode.EXCAVATION
            travel_meters = (tau_rt + tau_tl) * sim.grid.nominal_speed_mps
            return (
                em.cost_for_distance(travel_meters)
                + em.cost_for_pickup(mode_excavation=mode_excav, depth=depth)
                + em.cost_for_drop()
            )

        return f

    # ------------------------------------------------------------------ decide

    def decide(self, state: SystemState) -> ControllerOutput:
        self._ensure_static_maps()

        # 1. Eligible robots R_n
        eligible_ids = build_eligible_set(
            self.sim.robots,
            state,
            horizon_seconds=self.cfg.controller.tactical_horizon_H_seconds,
            battery_pre_filter_floor=self.cfg.world.robots.battery_pre_filter_floor,
            battery_min=self.cfg.world.robots.battery_min,
        )

        # Drop robots that already have a commitment (busy)
        eligible_ids = [r for r in eligible_ids if not state.commitment_busy[r]]

        if not eligible_ids:
            return ControllerOutput(
                commitments=[],
                diagnostics={"num_candidates": 0, "milp_status": "no_eligible_robots"},
            )

        # 2. Job set J_n
        jobs = build_job_set(state, self.cfg.controller.candidate_pruning)

        # 3. Feasible set F_n
        tote_to_src, tote_to_block = self._build_tote_maps()
        feasible = build_feasible_set(
            state,
            jobs,
            eligible_ids,
            horizon_seconds=self.cfg.controller.tactical_horizon_H_seconds,
            slot_size=self.slot_size,
            num_slots=self.num_slots,
            battery_min_per_robot=self._battery_min_per_robot,
            travel_to_tote_fn=self._make_travel_to_tote_fn(),
            travel_to_line_fn=self._make_travel_to_line_fn(),
            pickup_dur_fn=self._make_pickup_fn(),
            lock_dur_fn=self._make_lock_fn(),
            energy_fn=self._make_energy_fn(),
            drop_seconds=self.cfg.world.service_times.drop_seconds,
            max_slots_per_pair=self.max_slots_per_pair,
        )

        if self._pruner_rt is not None:
            feasible = self._pruner_rt.filter(
                state,
                feasible,
                self.sim,
                self._make_pickup_fn(),
                self._make_lock_fn(),
            )

        # 4. Build score field — all zeros for MILP-only, or F2 terminal-value scores
        if self._tv_rt is not None:
            score_field = self._tv_rt.coefficients(state, feasible, self.sim)
        else:
            score_field: dict[tuple[int, int, int], float] = {}

        # 5. Carried reservations from previous commitments — Stage 2: zeros
        n_src = len(self._cell_to_src_idx)
        n_dst = self.cfg.world.num_lines
        n_blk = n_src
        carried_src = np.zeros((n_src, self.num_slots), dtype=np.int32)
        carried_dst = np.zeros((n_dst, self.num_slots), dtype=np.int32)
        carried_block = np.zeros((n_blk, self.num_slots), dtype=np.int32)

        battery_remaining = {
            int(r.rid): max(0.0, float(r.battery) - self.cfg.world.robots.battery_min)
            for r in self.sim.robots
        }

        # 6. Solve
        sol = self.milp.solve(
            state=state,
            feasible=feasible,
            jobs=jobs,
            score_field=score_field,
            carried_src=carried_src,
            carried_dst=carried_dst,
            carried_block=carried_block,
            battery_remaining=battery_remaining,
            capacities_src=self._capacities_src,
            capacities_dst=self._capacities_dst,
            capacities_block=self._capacities_block,
            tote_to_src_idx=tote_to_src,
            line_to_dst_idx=self._line_to_dst_idx,
            tote_to_block_indices=tote_to_block,
        )
        self._last_solution = sol

        # ---- Optional rollout logging for pruner / F2 training data ---- #
        if self._rollout_logger is not None:
            try:
                decision_time = float(
                    getattr(
                        state,
                        "now_seconds",
                        getattr(
                            state,
                            "t_now",
                            getattr(state, "time_seconds", 0.0),
                        ),
                    )
                )
                self._rollout_logger.log_solve(
                    decision_time_s=decision_time,
                    state=state,
                    feasible=feasible,
                    jobs=jobs,
                    sol=sol,
                    robots=self.sim.robots,
                    sim=self.sim,
                    pickup_fn=self._make_pickup_fn(),
                    lock_fn=self._make_lock_fn(),
                )
            except Exception as e:
                print(f"[warn] rollout log_solve failed at one epoch: {e}")

        return ControllerOutput(
            commitments=sol.commitments,
            diagnostics={
                "num_candidates": len(feasible),
                "num_jobs": len(jobs),
                "num_eligible_robots": len(eligible_ids),
                "milp_status": sol.status,
                "milp_solve_ms": sol.runtime_ms,
                "milp_objective": sol.objective,
                "milp_gap": sol.mip_gap,
                **sol.diagnostics,
            },
        )

    # ------------------------------------------------------------ rollout I/O

    def close_rollout(self):
        """Flush and close the per-episode JSONL writer (no-op if disabled)."""
        if self._rollout_logger is not None:
            self._rollout_logger.close()
            self._rollout_logger = None

    def __del__(self):
        try:
            self.close_rollout()
        except Exception:
            pass