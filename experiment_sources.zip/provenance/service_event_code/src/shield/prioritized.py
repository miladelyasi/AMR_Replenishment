"""Prioritized MAPF planner with reservation table.

This is the operational layer of Section 4.3. It:

1. Receives a tactical commitment set together with the per-mission
   pickup/drop windows.
2. Plans each robot's trajectory in priority order using time-expanded
   A* against a shared reservation table.
3. When the nominal start cannot be exactly realized, applies the
   lexicographic repair logic from ``shield/repair.py``: bounded local
   shift → protected waiting (built into A* via wait actions) → selective
   deferral.
4. Returns the per-robot trajectories plus a ``ShieldOutput`` summary.

We intentionally implement *prioritized planning* rather than CBS:
for a 20×20 grid with 10 robots and short tactical horizons, prioritized
planning is fast, deterministic, and matches what the manuscript text
describes (Section 4.3 mentions "prioritized planning with reservation
tables" as an admissible choice).
"""

from __future__ import annotations

import heapq
import time
from dataclasses import dataclass, field

from common.config import ShieldConfig
from common.state import SystemState
from common.types import Commitment, Coord, Trajectory, TrajectoryStep
from world.grid import FloorGraph

from .repair import RepairAction, RepairResult
from .reservation_table import ReservationTable


# ---------------------------------------------------------------------------
# Output container
# ---------------------------------------------------------------------------

@dataclass
class PlannedMission:
    """One commitment fully resolved on the floor graph.

    Holds the step-by-step path **before** pickup and **after** pickup,
    plus the realized service-window times. The simulator uses these to
    schedule its EV_ARRIVE_PICKUP / PICKUP_DONE / EV_ARRIVE_DROP /
    EV_DROP_DONE events at the correct continuous-time instants.
    """

    commitment: Commitment
    path_to_pickup: list[Coord]      # cell-by-cell, including waits
    path_to_drop: list[Coord]
    arrive_pickup_time: float
    pickup_done_time: float
    arrive_drop_time: float
    drop_done_time: float
    travel_distance_m: float
    repair_action: RepairAction = RepairAction.NONE
    shift_steps: int = 0


@dataclass
class ShieldOutput:
    """The full result of one shield invocation (eq. contract)."""

    accepted: list[PlannedMission]
    deferred: list[Commitment]
    rejected: list[Commitment]
    repair_log: list[RepairResult] = field(default_factory=list)
    runtime_ms: float = 0.0


# ---------------------------------------------------------------------------
# Planner
# ---------------------------------------------------------------------------

class PrioritizedShield:
    """Prioritized A* + reservation table + bounded repair.

    The reservation table is owned by the shield and persists across epochs.
    Robots clear their own reservations via ``release_robot`` when their
    mission completes.
    """

    _NEIGHBOR_OFFSETS = ((1, 0), (-1, 0), (0, 1), (0, -1))

    def __init__(
        self,
        cfg: ShieldConfig,
        grid: FloorGraph,
        slot_size: float,
    ):
        self.cfg = cfg
        self.grid = grid
        self.slot_size = slot_size
        # Step time used by the time-expanded planner (one cell hop per step)
        self.step_seconds = grid.cell_size_m / max(grid.nominal_speed_mps, 1e-6)

        self.table = ReservationTable(step_seconds=self.step_seconds)

    # ------------------------------------------------------------------ public API

    def release_robot(self, rid: int) -> None:
        """Clear all reservations for a robot that just completed a mission."""
        self.table.clear_robot(rid)

    def plan(
        self,
        state: SystemState,
        commitments: list[Commitment],
        robot_positions: dict[int, Coord],
        line_positions: dict[int, Coord],
        tote_columns: dict[int, Coord],
        pickup_seconds_for: dict,        # commitment-key -> seconds
        lock_seconds_for: dict,
        drop_seconds: float,
    ) -> ShieldOutput:
        """Plan trajectories for every commitment in priority order."""
        t0 = time.perf_counter()
        accepted: list[PlannedMission] = []
        deferred: list[Commitment] = []
        rejected: list[Commitment] = []
        repair_log: list[RepairResult] = []

        ordered = self._priority_order(commitments, state)

        for cm in ordered:
            ck = (cm.robot_id, cm.job.line_id, cm.job.tote_id)
            pickup_seconds = pickup_seconds_for.get(ck, 6.0)
            lock_seconds = lock_seconds_for.get(ck, 0.0)

            tote_cell = tote_columns.get(int(cm.job.tote_id))
            if tote_cell is None:
                rejected.append(cm)
                repair_log.append(RepairResult(cm, RepairAction.REJECTED,
                                               notes="tote not in storage"))
                continue
            line_cell = line_positions[int(cm.job.line_id)]
            start_cell = robot_positions[int(cm.robot_id)]

            # Try the nominal start first
            mission = self._plan_one(
                cm,
                start_cell=start_cell,
                tote_cell=tote_cell,
                line_cell=line_cell,
                pickup_seconds=pickup_seconds,
                lock_seconds=lock_seconds,
                drop_seconds=drop_seconds,
                shift_steps=0,
            )
            if mission is not None:
                self._commit_to_reservations(mission)
                accepted.append(mission)
                continue

            # ---- Repair: bounded local shift
            repair_budget = max(1, int(self.cfg.shield_repair_budget_slots))
            repaired = None
            shift_used = 0
            steps_per_slot = max(1, int(round(self.slot_size / self.step_seconds)))
            for k in range(1, repair_budget + 1):
                # Shift the start by k slots forward (positive shift only — we
                # cannot move into the past).
                shift_steps_k = k * steps_per_slot
                mission = self._plan_one(
                    cm,
                    start_cell=start_cell,
                    tote_cell=tote_cell,
                    line_cell=line_cell,
                    pickup_seconds=pickup_seconds,
                    lock_seconds=lock_seconds,
                    drop_seconds=drop_seconds,
                    shift_steps=shift_steps_k,
                )
                if mission is not None:
                    repaired = mission
                    repaired.repair_action = RepairAction.SHIFTED
                    repaired.shift_steps = shift_steps_k
                    shift_used = k
                    break

            if repaired is not None:
                self._commit_to_reservations(repaired)
                accepted.append(repaired)
                repair_log.append(RepairResult(
                    cm, RepairAction.SHIFTED,
                    shift_slots=shift_used,
                    extra_wait_seconds=shift_used * self.slot_size,
                    notes=f"shifted by {shift_used} slot(s)",
                ))
                continue

            # ---- Selective deferral: drop the commitment
            deferred.append(cm)
            repair_log.append(RepairResult(
                cm, RepairAction.DEFERRED,
                notes=f"no plan within shift budget {repair_budget}",
            ))

        runtime_ms = 1000.0 * (time.perf_counter() - t0)
        return ShieldOutput(
            accepted=accepted,
            deferred=deferred,
            rejected=rejected,
            repair_log=repair_log,
            runtime_ms=runtime_ms,
        )

    # ------------------------------------------------------------------ priority ordering

    def _priority_order(
        self, commitments: list[Commitment], state: SystemState
    ) -> list[Commitment]:
        """Order commitments by ``self.cfg.priority_rule``.

        - ``urgency``: ascending hat_T_so of the destination line.
        - ``fcfs``:    issue order (stable).
        """
        rule = getattr(self.cfg, "priority_rule", "urgency")
        if rule == "fcfs":
            return list(commitments)
        # Default: urgency-first
        return sorted(commitments, key=lambda c: float(state.hat_T_so[int(c.job.line_id)]))

    # ------------------------------------------------------------------ plan one mission

    def _plan_one(
        self,
        commitment: Commitment,
        *,
        start_cell: Coord,
        tote_cell: Coord,
        line_cell: Coord,
        pickup_seconds: float,
        lock_seconds: float,
        drop_seconds: float,
        shift_steps: int,
    ) -> PlannedMission | None:
        """Plan a single robot's full mission with time-expanded A*."""
        rid = int(commitment.robot_id)

        # Continuous-time start of the mission within the epoch
        t_start = (
            commitment.epoch_time
            + commitment.start_slot * self.slot_size
            + shift_steps * self.step_seconds
        )
        start_step = self.table.time_to_step(t_start)
        # Generous deadline: 5 × tactical horizon worth of steps after start.
        # We mainly care about feasibility, not lateness — that's the MILP's job.
        deadline_step = start_step + 1000

        # ---- Phase 1: travel start → tote_cell
        path1 = self._astar_time_expanded(
            start_cell, tote_cell, start_step, deadline_step, rid,
        )
        if path1 is None:
            return None
        arrive_pickup_step = path1[-1][1]   # (cell, step)

        # ---- Phase 2: pickup window — robot stays at tote_cell for pickup_seconds
        pickup_steps = max(1, int(round(pickup_seconds / self.step_seconds)))
        # We try to reserve the window; if it conflicts with another robot,
        # this mission can't be planned at this start time.
        # NOTE: we don't actually mutate the table yet — we just check
        # feasibility so we can roll back if a later phase fails.
        pickup_step_end = arrive_pickup_step + pickup_steps
        for t in range(arrive_pickup_step, pickup_step_end):
            if not self.table.is_node_free(tote_cell, t, ignoring_rid=rid):
                return None
        pickup_done_step = pickup_step_end

        # ---- Phase 3: travel tote_cell → line_cell
        path2 = self._astar_time_expanded(
            tote_cell, line_cell, pickup_done_step, deadline_step, rid,
        )
        if path2 is None:
            return None
        arrive_drop_step = path2[-1][1]

        # ---- Phase 4: drop window
        drop_steps = max(1, int(round(drop_seconds / self.step_seconds)))
        drop_step_end = arrive_drop_step + drop_steps
        for t in range(arrive_drop_step, drop_step_end):
            if not self.table.is_node_free(line_cell, t, ignoring_rid=rid):
                return None

        # ---- Build mission
        cells_path1 = [step[0] for step in path1]
        cells_path2 = [step[0] for step in path2]
        # Travel distance counts every cell-hop where we MOVE (consecutive
        # different cells); waits don't add distance.
        moves = 0
        for a, b in zip(cells_path1, cells_path1[1:]):
            if a != b:
                moves += 1
        for a, b in zip(cells_path2, cells_path2[1:]):
            if a != b:
                moves += 1
        distance_m = moves * self.grid.cell_size_m

        return PlannedMission(
            commitment=commitment,
            path_to_pickup=cells_path1,
            path_to_drop=cells_path2,
            arrive_pickup_time=self.table.step_to_time(arrive_pickup_step),
            pickup_done_time=self.table.step_to_time(pickup_done_step),
            arrive_drop_time=self.table.step_to_time(arrive_drop_step),
            drop_done_time=self.table.step_to_time(drop_step_end),
            travel_distance_m=distance_m,
        )

    def _commit_to_reservations(self, mission: PlannedMission) -> None:
        """Add the mission's full footprint to the reservation table."""
        rid = int(mission.commitment.robot_id)

        # Travel-to-pickup path
        start_step1 = self.table.time_to_step(mission.commitment.epoch_time
                                              + mission.commitment.start_slot * self.slot_size
                                              + mission.shift_steps * self.step_seconds)
        for i, cell in enumerate(mission.path_to_pickup):
            self.table.reserve_node(cell, start_step1 + i, rid)
            if i + 1 < len(mission.path_to_pickup):
                nxt = mission.path_to_pickup[i + 1]
                if cell != nxt:
                    self.table.reserve_edge(cell, nxt, start_step1 + i, rid)

        # Pickup window (cell stays at tote_cell)
        arrive_pickup_step = self.table.time_to_step(mission.arrive_pickup_time)
        pickup_done_step = self.table.time_to_step(mission.pickup_done_time)
        for t in range(arrive_pickup_step, pickup_done_step):
            self.table.reserve_node(mission.path_to_pickup[-1], t, rid)

        # Travel-to-drop path
        for i, cell in enumerate(mission.path_to_drop):
            t_step = pickup_done_step + i
            self.table.reserve_node(cell, t_step, rid)
            if i + 1 < len(mission.path_to_drop):
                nxt = mission.path_to_drop[i + 1]
                if cell != nxt:
                    self.table.reserve_edge(cell, nxt, t_step, rid)

        # Drop window
        arrive_drop_step = self.table.time_to_step(mission.arrive_drop_time)
        drop_done_step = self.table.time_to_step(mission.drop_done_time)
        for t in range(arrive_drop_step, drop_done_step):
            self.table.reserve_node(mission.path_to_drop[-1], t, rid)

    # ------------------------------------------------------------------ A*

    def _astar_time_expanded(
        self,
        start: Coord,
        goal: Coord,
        t_start_step: int,
        deadline_step: int,
        rid: int,
    ) -> list[tuple[Coord, int]] | None:
        """Time-expanded A* on the floor graph.

        State = (cell, time_step). Actions: 4-connected move + wait.
        Returns the list of ``(cell, t_step)`` waypoints (inclusive of
        start and goal). The trajectory's *last* step has ``cell == goal``.
        """
        if start == goal:
            return [(start, t_start_step)]

        # Abs |dx| + |dy| heuristic (admissible on a 4-connected grid)
        def h(c: Coord) -> int:
            return abs(c[0] - goal[0]) + abs(c[1] - goal[1])

        # Open queue: (f_score, g_score, tie, state)
        open_heap: list[tuple[int, int, int, tuple[Coord, int]]] = []
        tie = 0
        heapq.heappush(open_heap, (h(start), 0, tie, (start, t_start_step)))
        tie += 1

        came_from: dict[tuple[Coord, int], tuple[Coord, int]] = {}
        g_score: dict[tuple[Coord, int], int] = {(start, t_start_step): 0}

        # A* search budget: 4×deadline horizon (waits + moves). A pure 20×20
        # grid has 400 nodes; with reasonable horizons this terminates fast.
        max_expansions = 50_000
        expansions = 0

        while open_heap and expansions < max_expansions:
            _, g, _, current = heapq.heappop(open_heap)
            cell, t_step = current
            expansions += 1

            if cell == goal:
                # Reconstruct path
                path: list[tuple[Coord, int]] = [current]
                while current in came_from:
                    current = came_from[current]
                    path.append(current)
                path.reverse()
                return path

            if t_step >= deadline_step:
                continue

            # Neighbors: 4 moves + 1 wait
            cx, cy = cell
            successor_cells: list[Coord] = []
            for dx, dy in self._NEIGHBOR_OFFSETS:
                nx, ny = cx + dx, cy + dy
                if 0 <= nx < self.grid.width and 0 <= ny < self.grid.height:
                    successor_cells.append((nx, ny))
            successor_cells.append(cell)   # wait action

            t_next = t_step + 1
            for n in successor_cells:
                # Vertex (node) conflict
                if not self.table.is_node_free(n, t_next, ignoring_rid=rid):
                    continue
                # Edge (swap) conflict — only relevant for actual moves
                if n != cell and not self.table.is_edge_free(cell, n, t_step, ignoring_rid=rid):
                    continue

                next_state = (n, t_next)
                tentative_g = g + 1
                if tentative_g < g_score.get(next_state, 1_000_000_000):
                    g_score[next_state] = tentative_g
                    came_from[next_state] = current
                    f = tentative_g + h(n)
                    heapq.heappush(open_heap, (f, tentative_g, tie, next_state))
                    tie += 1

        return None
